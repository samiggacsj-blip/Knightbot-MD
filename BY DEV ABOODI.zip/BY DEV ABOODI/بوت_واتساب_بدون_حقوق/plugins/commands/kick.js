const DataUtils = require("../../libs/dataUtils");
const { getUserName } = require("../../libs/utils");

module.exports = {
  config: {
    name: "kick",
    aliases: ["remove", "طرد", "ركل", "إزالة", "ازاله", "حذف"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 1,
    description: "طرد وإزالة عضو من المجموعة",
    category: "moderation",
    guide: "{pn} @منشن [السبب] - لطرد العضو من المجموعة مع ذكر السبب (اختياري)"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const threadId = message.key.remoteJid;
      const isGroup = threadId.endsWith("@g.us");
      const isAdmin = config.admins.includes(senderJid);
      
      if (!isGroup) {
        return reply("❌ يمكن استخدام هذا الأمر داخل المجموعات فقط.");
      }
      
      if (!isAdmin) {
        return reply("❌ ليس لديك الصلاحية الكافية لاستخدام هذا الأمر.");
      }
      
      // جلب معرف العضو المشار إليه (منشن)
      const mentionedUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (!mentionedUser) {
        const prefix = global.config?.prefix || ".";
        return reply(`❌ يرجى الإشارة (منشن) للعضو المراد طرده.\n💡 طريقة الاستخدام: \`${prefix}kick @منشن [السبب]\``);
      }
      
      // نظام حماية: منع طرد مطوري أو مديري البوت الأساسيين
      if (config.admins.includes(mentionedUser)) {
        return reply("❌ نظام الحماية: لا يمكن طرد مشرف أو مطور البوت الأساسي.");
      }
      
      // جلب تفاصيل سبب الطرد إن وجدت
      const reason = args.slice(1).join(" ") || "لم يتم ذكر سبب محدد";
      
      // جلب بيانات العضو واسمه من قاعدة البيانات والـ API
      const userData = await DataUtils.getUser(mentionedUser);
      const userName = await getUserName(mentionedUser, message, api);
      const threadData = await DataUtils.getThread(threadId);
      
      // التحقق مما إذا كان العضو متواجداً بالفعل في المجموعة حالياً
      if (!threadData.participants.includes(mentionedUser)) {
        return reply("❌ هذا العضو ليس موجوداً في هذه المجموعة.");
      }
      
      try {
        // إرسال طلب إزالة العضو من المجموعة عبر الـ API
        await api.groupParticipantsUpdate(threadId, [mentionedUser], "remove");
        
        // تحديث مصفوفة الأعضاء في قاعدة بيانات المجموعة بعد الطرد
        const updatedParticipants = threadData.participants.filter(p => p !== mentionedUser);
        await DataUtils.updateThread(threadId, {
          participants: updatedParticipants,
          lastActivity: Date.now()
        });
        
        // صياغة رسالة الطرد النهائية للشات
        const kickMessage = `👢 *تم طرد العضو بنجاح*\n\n` +
                           `👤 العضو: ${userName}\n` +
                           `🆔 المعرف: ${mentionedUser}\n` +
                           `👮 بواسطة المشرف: ${message.pushName || "المطور المسؤول"}\n` +
                           `📝 السبب: ${reason}\n` +
                           `🕐 الوقت: ${new Date().toLocaleString()}`;
        
        await reply(kickMessage);
        
        logger.info(`تم طرد المستخدم: ${userName} (${mentionedUser}) من المجموعة ${threadId} بواسطة ${senderJid}`);
        
      } catch (error) {
        logger.error("خطأ أثناء محاولة طرد العضو:", error);
        await reply("❌ فشل طرد العضو. يرجى التأكد من أن البوت يملك صلاحيات المشرف (Admin) في المجموعة أولاً.");
      }
      
    } catch (error) {
      logger.error("خطأ عام في أمر الطرد (kick):", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة أمر الطرد.");
    }
  }
};
