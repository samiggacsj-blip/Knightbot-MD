module.exports = {
	config: {
		name: "rules",
		aliases: ["قوانين", "القوانين", "شروط", "قانون", "شروطنا", "الرولز"],
		version: "1.5",
		author: "@anbuinfosec",
		countDown: 5,
		role: 0,
		description: "إنشاء، عرض، إضافة، تعديل، تغيير ترتيب، أو حذف قوانين المجموعة",
		category: "group",
		guide: "{pn} [إضافة | add | -a] <نص القانون>: لإضافة قانون جديد للمجموعة."
			+ "\n{pn}: لعرض قوانين المجموعة الحالية."
			+ "\n{pn} [تعديل | edit | -e] <رقم القانون> <النص الجديد>: لتعديل نص القانون المحدد."
			+ "\n{pn} [نقل | move | -m] <الرقم الأول> <الرقم الثاني>: لتبديل ترتيب أماكن القوانين بين رقمين."
			+ "\n{pn} [حذف | delete | -d] <رقم القانون>: لحذف قانون معين بناءً على رقمه."
			+ "\n{pn} [مسح | remove | -r]: لحذف وإزالة جميع قوانين المجموعة نهائياً."
			+ "\n"
			+ "\n💡 أمثلة على الاستخدام:"
			+ "\n{pn} إضافة ممنوع إرسال روابط وروابط سبام"
			+ "\n{pn} نقل 1 3"
			+ "\n{pn} -e 1 ممنوع التحدث في المواضيع السياسية"
			+ "\n{pn} مسح"
	},

	onStart: async function ({ message, event, args, threadsData, role }) {
		const { threadID } = event;
		const threadData = await threadsData.get(threadID);
		const rulesOfThread = threadData.data.rules || [];
		const totalRules = rulesOfThread.length;
		const type = (args[0] || "").toLowerCase();

		// دعم إضافة القوانين باللغتين العربية والإنجليزية
		if (["add", "-a", "إضافة", "اضافه", "ضيف"].includes(type)) {
			if (role < 1)
				return message.reply("❌ عذراً، هذا الأمر متاح فقط لمشرفي وإداريي المجموعة.");
			if (!args[1])
				return message.reply("⚠️ يرجى كتابة نص القانون الذي ترغب في إضافته.");
			rulesOfThread.push(args.slice(1).join(" "));
			try {
				await threadsData.set(threadID, rulesOfThread, "data.rules");
				message.reply("✅ تم إضافة القانون الجديد إلى قائمة قوانين المجموعة بنجاح.");
			}
			catch (err) {
				message.reply("❌ حدث خطأ داخلي أثناء محاولة حفظ القوانين في قاعدة البيانات.");
			}
		}
		// دعم تعديل القوانين باللغتين العربية والإنجليزية
		else if (["edit", "-e", "تعديل", "تعديل_قانون"].includes(type)) {
			if (role < 1)
				return message.reply("❌ عذراً، هذا الأمر متاح فقط لمشرفي وإداريي المجموعة.");
			const stt = parseInt(args[1]);
			if (isNaN(stt))
				return message.reply("⚠️ يرجى تحديد رقم صحيح يمثل القانون المراد تعديله.");
			if (!rulesOfThread[stt - 1])
				return message.reply(`⚠️ القانون رقم ${stt} غير موجود. ${totalRules == 0 ? "المجموعة لا تمتلك أي قوانين حالياً." : `تمتلك المجموعة حالياً ${totalRules} قوانين فقط.`}`);
			if (!args[2])
				return message.reply(`⚠️ يرجى كتابة المحتوى الجديد لتعديل القانون رقم ${stt}`);
			const newContent = args.slice(2).join(" ");
			rulesOfThread[stt - 1] = newContent;
			try {
				await threadsData.set(threadID, rulesOfThread, "data.rules");
				message.reply(`✅ تم تعديل القانون رقم ${stt} بنجاح بالمتغيرات الجديدة.`);
			}
			catch (err) {
				message.reply("❌ حدث خطأ أثناء محاولة تعديل وحفظ القانون الجديد.");
			}
		}
		// دعم تغيير الترتيب (النقل) باللغتين العربية والإنجليزية
		else if (["move", "-m", "نقل", "ترتيب", "تبديل"].includes(type)) {
			if (role < 1)
				return message.reply("❌ عذراً، هذا الأمر متاح فقط لمشرفي وإداريي المجموعة.");
			const stt1 = parseInt(args[1]);
			const stt2 = parseInt(args[2]);
			if (isNaN(stt1) || isNaN(stt2))
				return message.reply("⚠️ يرجى كتابة أرقام صحيحة وصالحة لتبديل أماكن القوانين.");
			if (!rulesOfThread[stt1 - 1] || !rulesOfThread[stt2 - 1])
				return message.reply(`⚠️ القانون المحدد رقم ${!rulesOfThread[stt1 - 1] ? stt1 : stt2} غير موجود. ${totalRules == 0 ? "المجموعة لا تمتلك أي قوانين حالياً." : `تمتلك المجموعة حالياً ${totalRules} قوانين فقط.`}`);
			[rulesOfThread[stt1 - 1], rulesOfThread[stt2 - 1]] = [rulesOfThread[stt2 - 1], rulesOfThread[stt1 - 1]];
			try {
				await threadsData.set(threadID, rulesOfThread, "data.rules");
				message.reply(`✅ تم نقل وتبديل الترتيب بنجاح بين القانون رقم ${stt1} والقانون رقم ${stt2}.`);
			}
			catch (err) {
				message.reply("❌ حدث خطأ أثناء إعادة ترتيب ونقل القوانين.");
			}
		}
		// دعم حذف قانون معين باللغتين العربية والإنجليزية
		else if (["delete", "-d", "حذف", "ازالة", "إزالة"].includes(type)) {
			if (role < 1)
				return message.reply("❌ عذراً، هذا الأمر متاح فقط لمشرفي وإداريي المجموعة.");
			const stt = parseInt(args[1]);
			if (isNaN(stt))
				return message.reply("⚠️ يرجى تحديد رقم القانون الصالح الذي ترغب في حذفه.");
			if (!rulesOfThread[stt - 1])
				return message.reply(`⚠️ القانون رقم ${stt} غير موجود. ${totalRules == 0 ? "المجموعة لا تمتلك أي قوانين حالياً." : `تمتلك المجموعة حالياً ${totalRules} قوانين فقط.`}`);
			rulesOfThread.splice(stt - 1, 1);
			try {
				await threadsData.set(threadID, rulesOfThread, "data.rules");
				message.reply(`✅ تم حذف القانون رقم ${stt} بنجاح من سجلات المجموعة.`);
			}
			catch (err) {
				message.reply("❌ حدث خطأ داخلي أثناء محاولة حذف القانون المختار.");
			}
		}
		// دعم مسح كافة القوانين باللغتين العربية والإنجليزية مع تأكيد الحذف بالتفاعل
		else if (["remove", "-r", "مسح", "تصفير", "حذف_الكل"].includes(type)) {
			if (role < 1)
				return message.reply("❌ عذراً، هذا الأمر متاح فقط لمشرفي وإداريي المجموعة.");
			return message.reply("⚠️ هل أنت متأكد تماماً من رغبتك في حذف وإزالة كافة قوانين المجموعة نهائياً؟\nقم بالتفاعل (وضع إيموجي/React) على هذه الرسالة لتأكيد الحذف النهائي.", (err, info) => {
				global.GoatBot.onReaction.set(info.messageID, {
					commandName: "rules",
					messageID: info.messageID,
					author: event.senderID
				});
			});
		}
		// في حال عدم إرسال خيارات يتم عرض القوانين مباشرة للمستخدمين
		else {
			if (totalRules == 0) {
				const prefix = global.config?.prefix || "/";
				return message.reply(`⚠️ هذه المجموعة لا تمتلك أي قوانين معينة حتى الآن.\n💡 إذا كنت مشرفاً، يمكنك إضافة قانون بكتابة:\n\`${prefix}rules إضافة اكتب نص القانون هنا\``);
			}
			let msg = `📋 *قوانين وشروط مجموعة [ ${threadData.threadName || "المجموعة الحالية"} ]* 📋\n\n`;
			for (let i = 0; i < rulesOfThread.length; i++) {
				msg += `${i + 1}. ${rulesOfThread[i]}\n`;
			}
			msg += `\n💡 يرجى الالتزام التام بالقوانين أعلاه لتفادي الطرد أو الحظر التلقائي من المشرفين.`;
			return message.reply(msg);
		}
	},

	// معالج التفاعل (Reaction) لتنفيذ المسح الشامل والنهائي للقوانين بعد تأكيد المشرف
	onReaction: async function ({ message, event, Reaction, threadsData }) {
		const { threadID, userID } = event;
		if (userID != Reaction.author)
			return;
		try {
			await threadsData.set(threadID, [], "data.rules");
			message.reply("✅ تم تصفير وحذف جميع قوانين المجموعة نهائياً بناءً على تأكيدك.");
		}
		catch (err) {
			message.reply("❌ حدث خطأ غير متوقع أثناء محاولة حذف وإزالة جميع القوانين.");
		}
	}
};
