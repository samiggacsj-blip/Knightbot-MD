const { exec } = require('child_process');

module.exports = {
  config: {
    name: "shell",
    aliases: ["sh", "ترمنال", "شيل", "نظام", "امر", "أمر"],
    description: "تنفيذ الأوامر السطرية ونظام التشغيل (CLI) مباشرة عبر سيرفر البوت",
    role: 2, // متاح حصرياً لمطور البوت الأساسي نظراً لخطورة الوصول للنظام
    countDown: 2,
  },
  onCmd: async ({ args, reply, message, user, config, logger, event }) => {
    
    // التحقق من وجود مدخلات لتنفيذها
    if (!args[0]) {
      return message.reply("⚠️ يرجى كتابة الأمر السطري المطلوب تنفيذه في السيرفر.");
    }

    // تشغيل الأمر السطري عبر نظام التشغيل الخلفي للسيرفر
    exec(`${args.join(" ")}`, (error, stdout, stderr) => {
      if (error) {
        message.reply(`❎ | حدث خطأ أثناء تنفيذ الأمر:\n${error}`);
        return;
      }

      // في حال وجود مخرجات خطأ قياسية (Stderr) يتم عرضها أيضاً
      if (stderr) {
        message.reply(`⚠️ | مخرجات تنبيهية:\n${stderr}`);
      }

      // تنسيق المخرجات الناتجة من نظام التشغيل لتبدو مرتبة وسهلة القراءة
      const formattedOutput = stdout
        .trim()
        .split("\n")
        .map((line) => `${line}`)
        .join("\n");
        
      // إرسال النتيجة النهائية للشات (أو إرسال رسالة نجاح إذا لم تكن هناك مخرجات نصية)
      message.reply(formattedOutput || "✅ تم تنفيذ الأمر بنجاح (لا توجد مخرجات نصية).");
    });
  },
};
