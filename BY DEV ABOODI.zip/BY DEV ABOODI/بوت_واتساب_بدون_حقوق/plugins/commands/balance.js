const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "balance",
    aliases: ["bal", "money", "currency", "رصيد", "فلوس", "اموال"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 5,
    role: 0,
    description: "التحقق من رصيدك المالي أو منح/سحب الأموال الافتراضية (للمشرفين فقط)",
    category: "economy",
    guide: "balance [give/take] [@user] [amount]{pn}"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const isAdmin = config.admins.includes(senderJid);
      
      // إذا لم يتم إدخال أي وسائط، يتم عرض رصيد المستخدم الحالي
      if (args.length === 0) {
        const userData = await DataUtils.getUser(senderJid);
        if (!userData) {
          return reply("❌ تعذر الوصول إلى بيانات رصيدك الحالي.");
        }
        
        return reply(`💰 *محفظتك المالية الافتراضية*\n\n` +
                    `💵 الرصيد الحالي: ${userData.currency}\n` +
                    `⭐ المستوى الحالي: ${userData.level}\n` +
                    `📊 نقاط الخبرة (Exp): ${userData.experience}`);
      }
      
      const firstArg = args[0]?.toLowerCase();
      const isGiveAction = firstArg === "give" || firstArg === "اعطاء" || firstArg === "إعطاء";
      const isTakeAction = firstArg === "take" || firstArg === "اخذ" || firstArg === "أخذ" || firstArg === "سحب";

      // أوامر التحكم والمراقبة الخاصة بمطوري النظام والمشرفين (تدعم العربية والإنجليزية)
      if (isAdmin && (isGiveAction || isTakeAction)) {
        const targetUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        const amount = parseInt(args[2]);
        
        if (!targetUser) {
          return reply("❌ يرجى الإشارة (منشن) للعضو المراد منح أو سحب الأموال منه.");
        }
        
        if (isNaN(amount) || amount <= 0) {
          return reply("❌ يرجى تحديد كمية أو مبلغ مالي صحيح.");
        }
        
        const userData = await DataUtils.getUser(targetUser);
        if (!userData) {
          return reply("❌ تعذر العثور على بيانات هذا المستخدم في النظام.");
        }
        
        if (isGiveAction) {
          userData.currency += amount;
          await DataUtils.updateUser(targetUser, { currency: userData.currency });
          return reply(`✅ تم بنجاح إيداع ومنح ${amount} من العملة إلى حساب العضو ${userData.name}.\n` +
                      `💰 رصيده الجديد الآن: ${userData.currency}`);
        } else if (isTakeAction) {
          if (userData.currency < amount) {
            return reply(`❌ فشلت العملية؛ العضو يملك ${userData.currency} فقط في محفظته، لا يمكن خصم ${amount}.`);
          }
          userData.currency -= amount;
          await DataUtils.updateUser(targetUser, { currency: userData.currency });
          return reply(`✅ تم بنجاح سحب وخصم ${amount} من العملة من حساب العضو ${userData.name}.\n` +
                      `💰 رصيده المتبقي الآن: ${userData.currency}`);
        }
      }
      
      // فحص وعرض الرصيد الخاص بالمستخدم المشار إليه (منشن)
      const targetUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (targetUser) {
        const userData = await DataUtils.getUser(targetUser);
        if (!userData) {
          return reply("❌ تعذر جلب وعرض بيانات رصيد هذا العضو.");
        }
        
        return reply(`💰 *محفظة العضو [ ${userData.name} ]*\n\n` +
                    `💵 الرصيد الحالي: ${userData.currency}\n` +
                    `⭐ المستوى: ${userData.level}\n` +
                    `📊 نقاط الخبرة (Exp): ${userData.experience}`);
      }
      
      return reply("❌ طريقة استخدام غير صحيحة. استخدم الأمر بمفرده لمعرفة رصيدك، أو قم بالإشارة لعضو آخر لمعرفة رصيده المالي.");
      
    } catch (error) {
      logger.error("خطأ في أمر الرصيد والاقتصاد (balance):", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة تفاصيل الرصيد.");
    }
  }
};
