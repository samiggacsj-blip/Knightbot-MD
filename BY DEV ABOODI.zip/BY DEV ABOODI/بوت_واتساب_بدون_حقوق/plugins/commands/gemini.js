const axios = require("axios");

module.exports = {
  config: {
    name: "gemini",
    aliases: ["ai", "ask", "chat", "ذكاء", "اسأل", "اسال", "جميني", "جمناي"],
    description: "طرح الأسئلة والاستفسارات على الذكاء الاصطناعي Gemini من جوجل",
    author: "anbuinfosec",
    cooldown: 5,
    role: 0,
    category: "ai",
    guide: "{pn} <السؤال>\n💡 مثال: {pn} اشرح لي الذكاء الاصطناعي ببساطة"
  },

  onCmd: async ({ args, event, reply, react }) => {
    const prompt = args.join(" ");
    const apiKey = global.GoatBot.config.apikeys?.gemini;

    if (!apiKey) {
      await react("❌");
      return reply("❌ مفتاح الواجهة البرمجية لـ Gemini غير معين. يرجى تعريف `GEMINI_API_KEY` في ملف البيئة الخاص بك (.env).");
    }

    if (!prompt) {
      const prefix = global.config?.prefix || "/";
      return reply(`❌ يرجى كتابة السؤال أو النص المطلوب.\n💡 مثال: ${prefix}gemini ما هو التعلم الآلي؟`);
    }

    await react("💭");

    try {
      const res = await axios.post(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent",
        {
          contents: [
            {
              parts: [{ text: prompt }]
            }
          ]
        },
        {
          headers: {
            "Content-Type": "application/json",
            "X-goog-api-key": apiKey
          }
        }
      );

      const replyText =
        res?.data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

      if (!replyText) {
        await react("❌");
        return reply("❌ لم يتمكن نموذج Gemini من توليد استجابة لهذا السؤال حالياً.");
      }

      await react("✅");
      return reply(`🧠 *إجابة الذكاء الاصطناعي (Gemini):*\n\n${replyText}`);
    } catch (err) {
      console.error("Gemini error:", err.response?.data || err.message);
      await react("❌");
      return reply("❌ فشل الاتصال بخادم Gemini API. يرجى التحقق من الرابط أو المحاولة لاحقاً.");
    }
  },
};
