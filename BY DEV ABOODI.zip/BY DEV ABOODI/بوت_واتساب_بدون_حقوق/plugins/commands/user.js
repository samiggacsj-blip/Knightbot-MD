const fs = require('fs');
const path = require('path');

module.exports = {
    config: {
        name: "user",
        aliases: ["u", "profile", "مستخدم", "بروفايل", "ملفي", "حساب", "حسابي", "ملف"],
        description: "لوحة التحكم بالمستخدمين، الإشراف، واستعراض الملفات الشخصية",
        guide: "{pn} [معلومات | حظر | فك_حظر | تحذير | تصفير_التحذيرات | فلوس | خبرة] [@منشن أو بالرد]\n\n"
            + "💡 أمثلة على العمليات:\n"
            + "• {pn} معلومات -> لعرض ملفك الشخصي أو ملف العضو المذكور\n"
            + "• {pn} تحذير @منشن مخالفة القوانين -> لتوجيه إنذار لعضو\n"
            + "• {pn} فلوس @منشن 500 -> لإضافة أموال (للمطورين)\n"
            + "• {pn} فلوس @منشن -200 -> لخصم أموال من العضو",
        author: "@anbuinfosec",
        role: 0,
        cooldown: 3,
        countDown: 3,
        category: "utility"
    },

    onStart: async ({ reply, event, args, user, role, utils, api, getLang }) => {
        try {
            // قاموس النصوص والترجمات الداخلي المعرب بالكامل لدعم العمليات
            const getText = getLang || ((key, ...args) => {
                const texts = {
                    missingAction: "❌ يرجى تحديد الإجراء المطلوب تنفيذه: معلومات، حظر، فك_حظر، تحذير، تصفير_التحذيرات، فلوس، خبرة",
                    noPermission: "❌ عذراً، ليس لديك الصلاحية الكافية في البوت لتنفيذ هذا الإجراء.",
                    userNotFound: "❌ تعذر العثور على هذا المستخدم في قاعدة البيانات.",
                    missingUser: "❌ يرجى الإشارة (منشن) للعضو المستهدف أو قم بالرد على رسالته مباشرة.",
                    missingAmount: "❌ يرجى تحديد الكمية أو القيمة الرقمية المطلوبة للتعديل.",
                    missingReason: "❌ يرجى كتابة سبب الإجراء لتسجيله في النظام.",
                    userBanned: "🚫 تم حظر المستخدم بنجاح من استخدام البوت. السبب: %1",
                    userUnbanned: "✅ تم إلغاء حظر المستخدم بنجاح وإعادته للنظام.",
                    userWarned: "⚠️ تم توجيه إنذار للعضو بنجاح. إجمالي التحذيرات الحالية: %1\n📝 السبب: %2",
                    warningsCleared: "✅ تم تصفير وإلغاء كافة التحذيرات والإنذارات السابقة لهذا العضو.",
                    moneyAdded: "💰 تم إضافة %1$ إلى رصيد العضو بنجاح. الرصيد الحالي: %2$",
                    moneyRemoved: "📉 تم خصم %1$ من رصيد العضو بنجاح. الرصيد الحالي: %2$",
                    expAdded: "⭐ تم منح العضو %1 من نقاط الخبرة (XP). الإجمالي الحالي: %2 XP",
                    expRemoved: "📉 تم خصم %1 من نقاط الخبرة (XP) للعضو. الإجمالي الحالي: %2 XP",
                    userInfo: "👤 *بطاقة الملف الشخصي للمستخدم* 👤\n\n"
                        + "🏷️ *الاسم:* %1\n"
                        + "🆔 *المعرف الحسابي (ID):* \`%2\`\n"
                        + "📊 *المستوى (Level):* %3\n"
                        + "⭐ *نقاط الخبرة:* %4 XP\n"
                        + "💰 *الرصيد المالي:* %5$\n"
                        + "⚠️ *إجمالي التحذيرات:* %6\n"
                        + "🚫 *حالة الحظر:* %7\n"
                        + "📅 *أول ظهور بالبوت:* %8\n"
                        + "📅 *آخر تفاعل مرصود:* %9\n"
                        + "📨 *عدد الرسائل الإجمالي:* %10"
                };
                let text = texts[key] || key;
                args.forEach((arg, index) => {
                    text = text.replace(new RegExp(`%${index + 1}`, 'g'), arg);
                });
                return text;
            });

            const currentUser = await user.getUser();
            const userRole = await role.getRole();

            if (!args[0]) {
                return await reply(getText('missingAction'));
            }

            const action = args[0].toLowerCase();
            let targetUser = event.senderID;

            // جلب معرف المستخدم المستهدف ديناميكياً سواء من المنشن أو الرد أو الكتابة بالـ @
            if (event.mentions && Object.keys(event.mentions).length > 0) {
                targetUser = Object.keys(event.mentions)[0];
            } else if (event.messageReply) {
                targetUser = event.messageReply.senderID;
            } else if (args[1] && args[1].includes('@')) {
                targetUser = args[1].replace('@', '');
            }

            // التحقق من الإجراءات والعمليات ودعمها باللغتين العربية والإنجليزية
            switch (action) {
                case 'info':
                case 'معلومات':
                case 'ملف':
                    await showUserInfo(targetUser, user, reply, getText);
                    break;

                case 'ban':
                case 'حظر':
                    if (userRole < 1) {
                        return await reply(getText('noPermission'));
                    }
                    if (targetUser === event.senderID) {
                        return await reply("❌ لا يمكنك القيام بحظر حسابك الشخصي!");
                    }
                    await banUser(targetUser, args.slice(1).join(' ') || 'لم يتم ذكر سبب محدد', user, reply, getText);
                    break;

                case 'unban':
                case 'فك_حظر':
                case 'الغاء_الحظر':
                    if (userRole < 1) {
                        return await reply(getText('noPermission'));
                    }
                    await unbanUser(targetUser, user, reply, getText);
                    break;

                case 'warn':
                case 'تحذير':
                case 'انذار':
                    if (userRole < 1) {
                        return await reply(getText('noPermission'));
                    }
                    if (targetUser === event.senderID) {
                        return await reply("❌ لا يمكنك توجيه تحذير أو إنذار لنفسك!");
                    }
                    const reason = args.slice(1).join(' ');
                    if (!reason) {
                        return await reply(getText('missingReason'));
                    }
                    await warnUser(targetUser, reason, user, reply, getText);
                    break;

                case 'clearwarns':
                case 'تصفير_التحذيرات':
                case 'مسح_الانذارات':
                    if (userRole < 1) {
                        return await reply(getText('noPermission'));
                    }
                    await clearWarnings(targetUser, user, reply, getText);
                    break;

                case 'money':
                case 'فلوس':
                case 'اموال':
                case 'رصيد':
                    if (userRole < 2) {
                        return await reply(getText('noPermission'));
                    }
                    const amount = parseInt(args[1]);
                    if (isNaN(amount)) {
                        return await reply(getText('missingAmount'));
                    }
                    await manageMoney(targetUser, amount, user, reply, getText);
                    break;

                case 'exp':
                case 'خبرة':
                case 'خبره':
                case 'نقاط':
                    if (userRole < 2) {
                        return await reply(getText('noPermission'));
                    }
                    const expAmount = parseInt(args[1]);
                    if (isNaN(expAmount)) {
                        return await reply(getText('missingAmount'));
                    }
                    await manageExp(targetUser, expAmount, user, reply, getText);
                    break;

                default:
                    await reply(getText('missingAction'));
            }

        } catch (error) {
            console.error("Error in user command:", error);
            await reply("❌ حدث خطأ غير متوقع أثناء معالجة أمر إدارة المستخدمين.");
        }
    }
};

// دالة عرض وتنسيق الملف الشخصي
async function showUserInfo(userId, user, reply, getText) {
    try {
        const userData = await user.getUser(userId);
        
        if (!userData) {
            return await reply(getText('userNotFound'));
        }

        const level = Math.floor((userData.exp || 0) / 100) + 1;
        const warnings = userData.warnings ? userData.warnings.length : 0;
        const banned = userData.banned ? 'نعم (محظور)' : 'لا (نشط)';
        const firstSeen = userData.firstSeen ? new Date(userData.firstSeen).toLocaleDateString('ar-EG') : 'غير مسجل';
        const lastSeen = userData.lastSeen ? new Date(userData.lastSeen).toLocaleDateString('ar-EG') : 'غير مسجل';

        const info = getText('userInfo',
            userData.name || 'عضو غير معروف',
            userData.id || userId,
            level,
            userData.exp || 0,
            userData.money || 0,
            warnings,
            banned,
            firstSeen,
            lastSeen,
            userData.messageCount || 0
        );

        await reply(info);

    } catch (error) {
        await reply(getText('userNotFound'));
    }
}

// دالة حظر العضو من استخدام البوت
async function banUser(userId, reason, user, reply, getText) {
    try {
        await user.ban(userId, reason);
        await reply(getText('userBanned', reason));
    } catch (error) {
        await reply(getText('userNotFound'));
    }
}

// دالة فك الحظر عن العضو
async function unbanUser(userId, user, reply, getText) {
    try {
        await user.unban(userId);
        await reply(getText('userUnbanned'));
    } catch (error) {
        await reply(getText('userNotFound'));
    }
}

// دالة تو
