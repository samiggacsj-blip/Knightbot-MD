const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "thread",
    aliases: ["group", "chat", "مجموعة", "مجموعه", "جروب", "المجموعة", "المجموعه", "إعدادات", "اعدادات"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 5,
    role: 1, // متاح فقط للمشرفين وإداريي البوت
    description: "إدارة إعدادات وخصائص المجموعة واستعراض بياناتها بالكامل",
    category: "admin",
    guide: "{pn} [الإعداد] [القيمة]\n\n🔧 الإعدادات المتاحة:\n"
         + "• ترحيب [تشغيل / ايقاف] - لتفعيل أو تعطيل رسائل الترحيب بالمغادرين والمنضمين\n"
         + "• حماية [تشغيل / ايقاف] - لتفعيل أو تعطيل نظام مكافحة السبام (Anti-Spam)\n"
         + "• مشرفين [تشغيل / ايقاف] - لتفعيل وضع استخدام الأوامر للمشرفين فقط\n"
         + "• معلومات - لعرض تفاصيل وإحصائيات المجموعة الحالية"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply, event }) {
    try {
      const threadId = event.threadID;
      const isGroup = threadId.endsWith("@g.us");
      
      if (!isGroup) {
        return reply("❌ يمكن استخدام هذا الأمر داخل المجموعات فقط.");
      }
      
      // جلب بيانات المجموعة الحالية من قاعدة البيانات
      const threadData = await DataUtils.getThread(threadId);

      console.log(threadData);
      
      // في حال عدم إرسال خيارات أو اختيار "معلومات/info"، يتم عرض تقرير المجموعة
      if (args.length === 0 || ["info", "معلومات", "المعلومات"].includes(args[0]?.toLowerCase())) {
        
        const threadInfo = `📋 *تقرير ومعلومات المجموعة الحالية* 📋\n\n` +
                          `🆔 *معرف المجموعة:* ${threadData.id}\n` +
                          `📝 *اسم المجموعة:* ${threadData.name}\n` +
                          `👥 *عدد الأعضاء الحركي:* ${threadData.participants.length}\n` +
                          `💬 *إجمالي الرسائل المرصودة:* ${threadData.messageCount}\n` +
                          `📅 *تاريخ تسجيل المجموعة:* ${new Date(threadData.firstActivity).toLocaleString('ar-EG')}\n` +
                          `🕐 *آخر نشاط مسجل:* ${new Date(threadData.lastActivity).toLocaleString('ar-EG')}\n\n` +
                          
                          `⚙️ *حالة الإعدادات الحالية:*\n` +
                          `• رسائل الترحيب: ${threadData.settings.welcomeMessage ? "✅ مفعّلة (On)" : "❌ معطّلة (Off)"}\n` +
                          `• نظام مكافحة السبام: ${threadData.settings.antiSpam ? "✅ مفعّل (On)" : "❌ معطّل (Off)"}\n` +
                          `• أوامر للمشرفين فقط: ${threadData.settings.adminOnly ? "✅ مفعّل (On)" : "❌ معطّل (Off)"}\n` +
                          `• لغة النظام المعتمدة: ${threadData.settings.language || "ar"}\n\n` +
                          
                          `⚠️ *السجل الرقابي والإشرافي:*\n` +
                          `• إجمالي التحذيرات: ${threadData.warnings || 0}\n` +
                          `• حالة حظر المجموعة: ${threadData.banned ? "🚫 محظورة في البوت" : "✅ نشطة ونظامية"}`;
        
        return reply(threadInfo);
      }
      
      const setting = args[0].toLowerCase();
      const value = args[1]?.toLowerCase();
      
      if (!value) {
        return reply("❌ يرجى تحديد القيمة المطلوبة للإعداد (تشغيل / ايقاف) أو (on / off).");
      }
      
      // التحقق من القيمة المدخلة للتفعيل أو التعطيل باللغتين العربية والإنجليزية
      const isEnabled = ["on", "true", "1", "تشغيل", "تفعيل"].includes(value);
      const isDisabled = ["off", "false", "0", "ايقاف", "إيقاف", "تعطيل"].includes(value);
      
      if (!isEnabled && !isDisabled) {
        return reply("❌ قيمة غير صالحة. يرجى استخدام: 'تشغيل' أو 'ايقاف' (أو 'on' / 'off').");
      }
      
      let updated = false;
      let settingName = "";
      
      // معالجة الخيارات المدخلة باللغتين العربية والإنجليزية لتحديث كائن الإعدادات
      switch (setting) {
        case "welcome":
        case "ترحيب":
          threadData.settings.welcomeMessage = isEnabled;
          settingName = "رسائل الترحيب";
          updated = true;
          break;
        case "antispam":
        case "حماية":
        case "حمايه":
          threadData.settings.antiSpam = isEnabled;
          settingName = "نظام مكافحة السبام";
          updated = true;
          break;
        case "adminonly":
        case "مشرفين":
        case "المشرفين":
          threadData.settings.adminOnly = isEnabled;
          settingName = "وضع المشرفين فقط";
          updated = true;
          break;
        default:
          return reply("❌ هذا الإعداد غير موجود. الإعدادات المتاحة: (ترحيب ، حماية ، مشرفين)");
      }
      
      // حفظ الإعدادات الجديدة في قاعدة البيانات وإرسال التقرير النهائي للمجموعة
      if (updated) {
        await DataUtils.updateThread(threadId, threadData);
        const status = isEnabled ? "✅ تفعيلها بنجاح" : "❌ تعطيلها بنجاح";
        await reply(`⚙️ تم تحديث الإعدادات: [ ${settingName} ] تم ${status} لهذه المجموعة.`);
        logger.info(`Thread setting updated: ${settingName} = ${isEnabled} for ${threadId}`);
      }
      
    } catch (error) {
      logger.error("Error in thread command:", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة وحفظ إعدادات المجموعة.");
    }
  }
};
