const axios = require('axios');

module.exports = {
	config: {
		name: "translate",
		aliases: ["trans", "ترجم", "ترجمة", "ترجمه", "مترجم"],
		version: "1.5",
		author: "@anbuinfosec",
		countDown: 5,
		role: 0, // متاح لجميع الأعضاء
		description: "ترجمة النصوص الفورية إلى أي لغة تريدها باستخدام جوجل",
		category: "utility",
		guide: "{pn} <النص>: لترجمة النص إلى اللغة الافتراضية للبوت (الإنجليزية)."
			+ "\n{pn} <النص> -> <رمز اللغة>: لترجمة النص إلى لغة محددة بناءً على رمزها الدولي (ISO 639-1)."
			+ "\nأو يمكنك الرد (Reply) على رسالة أي عضو وكتابة اسم الأمر لترجمتها فوراً."
			+ "\n\n💡 أمثلة على الاستخدام:"
			+ "\n{pn} hello -> ar (لترجمة الكلمة إلى العربية)"
			+ "\n{pn} مرحبا -> en (لترجمة الكلمة إلى الإنجليزية)"
	},

	onStart: async function ({ message, event, args, threadsData, commandName }) {
		const { body = "" } = event;
		let content;
		let langCodeTrans;
		const langOfThread = "en"; // اللغة الافتراضية في حال عدم تحديد لغة مستهدفة

		// مسار معالجة البيانات في حال قام المستخدم بالرد (Reply) على رسالة أخرى
		if (event.messageReply) {
			content = event.messageReply.body;
			let lastIndexSeparator = body.lastIndexOf("->");
			if (lastIndexSeparator == -1)
				lastIndexSeparator = body.lastIndexOf("=>");

			if (lastIndexSeparator != -1 && (body.length - lastIndexSeparator == 4 || body.length - lastIndexSeparator == 5))
				langCodeTrans = body.slice(lastIndexSeparator + 2);
			else if ((args[0] || "").match(/\w{2,3}/))
				langCodeTrans = args[0].match(/\w{2,3}/)[0];
			else
				langCodeTrans = langOfThread;
		}
		// مسار معالجة البيانات في حال كتابة النص مباشرة مع الأمر
		else {
			content = event.body;
			let lastIndexSeparator = content.lastIndexOf("->");
			if (lastIndexSeparator == -1)
				lastIndexSeparator = content.lastIndexOf("=>");

			if (lastIndexSeparator != -1 && (content.length - lastIndexSeparator == 4 || content.length - lastIndexSeparator == 5)) {
				langCodeTrans = content.slice(lastIndexSeparator + 2);
				content = content.slice(content.indexOf(args[0]), lastIndexSeparator);
			}
			else
				langCodeTrans = langOfThread;
		}

		// التحقق من وجود نص لإرساله للترجمة
		if (!content) {
			const prefix = global.config?.prefix || ".";
			return message.reply(`❌ يرجى كتابة النص المراد ترجمته.\n💡 مثال: \`${prefix}translate كيف حالك -> en\``);
		}
		
		try {
			// استدعاء دالة الترجمة الخلفية المستندة إلى API جوجل
			const { text, lang } = await translate(content.trim(), langCodeTrans.trim());
			return message.reply(`${text}\n\n🌐 تم الترجـمة تلقائياً من [ ${lang.toUpperCase()} ] إلى [ ${langCodeTrans.toUpperCase()} ]`);
		} catch (err) {
			return message.reply("❌ حدث خطأ غير متوقع أثناء محاولة ترجمة النص، يرجى التحقق من رمز اللغة.");
		}
	}
};

// دالة الاتصال بخادم ترجمة جوجل وجلب المصفوفات النصية وإعادة دمجها
async function translate(text, langCode) {
	const res = await axios.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${langCode}&dt=t&q=${encodeURIComponent(text)}`);
	return {
		text: res.data[0].map(item => item[0]).join(''),
		lang: res.data[2]
	};
}
