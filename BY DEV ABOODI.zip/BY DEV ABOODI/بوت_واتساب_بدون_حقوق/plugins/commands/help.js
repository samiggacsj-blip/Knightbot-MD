const fs = require('fs');
const path = require('path');

module.exports = {
  config: {
    name: "help",
    aliases: ["h", "menu", "commands", "مساعدة", "مسعده", "اوامر", "الاوامر", "قائمة", "قائمه"],
    description: "عرض قائمة الأوامر المتاحة أو تفاصيل أمر معين وطريقة استخدامه",
    guide: [
      "{pn}help <اسم_الأمر> ← لعرض تفاصيل وشرح أمر معين بالتفصيل",
      "{pn}help ← لعرض جميع الأوامر المتاحة لك في البوت مقسمة حسب الفئات"
    ],
    author: "@anbuinfosec",
    role: 0,
    cooldown: 3,
    countDown: 3,
    category: "info"
  },

  onStart: async ({ reply, event, args, user, role, utils, getLang }) => {
    try {
      const getText = getLang || ((key, ...params) => {
        const texts = {
          noPermission: "❌ ليس لديك الصلاحية الكافية لعرض تفاصيل هذا الأمر.",
          commandNotFound: "❌ تعذر العثور على الأمر '%1'، تأكد من كتابة الاسم بشكل صحيح.",
          commandsList: "📋 قائمة الأوامر المتاحة",
          commandDetails: "📖 تفاصيل ومعلومات الأمر",
          usage: "🔧 طريقة الاستخدام: %1",
          aliases: "🔗 الاختصارات والمرادفات: %1",
          description: "📝 وصف الأمر: %1",
          cooldown: "⏱️ وقت الانتظار: %1 ثوانٍ",
          role: "🔑 الصلاحية المطلوبة: %1",
          category: "📂 الفئة: %1",
          totalCommands: "📊 يمتلك البوت حالياً %1 أمراً متاحاً للاستخدام بناءً على صلاحياتك.",
          prefix: "» أكتب %1help <اسم الأمر> لعرض شرح تفصيلي عن كيفية استخدامه.",
          noAliases: "لا يوجد اختصارات",
          noDescription: "لا يوجد وصف متاح حالياً لهذا الأمر.",
          roleNames: ['👤 مستخدم عادي', '🛡️ مشرف مجموعة', '👑 مطور البوت الإداري']
        };
        let text = texts[key] || key;
        params.forEach((param, index) => {
          text = text.replace(new RegExp(`%${index + 1}`, 'g'), param);
        });
        return text;
      });

      const currentUser = await user.getUser();
      const userRole = await role.getRole();
      const prefix = global.GoatBot.prefix || utils.getPrefix();
      const botName = global.GoatBot.config?.botName || "GoatBot";

      // قاموس ترجمة الفئات لتحويل العرض إلى اللغة العربية بشكل منسق واحترافي
      const categoryTranslations = {
        'admin': '👑 أوامر الإدارة والصيانة',
        'info': 'ℹ️ قسم المعلومات والدعم',
        'utility': '🔧 الأدوات والخدمات',
        'fun': '🎉 الألعاب والترفيه',
        'moderation': '🛡️ الحماية والإشراف',
        'game': '🎮 الألعاب والمسابقات',
        'music': '🎵 الصوتيات والموسيقى',
        'image': '🖼️ الصور والتصميم',
        'economy': '💰 النظام الاقتصادي والفلوس',
        'media': '🎬 التنزيلات والوسائط',
        'ai': '🧠 الذكاء الاصطناعي',
        'anime': '💮 الأنمي والمانجا',
        'general': '📝 الأوامر العامة',
        'system': '⚙️ إعدادات النظام',
        'owner': '👤 ركن المطور الأساسي'
      };

      if (args[0]) {
        // عرض تفاصيل أمر معين تم تحديده بواسطة المستخدم
        const commandName = args[0].toLowerCase();
        const command = global.GoatBot.commands.get(commandName) || 
                        global.GoatBot.commands.get(global.GoatBot.aliases.get(commandName));

        if (!command) {
          return await reply(getText('commandNotFound', commandName));
        }

        if (command.config.role > userRole) {
          return await reply(getText('noPermission'));
        }

        const c = command.config;

        const roleName = getText("roleNames")[c.role] || `مستوى صلاحية ${c.role}`;
        const aliases = c.aliases && c.aliases.length ? c.aliases.join(", ") : getText("noAliases");
        const description = c.description || getText("noDescription");

        let guideContent = c.guide || c.guide?.en || c.guide?.vi || "";
        if (Array.isArray(guideContent)) {
          guideContent = guideContent.map(line => line.trim()).join("\n");
        } else if (typeof guideContent === "string") {
          guideContent = guideContent.trim();
        } else {
          guideContent = "";
        }
        guideContent = guideContent.replace(/\{pn\}/g, prefix);

        // جلب الاسم المعرب للفئة إذا كان متوفراً في القاموس
        const categoryNameEN = (c.category || 'general').toLowerCase();
        const categoryShow = categoryTranslations[categoryNameEN] || `📂 ${categoryNameEN.toUpperCase()}`;

        let details = `✨ *${getText('commandDetails')}* ✨\n\n`;
        details += `🏷️ **الاسم الأساسي:** \`${c.name}\`\n`;
        details += `${getText('description', description)}\n`;
        details += `${getText('role', roleName)}\n`;
        details += `${getText('cooldown', c.cooldown || c.countDown || 3)}\n`;
        details += `${getText('category', categoryShow)}\n`;
        details += `${getText('aliases', aliases)}\n\n`;
        details += `${getText('usage', guideContent)}`;

        return await reply(details);
      }

      // تجميع وفرز كافة الأوامر بناءً على الفئات المحددة وصلاحية المستخدم
      const commands = Array.from(global.GoatBot.commands.values());
      const categories = {};

      commands.forEach(cmd => {
        if (cmd.config.role <= userRole) {
          const category = (cmd.config.category || 'general').toLowerCase();
          if (!categories[category]) categories[category] = [];
          categories[category].push({
            name: cmd.config.name,
            description: cmd.config.description || 'No description',
            aliases: cmd.config.aliases || []
          });
        }
      });

      let helpMessage = "";

      // ترتيب الفئات أبجدياً مع الإبقاء على قسم الإدارة في الأعلى دائماً لحسابات المطورين
      const sortedCategories = Object.keys(categories).sort((a, b) => {
        if (a === 'admin') return -1;
        if (b === 'admin') return 1;
        return a.localeCompare(b);
      });

      sortedCategories.forEach((category, index) => {
        const categoryCommands = categories[category];
        
        // استدعاء الاسم المعرب للفئة من القاموس العلوي
        const categoryHeader = categoryTranslations[category.toLowerCase()] || `📂 ${category.toUpperCase()}`;

        const topBorder = index === 0 ? '╭───' : '╭─────';
        const bottomSymbol = index === 0 ? '⭓' : '⭔';

        // طباعة رأس الفئة المعرب بالكامل بالشات
        helpMessage += `${topBorder} ${categoryHeader} ${bottomSymbol}\n`;

        categoryCommands.forEach(cmd => {
          helpMessage += `╰ ◈ \`${cmd.name}\`\n`;
        });
      });

      // صياغة تذييل الرسالة (Footer) بشكل جمالي ومتناسق
      helpMessage += "𝄖".repeat(15) + "⧕\n";
      helpMessage += `📊 ${getText('totalCommands', Object.values(categories).flat().length)}\n`;
      helpMessage += `💡 ${getText('prefix', prefix)}\n`;
      helpMessage += `» ${botName}\n`;
      helpMessage += "𝄖".repeat(15) + "⧕";

      await reply(helpMessage);

    } catch (error) {
      console.error("Error in help command:", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء محاولة استخراج قائمة المساعدة.");
    }
  }
};
