const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "stats",
    aliases: ["statistics", "botstats", "إحصائيات", "احصائيات", "معلومات_البوت", "الحالة", "الحاله", "احصائيه"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 0, // متاح لجميع الأعضاء
    description: "عرض إحصائيات البوت العامة وحالة النظام والمجموعات الحالية",
    category: "info",
    guide: "{pn}"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      // جلب الإحصائيات العامة من ملفات النظام وقاعدة البيانات
      const globalStats = await DataUtils.getGlobalStats();
      const botStats = global.GoatBot.stats;
      
      if (!globalStats) {
        return reply("❌ تعذر جلب واستخراج إحصائيات البوت حالياً.");
      }
      
      // حساب وتنسيق وقت تشغيل السيرفر بدقة وتحويله لصيغة مقروءة باللغة العربية
      const uptimeMs = globalStats.uptime;
      const uptimeSeconds = Math.floor(uptimeMs / 1000);
      const uptimeMinutes = Math.floor(uptimeSeconds / 60);
      const uptimeHours = Math.floor(uptimeMinutes / 60);
      const uptimeDays = Math.floor(uptimeHours / 24);
      
      const uptimeString = `${uptimeDays} يوم و ${uptimeHours % 24} ساعة و ${uptimeMinutes % 60} دقيقة و ${uptimeSeconds % 60} ثانية`;
      
      // صياغة الرسالة النهائية وتنسيق الإحصائيات بشكل جمالي ومنظم بالشات
      const statsInfo = `📊 *إحصائيات ونظام البوت العامة* 📊\n\n` +
                       `🤖 *اسم البوت:* ${global.GoatBot.user?.name || config.botName || "GoatBot"}\n` +
                       `⏱️ *مدة التشغيل:* ${uptimeString}\n` +
                       `📱 *حالة الاتصال:* ${global.GoatBot.isConnected ? "🟢 متصل ونشط" : "🔴 غير متصل"}\n\n` +
                       
                       `👥 *المستخدمين والمحادثات:*\n` +
                       `• إجمالي المستخدمين: ${globalStats.userCount}\n` +
                       `• إجمالي الدردشات: ${globalStats.threadCount}\n` +
                       `• المحادثات الجماعية (المجموعات): ${globalStats.groupCount}\n` +
                       `• المحادثات الخاصة (الخاص): ${globalStats.privateChats}\n\n` +
                       
                       `📈 *النشاط والعمليات:*\n` +
                       `• إجمالي الرسائل المستلمة: ${globalStats.totalMessages}\n` +
                       `• الرسائل التي تمت معالجتها: ${botStats.messagesProcessed}\n` +
                       `• الأوامر المنفذة بنجاح: ${botStats.commandsExecuted}\n` +
                       `• الأخطاء البرمجية المرصودة: ${botStats.errors}\n\n` +
                       
                       `🔧 *بيانات النظام الخلفية:*\n` +
                       `• الأوامر المحملة بالذاكرة: ${global.GoatBot.commands.size}\n` +
                       `• الأحداث (Events) المحملة: ${global.GoatBot.events.size}\n` +
                       `• رمز البادئة (Prefix): \`${config.prefix}\`\n` +
                       `• نوع قاعدة البيانات: ${config.database.type}`;
      
      await reply(statsInfo);
      
    } catch (error) {
      logger.error("Error in stats command:", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة جلب إحصائيات البوت.");
    }
  }
};
