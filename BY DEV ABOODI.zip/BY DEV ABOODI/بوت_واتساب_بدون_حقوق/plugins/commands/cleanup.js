const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "cleanup",
    aliases: ["clean", "purge", "تنظيف", "صيانة", "تصفية", "تنقيه"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 30,
    role: 1,
    description: "تنظيف البيانات القديمة وإدارة قاعدة البيانات للحفاظ على سرعة البوت",
    category: "admin",
    guide: "{pn} [رسائل/مستخدمين/مجموعات] [الأيام] - لتنظيف البيانات الأقدم من الأيام المحددة\n{pn} backup - لعمل نسخة احتياطية\n{pn} stats - لعرض إحصائيات قاعدة البيانات"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const isAdmin = config.admins.includes(senderJid);
      
      if (!isAdmin) {
        return reply("❌ هذا الأمر يتطلب صلاحيات المطور الإدارية.");
      }
      
      if (args.length === 0) {
        return reply("❌ يرجى تحديد الإجراء المطلوب: (messages/رسائل، users/مستخدمين، threads/مجموعات، backup/نسخ، stats/احصائيات)");
      }
      
      const action = args[0].toLowerCase();
      
      switch (action) {
        case "messages":
        case "رسائل":
        case "الرسائل":
          const days = parseInt(args[1]) || 30;
          await reply(`🔄 جاري تنظيف الرسائل الأقدم من ${days} يوماً...`);
          
          const success = await DataUtils.cleanOldMessages(days);
          if (success) {
            await reply(`✅ تم تنظيف الرسائل القديمة بنجاح (فترة الاحتفاظ الحالية: ${days} أيام).`);
          } else {
            await reply("❌ فشل تنظيف الرسائل القديمة.");
          }
          break;
          
        case "backup":
        case "نسخ":
        case "نسخة":
        case "احتياطي":
          await reply("🔄 جاري إنشاء نسخة احتياطية من قاعدة البيانات...");
          
          const backupData = await DataUtils.backupUserData();
          if (backupData) {
            const fs = require('fs');
            const backupFileName = `backup_${Date.now()}.json`;
            const backupPath = `./database/${backupFileName}`;
            
            fs.writeFileSync(backupPath, JSON.stringify(backupData, null, 2));
            await reply(`✅ تم إنشاء النسخة الاحتياطية بنجاح باسم:\n📂 \`${backupFileName}\``);
            logger.info(`تم إنشاء نسخة احتياطية لقاعدة البيانات: ${backupFileName}`);
          } else {
            await reply("❌ فشل إنشاء النسخة الاحتياطية للبيانات.");
          }
          break;
          
        case "stats":
        case "احصائيات":
        case "إحصائيات":
        case "فحص":
          await reply("📊 جاري حساب وتحليل إحصائيات قاعدة البيانات...");
          
          const allData = await db.getAllData();
          const keys = Object.keys(allData);
          
          let userCount = 0;
          let threadCount = 0;
          let messageCount = 0;
          let globalCount = 0;
          
          keys.forEach(key => {
            if (key.startsWith('user_')) userCount++;
            else if (key.startsWith('thread_')) threadCount++;
            else if (key.startsWith('message_')) messageCount++;
            else if (key.startsWith('global_')) globalCount++;
          });
          
          const statsInfo = `📊 *إحصائيات قاعدة البيانات الحالية*\n\n` +
                           `👥 عدد المستخدمين المسجلين: ${userCount}\n` +
                           `💬 عدد المجموعات (المحادثات): ${threadCount}\n` +
                           `📝 عدد الرسائل المؤرشفة: ${messageCount}\n` +
                           `🌐 المفاتيح العامة (Global): ${globalCount}\n` +
                           `🔑 إجمالي سجلات البيانات: ${keys.length}\n\n` +
                           `💾 حجم قاعدة البيانات التقريبي: ${JSON.stringify(allData).length} بايت`;
          
          await reply(statsInfo);
          break;
          
        case "users":
        case "مستخدمين":
        case "المستخدمين":
        case "أعضاء":
          const inactiveDays = parseInt(args[1]) || 90;
          await reply(`🔄 جاري تنظيف وحذف المستخدمين غير النشطين منذ (${inactiveDays} يوماً)...`);
          
          const cutoffTime = Date.now() - (inactiveDays * 24 * 60 * 60 * 1000);
          const allUsers = await db.getAllUsers();
          let deletedUsers = 0;
          
          for (const [key, userData] of Object.entries(allUsers)) {
            if (userData.lastSeen < cutoffTime) {
              await db.delete(key);
              deletedUsers++;
            }
          }
          
          await reply(`✅ تم بنجاح حذف وتصفية ${deletedUsers} مستخدم غير نشط لـ ${inactiveDays} يوماً.`);
          break;
          
        case "threads":
        case "مجموعات":
        case "المجموعات":
        case "دردشات":
          const inactiveThreadDays = parseInt(args[1]) || 60;
          await reply(`🔄 جاري تنظيف المجموعات غير النشطة منذ (${inactiveThreadDays} يوماً)...`);
          
          const threadCutoffTime = Date.now() - (inactiveThreadDays * 24 * 60 * 60 * 1000);
          const allThreads = await db.getAllThreads();
          let deletedThreads = 0;
          
          for (const [key, threadData] of Object.entries(allThreads)) {
            if (threadData.lastActivity < threadCutoffTime) {
              await db.delete(key);
              deletedThreads++;
            }
          }
          
          await reply(`✅ تم بنجاح تصفية وحذف ${deletedThreads} مجموعة مهجورة أو غير نشطة لـ ${inactiveThreadDays} يوماً.`);
          break;
          
        default:
          await reply("❌ إجراء غير صحيح. يرجى استخدام أحد الخيارات: رسائل، مستخدمين، مجموعات، نسخ، أو احصائيات.");
      }
      
    } catch (error) {
      logger.error("خطأ في أمر التنظيف والصيانة (cleanup):", error);
      await reply("❌ حدث خطأ داخلي أثناء تنفيذ عمليات صيانة قاعدة البيانات.");
    }
  }
};
