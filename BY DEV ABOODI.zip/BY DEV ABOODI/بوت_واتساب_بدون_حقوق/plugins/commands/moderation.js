const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "moderation",
    aliases: ["mod", "modpanel", "إشراف", "اشراف", "كنترول", "التحكم", "الاشراف"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 1,
    description: "لوحة تحكم الإشراف الإدارية وعرض إحصائيات البوت والمجموعات",
    category: "moderation",
    guide: "{pn} ← لعرض لوحة التحكم الافتراضية للمجموعة\n{pn} stats أو احصائيات ← لعرض الإحصائيات الإدارية الشاملة للبوت"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const threadId = message.key.remoteJid;
      const isGroup = threadId.endsWith("@g.us");
      const isAdmin = config.admins.includes(senderJid);
      
      if (!isAdmin) {
        return reply("❌ ليس لديك الصلاحية الكافية لاستخدام لوحة التحكم الإدارية.");
      }
      
      const action = args[0]?.toLowerCase();
      
      // دعم عرض الإحصائيات باللغتين العربية والإنجليزية
      if (action === "stats" || action === "احصائيات" || action === "إحصائيات") {
        // جلب البيانات الشاملة للمستخدمين والمجموعات من قاعدة البيانات
        const allUsers = await db.getAllUsers();
        const allThreads = await db.getAllThreads();
        
        let totalWarnings = 0;
        let bannedUsers = 0;
        let activeUsers = 0;
        let bannedThreads = 0;
        let threadsWithWelcome = 0;
        let threadsWithAntispam = 0;
        let threadsAdminOnly = 0;
        
        // احتساب إحصائيات المستخدمين
        for (const [key, userData] of Object.entries(allUsers)) {
          totalWarnings += userData.warnings || 0;
          if (userData.banned) bannedUsers++;
          if (userData.lastSeen > Date.now() - (7 * 24 * 60 * 60 * 1000)) activeUsers++; // نشط خلال آخر 7 أيام
        }
        
        // احتساب إحصائيات المجموعات (الدردشات)
        for (const [key, threadData] of Object.entries(allThreads)) {
          if (threadData.banned) bannedThreads++;
          if (threadData.settings.welcomeMessage) threadsWithWelcome++;
          if (threadData.settings.antiSpam) threadsWithAntispam++;
          if (threadData.settings.adminOnly) threadsAdminOnly++;
        }
        
        const statsMessage = `📊 *إحصائيات الإشراف والنظام العامة*\n\n` +
                           `👥 *المستخدمين:*\n` +
                           `• إجمالي الأعضاء المسجلين: ${Object.keys(allUsers).length}\n` +
                           `• الأعضاء النشطين (خلال أسبوع): ${activeUsers}\n` +
                           `• الأعضاء المحظورين: ${bannedUsers}\n` +
                           `• إجمالي التحذيرات القائمة: ${totalWarnings}\n\n` +
                           
                           `💬 *المجموعات والدردشات:*\n` +
                           `• إجمالي المجموعات: ${Object.keys(allThreads).length}\n` +
                           `• المجموعات المحظورة: ${bannedThreads}\n` +
                           `• ميزة الترحيب مفعلة في: ${threadsWithWelcome} مجموعة\n` +
                           `• ميزة مكافحة السبام مفعلة في: ${threadsWithAntispam} مجموعة\n` +
                           `• وضع المشرفين فقط مفعّل في: ${threadsAdminOnly} مجموعة\n\n` +
                           
                           `🤖 *إحصائيات نظام البوت:*\n` +
                           `• إجمالي الأوامر النشطة: ${global.GoatBot.commands.size}\n` +
                           `• عدد الإداريين والمطورين: ${config.admins.length}\n` +
                           `• مدة تشغيل السيرفر دون انقطاع: ${formatUptime(Date.now() - global.GoatBot.startTime)}`;
        
        return reply(statsMessage);
      }
      
      // عرض لوحة التحكم الافتراضية للمجموعة الحالية (Dashboard)
      const threadData = isGroup ? await DataUtils.getThread(threadId) : null;
      
      let dashboardMessage = `🛡️ *لوحة تحكم الإشراف والإدارة* 🛡️\n\n`;
      
      if (isGroup) {
        dashboardMessage += `📋 *معلومات المحادثة الحالية:*\n` +
                           `• اسم المجموعة: ${threadData.name || "غير معروف"}\n` +
                           `• عدد الأعضاء: ${threadData.participants.length}\n` +
                           `• تحذيرات المجموعة: ${threadData.warnings || 0}\n` +
                           `• حالة المجموعة في النظام: ${threadData.banned ? "🚫 محظورة" : "✅ نشطة"}\n\n` +
                           
                           `⚙️ *الإعدادات الأمنية الحالية:*\n` +
                           `• الترحيب المغادرين: ${threadData.settings.welcomeMessage ? "✅ مفعّل" : "❌ معطّل"}\n` +
                           `• حماية مكافحة السبام: ${threadData.settings.antiSpam ? "✅ مفعّل" : "❌ معطّل"}\n` +
                           `• أوامر للمشرفين فقط: ${threadData.settings.adminOnly ? "✅ مفعّل" : "❌ معطّل"}\n` +
                           `• اللغة المعتمدة: ${threadData.settings.language || "ar"}\n\n`;
      }
      
      const prefix = global.config?.prefix || ".";
      dashboardMessage += `🔧 *الأوامر الإدارية والرقابية المتاحة:*\n` +
                         `• \`${prefix}kick @منشن\` - لطرد عضو من المجموعة\n` +
                         `• \`${prefix}ban @منشن [السبب]\` - لحظر عضو من استخدام البوت كلياً\n` +
                         `• \`${prefix}warn @منشن [السبب]\` - تحذير عضو (3 تحذيرات = طرد تلقائي)\n` +
                         `• \`${prefix}add [الرقم/@منشن]\` - لإضافة عضو جديد للمجموعة\n` +
                         `• \`${prefix}promote @منشن\` - لرفع العضو إلى رتبة مشرف (Admin)\n` +
                         `• \`${prefix}demote @منشن\` - لتنزيل رتبة المشرف إلى عضو عادي\n` +
                         `• \`${prefix}threadinfo\` - لاستعراض تفاصيل ومعلومات المجموعة بالكامل\n` +
                         `• \`${prefix}cleanup\` - لتنظيف وتحديث سجلات قاعدة البيانات\n\n` +
                         
                         `📊 *روابط سريعة واستعلامات:*\n` +
                         `• أكتب \`${prefix}moderation stats\` لعرض إحصائيات النظام التفصيلية\n` +
                         `• أكتب \`${prefix}ban list\` لمراجعة قائمة الأعضاء المحظورين\n` +
                         `• أكتب \`${prefix}warn list @منشن\` لعرض سجل تحذيرات العضو\n\n` +
                         
                         `💡 *توجيهات ونصائح أمنية:*\n` +
                         `• نظام التحذير: عند وصول العضو لـ 3 تحذيرات يتم طرده تلقائياً من المجموعة.\n` +
                         `• الأعضاء المحظورين (Banned) يتم حرمانهم تماماً من التفاعل أو تشغيل أوامر البوت.\n` +
                         `• وضع (Admin-only) يقيد استخدام كافة أوامر البوت ويحصرها فقط في مشرفي المجموعة.\n` +
                         `• يرجى تشغيل أوامر التنظيف دورياً للحفاظ على سرعة واستقرار قاعدة البيانات.`;
      
      await reply(dashboardMessage);
      
    } catch (error) {
      logger.error("Error in moderation command:", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة لوحة تحكم الإشراف.");
    }
  }
};

// دالة صياغة وحساب وقت تشغيل السيرفر بدقة عالية وتحويلها لصيغة مقروءة
function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days} يوم و ${hours % 24} ساعة و ${minutes % 60} دقيقة`;
  if (hours > 0) return `${hours} ساعة و ${minutes % 60} دقيقة`;
  if (minutes > 0) return `${minutes} دقيقة و ${seconds % 60} ثانية`;
  return `${seconds} ثانية`;
}
