const axios = require("axios");

module.exports = {
  config: {
    name: "anilist",
    aliases: ["anime", "manga", "انمي", "مانجا", "انمي_لست", "أنمي"],
    description: "البحث عن معلومات الأنمي/المانجا أو جلب ملف تعريف مستخدم AniList",
    author: "anbuinfosec",
    category: "anime",
    role: 0,
    guide: "{pn} naruto أو {pn} -u اسم_المستخدم\n💡 بالعربي: {pn} ناروتو أو {pn} -مستخدم اسم_المستخدم"
  },

  onCmd: async ({ args, reply }) => {
    const query = args.join(" ");
    
    // التحقق من وجود خيار البحث عن مستخدم باللغتين العربية أو الإنجليزية
    const isUser = args.includes("-u") || args.includes("-مستخدم") || args.includes("-حساب");

    if (!query) return reply("❌ يرجى تحديد اسم الأنمي/المانجا أو استخدام خيار البحث عن مستخدم: `<-مستخدم اسم_المستخدم>`.");

    if (isUser) {
      // تحديد موقع اسم المستخدم بناءً على الخيار المدخل
      let index = args.indexOf("-u");
      if (index === -1) index = args.indexOf("-مستخدم");
      if (index === -1) index = args.indexOf("-حساب");
      
      const username = args[index + 1];
      if (!username) return reply("❌ يرجى كتابة اسم المستخدم بعد خيار البحث (`-مستخدم` أو `-u`) مباشرة.");

      const userQuery = `
        query {
          User(name: "${username}") {
            id
            name
            about
            siteUrl
            avatar { large }
            statistics {
              anime {
                count
                episodesWatched
                minutesWatched
                meanScore
              }
              manga {
                count
                chaptersRead
                volumesRead
                meanScore
              }
            }
          }
        }
      `;

      try {
        const res = await axios.post("https://graphql.anilist.co", {
          query: userQuery
        }, { headers: { "Content-Type": "application/json" } });

        const user = res.data.data.User;
        const about = user.about ? user.about.replace(/<br>/g, "\n") : "لا يوجد وصف متاح لهذا الحساب.";

        const caption = `
👤 الحساب: ${user.name}
🔗 رابط الملف الشخصي: ${user.siteUrl}

📖 نبذة: ${about.slice(0, 300)}${about.length > 300 ? "..." : ""}

📺 إحصائيات الأنمي:
•⁠ عدد الأنميات: ${user.statistics.anime.count}
•⁠ الحلقات المشاهدة: ${user.statistics.anime.episodesWatched}
•⁠ متوسط التقييم: ${user.statistics.anime.meanScore}
•⁠ دقائق المشاهدة: ${user.statistics.anime.minutesWatched}

📚 إحصائيات المانجا:
•⁠ عدد المقروءات: ${user.statistics.manga.count}
•⁠ الفصول المقروءة: ${user.statistics.manga.chaptersRead}
•⁠ المجلدات المقروءة: ${user.statistics.manga.volumesRead}
•⁠ متوسط التقييم: ${user.statistics.manga.meanScore || "غير متوفر"}
`;

        const img = (await axios.get(user.avatar.large, { responseType: "arraybuffer" })).data;
        return await reply({
          image: Buffer.from(img),
          mimetype: "image/jpeg",
          caption
        });
      } catch (err) {
        console.error("خطأ في واجهة برمجية AniList:", err.response?.data || err.message);
        return reply("❌ تعذر العثور على ملف تعريف هذا المستخدم في AniList.");
      }
    } else {
      const searchQuery = `
        query {
          Media(search: "${query}", type: ANIME) {
            title { romaji english native }
            episodes
            siteUrl
            genres
            averageScore
            description(asHtml: false)
            coverImage { large }
          }
        }
      `;

      try {
        const res = await axios.post("https://graphql.anilist.co", {
          query: searchQuery
        }, { headers: { "Content-Type": "application/json" } });

        const media = res.data.data.Media;
        const caption = `
🎬 الاسم: ${media.title.english || media.title.romaji}
📺 عدد الحلقات: ${media.episodes || "?"}
⭐ التقييم: ${media.averageScore || "?"}
🎭 التصنيف: ${media.genres.join(", ")}

📝 القصة:
${media.description.slice(0, 500)}${media.description.length > 500 ? "..." : ""}

🔗 للمزيد من المعلومات: ${media.siteUrl}
`;

        const img = (await axios.get(media.coverImage.large, { responseType: "arraybuffer" })).data;
        return await reply({
          image: Buffer.from(img),
          mimetype: "image/jpeg",
          caption
        });
      } catch (err) {
        console.error("خطأ في واجهة برمجية AniList:", err.response?.data || err.message);
        return
