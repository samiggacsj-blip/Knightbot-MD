const simi = require('node-simipro');

module.exports = {
  config: {
    name: "simi",
    aliases: ["simsimi", "sim", "سيمي", "سيمسيمي", "دردشة", "دردشه", "كلمني"],
    description: "الدردشة مع الروبوت سيمسيمي أو تلقينه وتعليمه ردوداً جديدة",
    author: "anbuinfosec",
    cooldown: 5,
    role: 0,
    category: "fun",
    guide: `طريقة الاستخدام:
- للدردشة: {pn} <الرسالة>
- للتعليم والتلقين: {pn} -teach -ask <السؤال> -ans <الإجابة> -lc <رمز_اللغة>

💡 أمثلة على الاستخدام:
{pn}سيمي أهلاً
{pn}سيمي -teach -ask كيف حالك -ans بخير والحمد لله -lc ar`
  },

  onCmd: async ({ args, reply, react }) => {
    if (args.length === 0) {
      const prefix = global.config?.prefix || "/";
      return reply(`❌ يرجى اتباع خطوات الاستخدام الصحيحة.\nأكتب \`${prefix}simi <الرسالة>\` للدردشة، أو أكتب \`${prefix}simi -teach -ask <السؤال> -ans <الإجابة> -lc <رمز اللّغة>\` لتعليم سيمي ردوداً مخصصة.`);
    }

    // التحقق مما إذا كان المستخدم يرغب في تفعيل وضع التعليم والتلقين
    const isTeach = args.includes("-teach");
    if (isTeach) {
      const askIndex = args.indexOf("-ask");
      const ansIndex = args.indexOf("-ans");
      const lcIndex = args.indexOf("-lc");

      if (askIndex === -1 || ansIndex === -1 || lcIndex === -1) {
        return reply("❌ وضع التعليم يتطلب توفير جميع المؤشرات الأساسية: (-ask للتلقين، -ans للإجابة، -lc لرمز اللغة).\n💡 مثال:\nsimi -teach -ask هلا -ans أهلاً بك يا غالي -lc ar");
      }

      const question = args[askIndex + 1];
      const answer = args[ansIndex + 1];
      const lang = args[lcIndex + 1];

      if (!question || !answer || !lang) {
        return reply("❌ المتغيرات المدخلة غير صالحة. تأكد من كتابة قيم واضحة ونصوص بعد مؤشرات -ask و -ans و -lc.");
      }

      await react("💡");
      try {
        // إرسال طلب التلقين والتعليم إلى حزمة node-simipro
        const res = await simi.simiteach(question, answer, lang);
        if (res.success) {
          return reply(`✅ تم تلقين سيمي بنجاح: ${res.message || "تم الحفظ بنجاح!"}`);
        } else {
          return reply(`❌ فشل تعليم سيمي. تفاصيل الخادم: ${res.message || "خطأ غير معروف"}`);
        }
      } catch (error) {
        console.error("Simi teach error:", error);
        return reply("❌ حدث خطأ داخلي أثناء محاولة تعليم وتلقين سيمي.");
      }
    } else {
      // مسار الدردشة والتفاعل العادي
      const message = args.join(" ");
      const lang = global.GoatBot.simiLang || "ar"; // تعيين اللغة العربية كخيار افتراضي أو جلبها ديناميكياً

      await react("💬");
      try {
        // جلب رد الروبوت بناءً على الرسالة المرسلة
        const res = await simi.simitalk(message, lang);
        if (res.success) {
          return reply(`📨 سيمي يقول لك:\n\n${res.message}`);
        } else {
          return reply(`❌ تعذر جلب رد من سيمي حالياً. تفاصيل الخادم: ${res.message || "خطأ غير معروف"}`);
        }
      } catch (error) {
        console.error("Simi talk error:", error);
        return reply("❌ حدث خطأ أثناء الاتصال بخادم دردشة سيمي.");
      }
    }
  }
};
