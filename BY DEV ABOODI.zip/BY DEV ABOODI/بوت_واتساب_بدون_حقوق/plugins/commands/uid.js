module.exports = {
	config: {
		name: "uid",
		aliases: ["id", "ايدي", "أيدي", "معرفي", "رقمي", "المعرف", "الرقم"],
		version: "1.2",
		author: "@anbuinfosec",
		countDown: 5,
		role: 0, // متاح لجميع الأعضاء
		description: "جلب المعرف الرقمي (ID) الخاص بك أو بالعضو المشار إليه",
		category: "info",
		guide: "{pn}: لعرض المعرف الحسابي الخاص بك."
			+ "\n{pn} @منشن: لعرض المعرف الخاص بالعضو الذي أشرت إليه."
			+ "\n{pn} بالرد: قم بالرد على رسالة أي عضو لمعرفة معرفه الحسابي."
	},

	onStart: async function ({ message, event, args }) {

		const { senderID, threadID } = event;
		
		// مسار معالجة البيانات في حال الرد (Reply) على رسالة عضو آخر
		if (event.quotedParticipant) {
			return message.reply(`👤 المعرف الحسابي (ID):\n${event.quotedParticipant}`);
		}

		// مسار معالجة البيانات في حال الإشارة (منشن) لعضو أو لعدة أعضاء
		if (Array.isArray(event.mentions) && event.mentions.length > 0) {
			let msg = "";
			for (const id of event.mentions) {
				msg += `👤 المعرف الحسابي (ID):\n${id}\n\n`;
			}
			return message.reply(msg.trim());
		}
		
		// مسار معالجة البيانات في حال كتابة رقم أو نص بشكل مباشر بعد الأمر
		if (args[0]) {
			const targetID = args[0];
			if (!isNaN(targetID)) {
				try {
					return message.reply(`👤 المعرف الحسابي (ID):\n${targetID}`);
				} catch (err) {
					return message.reply("❌ تعذر العثور على هذا المستخدم في سجلات المحادثة.");
				}
			}
		}
		
		// الافتراضي: إرسال المعرف الخاص بالمرسل نفسه في حال عدم تحديد مستهدف
		return message.reply(`👤 المعرف الحسابي الخاص بك (ID):\n${senderID}`);
	}
};
