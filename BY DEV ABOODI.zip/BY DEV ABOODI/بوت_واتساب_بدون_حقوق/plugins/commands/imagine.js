const axios = require("axios");

module.exports = {
  config: {
    name: "imagine",
    aliases: ["t2i", "imagegen", "aiart", "تخيل", "تخيل_صورة", "صورة", "صوره", "ارسم", "رسم"],
    description: "توليد ورسم صور واحترافية من النص باستخدام الذكاء الاصطناعي",
    author: "anbuinfosec",
    cooldown: 5,
    role: 0,
    category: "ai",
    guide: "{pn} <الوصف بالإنجليزية> ← لتوليد صورة بناءً على خيالك\n💡 مثال: {pn} cyberpunk cat"
  },

  onCmd: async ({ args, event, reply, react }) => {
    const prompt = args.join(" ");
    if (!prompt) {
      const prefix = global.config?.prefix || "/";
      return reply(`❌ يرجى كتابة وصف للصورة المطلوبة (يُفضل بالإنجليزية للحصول على أفضل نتيجة).\n💡 مثال: ${prefix}imagine cyberpunk hacker`);
    }

    await react("🎨");

    const apiUrl = `https://t2i.anbuinfosec.workers.dev/${encodeURIComponent(prompt)}`;

    try {
      const { data } = await axios.get(apiUrl, {
        responseType: "arraybuffer",
        headers: { "User-Agent": "Mozilla/5.0" }
      });

      await react("✔️");
      await reply({
        image: Buffer.from(data),
        mimetype: "image/jpeg",
        caption: `🧠 *النص المستخدم للتوليد:* ${prompt}`
      });
    } catch (err) {
      console.error("Image generation error:", err);
      await react("❌");
      return reply("❌ فشل خادم الذكاء الاصطناعي في توليد الصورة، يرجى المحاولة مرة أخرى لاحقاً.");
    }
  },
};
