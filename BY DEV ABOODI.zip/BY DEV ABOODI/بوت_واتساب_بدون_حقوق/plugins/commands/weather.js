const axios = require('axios');

module.exports = {
    config: {
        name: "weather",
        aliases: ["w", "forecast", "طقس", "الطقس", "جو", "الجو", "مناخ", "المناخ"],
        description: "جلب معلومات الطقس والأرصاد الجوية الحية لأي مدينة في العالم",
        guide: "{pn} <اسم المدينة>\n\n💡 مثال:\n{pn} القاهرة\n{pn} لندن",
        author: "@anbuinfosec",
        role: 0, // متاح لجميع الأعضاء
        cooldown: 10,
        countDown: 10,
        category: "utility"
    },

    onStart: async ({ reply, event, args, utils, getLang }) => {
        try {
            // قاموس النصوص والترجمات الداخلي المعرب بالكامل لدعم مخرجات الطقس
            const getText = getLang || ((key, ...args) => {
                const texts = {
                    missingLocation: "❌ يرجى تحديد اسم المدينة أو الموقع!\n💡 مثال: الطقس مكة",
                    fetching: "🌤️ جاري جلب تفاصيل الأرصاد الجوية ومسح الأجواء...",
                    locationNotFound: "❌ تعذر العثور على المدينة المطلوبة، يرجى التحقق من صحة الاسم والإملاء.",
                    serviceUnavailable: "❌ مفتاح خادم الطقس غير صالحة أو منتهي، يرجى التواصل مع مطور البوت.",
                    error: "❌ حدث خطأ أثناء الاتصال بخادم الأرصاد، يرجى المحاولة لاحقاً.",
                    weatherReport: "%1 *[ تقرير حالة الطقس والأجواء ]* %1\n\n"
                        + "📍 *الموقع:* %2، %3\n"
                        + "🌡️ *درجة الحرارة الحالية:* %4°C\n"
                        + "🤒 *المحسوسة:* %5°C\n"
                        + "🌦️ *حالة السماء:* %6\n"
                        + "💧 *نسبة الرطوبة:* %7%\n"
                        + "🌪️ *سرعة الرياح:* %8 م/ث\n"
                        + "👁️ *مدى الرؤية الأفقي:* %9 كم\n"
                        + "🌅 *شروق الشمس:* %10\n"
                        + "🌇 *غروب الشمس:* %11\n"
                        + "📊 *الضغط الجوي:* %12 hPa"
                };
                let text = texts[key] || key;
                args.forEach((arg, index) => {
                    text = text.replace(new RegExp(`%${index + 1}`, 'g'), arg);
                });
                return text;
            });
            
            if (!args[0]) {
                return await reply(getText('missingLocation'));
            }
            
            const location = args.join(' ');
            
            // الاتصال بـ API منصة OpenWeatherMap لجلب البيانات المترية المئوية
            const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&appid=efed98a2e0f2ec1e29b2a4f78e6f6a5a&units=metric&lang=ar`; // تم إضافة lang=ar لتعريب وصف السماء من الخادم مباشرة
            
            await reply(getText('fetching'));
            
            const response = await axios.get(apiUrl);
            const data = response.data;
            
            if (!data) {
                return await reply(getText('error'));
            }
            
            // ترتيب وهندسة بيانات الطقس المستلمة من السيرفر
            const weather = {
                location: data.name,
                country: data.sys.country,
                temperature: Math.round(data.main.temp),
                feelLike: Math.round(data.main.feels_like),
                humidity: data.main.humidity,
                pressure: data.main.pressure,
                description: data.weather[0].description,
                wind: data.wind.speed,
                visibility: data.visibility / 1000,
                sunrise: new Date(data.sys.sunrise * 1000).toLocaleTimeString('ar-EG'),
                sunset: new Date(data.sys.sunset * 1000).toLocaleTimeString('ar-EG')
            };
            
            // جلب الإيموجي المناسب لظاهرة الطقس الحالية
            const weatherEmoji = getWeatherEmoji(data.weather[0].main);
            
            // صياغة وإرسال الرسالة النصية النهائية المعربة
            const weatherMessage = getText('weatherReport', 
                weatherEmoji, weather.location, weather.country, weather.temperature,
                weather.feelLike, weather.description, weather.humidity, weather.wind,
                weather.visibility, weather.sunrise, weather.sunset, weather.pressure
            );

            await reply(weatherMessage);
            
        } catch (error) {
            console.error("Error in weather command:", error);
            
            const getText = getLang || ((key) => {
                const texts = {
                    locationNotFound: "❌ تعذر العثور على المدينة المطلوبة، يرجى التحقق من صحة الاسم والإملاء.",
                    serviceUnavailable: "❌ مفتاح خادم الطقس غير صالحة أو منتهي، يرجى التواصل مع مطور البوت.",
                    error: "❌ حدث خطأ أثناء الاتصال بخادم الأرصاد، يرجى المحاولة لاحقاً."
                };
                return texts[key] || key;
            });
            
            // إدارة الأخطاء التلقائية بناءً على ردود أفعال السيرفر (HTTP Status Codes)
            if (error.response && error.response.status === 404) {
                await reply(getText('locationNotFound'));
            } else if (error.response && error.response.status === 401) {
                await reply(getText('serviceUnavailable'));
            } else {
                await reply(getText('error'));
            }
        }
    }
};

// دالة تحديد الأيقونة التعبيرية المناسبة بناءً على كود الغلاف الجوي
function getWeatherEmoji(weatherCondition) {
    const emojiMap = {
        'Clear': '☀️',         // صافي
        'Clouds': '☁️',        // غيوم
        'Rain': '🌧️',          // مطر
        'Drizzle': '🌦️',       // رذاذ
        'Thunderstorm': '⛈️',  // عواصف رعدية
        'Snow': '❄️',          // ثلوج
        'Mist': '🌫️',          // ضباب خفيف
        'Fog': '🌫️',           // ضباب كثيف
        'Haze': '🌫️',          // سديم
        'Smoke': '🌫️',         // دخان
        'Dust': '🌪️',          // غبار
        'Sand': '🌪️',          // رمال
        'Squall': '🌪️',        // خطوط هبوب
        'Tornado': '🌪️'        // إعصار
    };
    
    return emojiMap[weatherCondition] || '🌤️';
}
