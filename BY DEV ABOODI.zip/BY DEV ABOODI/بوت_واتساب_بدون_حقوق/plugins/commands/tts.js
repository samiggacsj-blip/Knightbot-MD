const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "tts",
    aliases: ["صوت", "انطق", "قول", "تكلم", "تحدث", "نطق"],
    version: "1.0",
    author: "@anbuinfosec",
    description: "تحويل النصوص المكتوبة إلى مقاطع ورسائل صوتية مسموعة عبر جوجل",
    category: "tools",
    guide: "{pn} <النص> - لنطق النص باللغة الإنجليزية الافتراضية"
         + "\n{pn} -lc <رمز_اللغة> <النص> - لنطق النص بلغة مخصصة (مثال للعربية: ar)"
         + "\n\n💡 أمثلة على الاستخدام:"
         + "\n{pn} Welcome everyone"
         + "\n{pn} -lc ar أهلاً بكم جميعاً في المجموعة",
  },

  onStart: async function ({ args, reply, react }) {
    if (!args[0]) {
      const prefix = global.config?.prefix || ".";
      return reply(`🗣️ يرجى كتابة النص المراد تحويله إلى صوت.\n💡 مثال: \`${prefix}tts Hello world!\`\n💡 للنطق بالعربية: \`${prefix}tts -lc ar مرحباً بكم\``);
    }

    let lang = "en"; // اللغة الافتراضية
    let text = args.join(" ");

    // التحقق من وجود وسيط تغيير اللغة المخصص
    if (args[0] === "-lc") {
      lang = args[1];
      text = args.slice(2).join(" ");
    }

    if (!text) return reply("❌ لم يتم العثور على أي نص لنطقه بعد رمز اللغة المختار.");

    try {
      await react("🔊");

      // رابط توليد الصوت عبر API الترجمة من جوجل
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(
        text
      )}&tl=${lang}&client=tw-ob`;

      // جلب البيانات الصوتية كـ ArrayBuffer من خوادم جوجل
      const res = await axios.get(url, { responseType: "arraybuffer" });

      // تحديد المسار الجديد المختار (../../tmp/)
      const tmpDir = path.join(__dirname, "../../tmp");
      
      // خطوة أمان أوتوماتيكية: إنشاء مجلد tmp إذا لم يكن موجوداً لمنع توقف السيرفر (Crash)
      if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
      }

      const filePath = path.join(tmpDir, `tts_${Date.now()}.mp3`);
      
      // كتابة وقراءة الملف الصوتي المؤقت
      fs.writeFileSync(filePath, res.data);
      const audioBuffer = fs.readFileSync(filePath);

      // إرسال المقطع الصوتي كرسالة صوتية (Voice Note / PTT) في الواتساب
      await reply({
        audio: audioBuffer,
        mimetype: "audio/mpeg",
        ptt: true,
      });

      // تنظيف السيرفر وحذف الملف المؤقت فوراً بعد إتمام الإرسال
      fs.unlinkSync(filePath);
      await react("✅");
    } catch (err) {
      console.error("TTS Error:", err);
      await react("❌");
      reply("❌ فشل خادم تحويل النصوص في توليد المقطع الصوتي، يرجى المحاولة لاحقاً.");
    }
  },
};
