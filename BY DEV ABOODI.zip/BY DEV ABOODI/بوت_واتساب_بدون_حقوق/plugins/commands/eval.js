module.exports = {
  config: {
    name: "eval",
    aliases: ["e", "تنفيذ", "برمج", "اكواد", "أكواد", "شغل"],
    description: "تنفيذ واختبار أكواد الجافا سكريبت (JavaScript) مباشرة عبر الشات",
    role: 2, // متاح لمطور البوت الرئيسي والإداري فقط لخطورته
    countDown: 2,
  },
  onCmd: async ({ args, reply, message, user, config, logger, event }) => {
    // دالة داخلية لتنسيق المخرجات تلقائياً بناءً على نوع البيانات الناتجة
    function output(msg) {
      if (
        typeof msg == "number" ||
        typeof msg == "boolean" ||
        typeof msg == "function"
      )
        msg = msg.toString();
      else if (msg instanceof Map) {
        let text = `Map(${msg.size}) `;
        text += JSON.stringify(mapToObj(msg), null, 2);
        msg = text;
      } else if (typeof msg == "object") msg = JSON.stringify(msg, null, 2);
      else if (typeof msg == "undefined") msg = "undefined (غير معرف)";
      message.reply(msg);
    }
    
    // دالة مختصرة لتسهيل الكتابة والاختبار للمطور (مثال: out(api) )
    function out(msg) {
      output(msg);
    }
    
    // تحويل بنية الخرائط (Maps) إلى كائنات (Objects) لتسهيل قراءتها
    function mapToObj(map) {
      const obj = {};
      map.forEach(function (v, k) {
        obj[k] = v;
      });
      return obj;
    }

    const code = args.join(" ");
    if (!code) return reply("⚠️ يرجى كتابة الأكواد البرمجية المطلوب تنفيذها واختبارها.");
    
    // صياغة الكود داخل دالة مجهولة غير متزامنة (Async IIFE) لالتقاط الأخطاء بسلاسة
    const cmd = `
    (async () => {
      try {
        ${code}
      }
      catch(err) {
        logger.error("Eval error:", err);
        reply("❌ حدث خطأ أثناء تنفيذ الكود:\\n" + (err.stack || JSON.stringify(err, null, 2)));
      }
    })()
  `;
  
    try {
      await eval(cmd);
    } catch (err) {
      logger.error("Eval error:", err);
      reply(`❌ خطأ في بنية الأمر السطري:\n${err}`);
    }
  },
};
