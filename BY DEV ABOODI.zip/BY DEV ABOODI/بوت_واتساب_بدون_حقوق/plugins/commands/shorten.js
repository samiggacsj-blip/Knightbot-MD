const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "tts",
    aliases: ["صوت", "انطق", "قول", "تكلم", "تحدث", "نطق"],
    version: "1.0",
    author: "@anbuinfosec",
    description: "تحويل النصوص المكتوبة إلى مقاطع ورسائل صوتية مسموعة",
    category: "tools",
    guide: "{pn} <النص> - لنطق النص باللغة الإنجليزية الافتراضية"
			+ "\n{pn} -lc <رمز_اللغة> <النص> - لنطق النص بلغة محددة (مثال للغة العربية: ar)"
			+ "\n\n💡 أمثلة على الاستخدام:"
			+ "\n{pn} Hello members"
			+ "\n{pn} -lc ar أهلاً بكم في المجموعة",
  },

  onStart: async function ({ args, reply, react }) {
    if (!args[0]) {
      const prefix = global.config?.prefix || ".";
      return reply(`🗣️ يرجى كتابة النص المراد تحويله إلى صوت.\n💡 مثال: \`${prefix}tts Hello world!\`\n💡 للنطق بالعربية: \`${prefix}tts -lc ar مرحباً بكم\``);
    }

    let lang = "en"; // اللغة الافتراضية للنطق (الإنجليزية)
    let text = args.join(" ");

    // التحقق مما إذا كان المستخدم قد حدد رمز لغة مخصص (مثل -lc ar)
    if (args[0] === "-lc") {
      lang = args[1];
      text = args.slice(2).join(" ");
    }

    if (!text) return reply("❌ لم يتم العثور على أي نص لنطقه بعد رمز اللغة المختار.");

    try {
      await react("🔊");

      // رابط توليد الصوت عبر محرك تحويل النصوص من جوجل (Google TTS API)
      const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(
        text
      )}&tl=${lang}&client=tw-ob`;

      // إنشاء المجلد المؤقت (tmp) إن لم يكن موجوداً لحفظ الملف الصوتي فيه
      const tmpDir = path.join(__dirname, "tmp");
      if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
      }

      const filePath = path.join(tmpDir, `tts_${Date.now()}.mp3`);

      // جلب البيانات الصوتية كـ ArrayBuffer من خوادم جوجل وحفظها في السيرفر مؤقتاً
      const res = await axios.get(url, { responseType: "arraybuffer" });
      fs.writeFileSync(filePath, res.data);

      const audioBuffer = fs.readFileSync(filePath);

      // إرسال المقطع الصوتي كرسالة صوتية مباشرة (PTT: Push To Talk) في الواتساب
      await reply({
        audio: audioBuffer,
        mimetype: "audio/mpeg",
        ptt: true,
      });

      // حذف الملف المؤقت فوراً من السيرفر بعد الإرسال للمحافظة على مساحة التخزين
      fs.unlinkSync(filePath);
      await react("✅");
    } catch (err) {
      console.error("TTS Error:", err);
      await react("❌");
      reply("❌ فشل خادم تحويل النصوص في توليد المقطع الصوتي حالياً، يرجى المحاولة لاحقاً.");
    }
  },
};
