const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "warn",
    aliases: ["warning", "إنذار", "انذار", "مخالفة", "مخالفه", "تحذير", "عاقب"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 1, // متاح فقط للمشرفين وإداريي البوت
    description: "نظام التحذيرات والإنذارات الرقابي للمجموعات - 3 تحذيرات = طرد تلقائي",
    category: "moderation",
    guide: "{pn} @منشن [السبب] - لتوجيه تحذير وإنذار لعضو مخترق للقوانين\n"
         + "{pn} حذف @منشن - لإزالة وإسقاط تحذير واحد عن العضو\n"
         + "{pn} قائمة @منشن - لعرض سجل وتاريخ تحذيرات العضو بالتفصيل\n"
         + "{pn} تصفير @منشن - لمسح وإلغاء كافة التحذيرات السابقة عن العضو"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const threadId = message.key.remoteJid;
      const isGroup = threadId.endsWith("@g.us");
      const isAdmin = config.admins.includes(senderJid);
      
      // التحقق من صلاحيات مرسل الأمر في البوت
      if (!isAdmin) {
        return reply("❌ عذراً، ليس لديك الصلاحية الكافية لاستخدام نظام التحذيرات.");
      }
      
      const action = args[0]?.toLowerCase();
      const mentionedUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      
      if (!mentionedUser) {
        return reply("❌ يرجى الإشارة (منشن) للعضو المستهدف.\n💡 طريقة الاستخدام: .warn @منشن [السبب]");
      }
      
      // منع توجيه التحذيرات لمطوري وإداريي البوت الأساسيين
      if (config.admins.includes(mentionedUser)) {
        return reply("❌ خطأ أمني: لا يمكن توجيه تحذيرات أو إنذارات لإداريي ومطوري البوت.");
      }
      
      // جلب بيانات العضو المستهدف من قاعدة البيانات
      const userData = await DataUtils.getUser(mentionedUser);
      
      // [1] مسار إزالة وإسقاط تحذير واحد (Remove / حذف)
      if (["remove", "حذف", "ازالة", "إزالة", "انقص"].includes(action)) {
        if (userData.warnings <= 0) {
          return reply("❌ هذا العضو لم يتلقى أي تحذيرات مسبقاً لإزالتها.");
        }
        
        const newWarnings = Math.max(0, userData.warnings - 1);
        await DataUtils.updateUser(mentionedUser, { warnings: newWarnings });
        
        const removeMessage = `✅ *تم إسقاط تحذير بنجاح*\n\n` +
                             `👤 *العضو:* ${userData.name || "عضو غير معروف"}\n` +
                             `⚠️ *التحذيرات الحالية:* ${newWarnings}/3\n` +
                             `👮 *بواسطة المشرف:* ${message.pushName || "إداري"}\n` +
                             `🕐 *التاريخ:* ${new Date().toLocaleString('ar-EG')}`;
        
        await reply(removeMessage);
        logger.info(`Warning removed from ${userData.name} (${mentionedUser}) by ${senderJid}`);
        return;
      }
      
      // [2] مسار عرض سجل التحذيرات والتاريخ (List / قائمة) - (تم إصلاح الجزء المقطوع هنا)
      if (["list", "قائمة", "قائمه", "سجل", "فحص"].includes(action)) {
        const warningHistory = userData.warningHistory || [];
        
        if (!userData.warnings || userData.warnings === 0) {
          return reply(`✅ العضو [ ${userData.name || "المستهدف"} ] سجلّه نظيف تماماً ولا يمتلك أي تحذيرات.`);
        }
        
        let warningList = `⚠️ *سجل المخالفات والتحذيرات لـ ${userData.name || "العضو"}*\n\n`;
        warningList += `📊 *إجمالي التحذيرات:* ${userData.warnings}/3\n\n`;
        
        if (warningHistory.length > 0) {
          warningHistory.forEach((warning, index) => {
            warningList += `📍 *المخالفة رقم ${index + 1}:* ${warning.reason}\n`;
            warningList += `   • المشرف: ${warning.adminName || "إداري"}\n`;
            warningList += `   • التاريخ: ${new Date(warning.date).toLocaleString('ar-EG')}\n\n`;
          });
        }
        
        return reply(warningList);
      }
      
      // [3] مسار تصفير وإلغاء كافة التحذيرات (Clear / تصفير)
      if (["clear", "تصفير", "مسح", "العفو"].includes(action)) {
        await DataUtils.updateUser(mentionedUser, { 
          warnings: 0,
          warningHistory: []
        });
        
        const clearMessage = `✅ *تم العفو وتصفير السجل الرقابي*\n\n` +
                            `👤 *العضو:* ${userData.name || "عضو غير معروف"}\n` +
                            `👮 *بواسطة المشرف:* ${message.pushName || "إداري"}\n` +
                            `🕐 *التاريخ:* ${new Date().toLocaleString('ar-EG')}`;
        
        await reply(clearMessage);
        logger.info(`All warnings cleared for ${userData.name} (${mentionedUser}) by ${senderJid}`);
        return;
      }
      
      // [4] المسار الأساسي: إضافة وتوجيه تحذير جديد للعضو (Add Warning)
      let reasonArgs = [...args];
      // تنظيف المدخلات في حال كتابة كلمات فرعية اختيارية
      if (["add", "إضافة", "اضافه", "جديد"].includes(reasonArgs[0]?.toLowerCase())) {
        reasonArgs.shift();
      }
      
      const reason = reasonArgs.join(" ") || "مخالفة القوانين والشروط العامة للمجموعة";
      const newWarnings = (userData.warnings || 0) + 1;
      const warningHistory = userData.warningHistory || [];
      
      // إضافة تفاصيل المخالفة إلى المصفوفة التاريخية
      warningHistory.push({
        reason: reason,
        adminName: message.pushName || "Admin",
        adminId: senderJid,
        date: Date.now()
      });
      
      await DataUtils.updateUser(mentionedUser, { 
        warnings: newWarnings,
        warningHistory: warningHistory
      });
      
      let warningMessage = `⚠️ *[ إنذار وتحذير جديد في النظام ]*\n\n` +
                          `👤 *العضو المخالف:* ${userData.name || "عضو غير معروف"}\n` +
                          `📝 *سبب المخالفة:* ${reason}\n` +
                          `⚠️ *عداد التحذيرات:* ${newWarnings}/3\n` +
                          `👮 *بواسطة المشرف:* ${message.pushName || "إداري"}\n` +
                          `🕐 *التاريخ الحالي:* ${new Date().toLocaleString('ar-EG')}`;
      
      // التحقق من وصول المخالفات للحد الأقصى (3 تحذيرات) وتفعيل الطرد التلقائي
      if (newWarnings >= 3 && isGroup) {
        try {
          // تنفيذ أمر الطرد النهائي عبر الـ API
          await api.groupParticipantsUpdate(threadId, [mentionedUser], "remove");
          
          // تحديث قائمة الأعضاء النشطين في قاعدة البيانات للمجموعة
          const threadData = await DataUtils.getThread(threadId);
          const updatedParticipants = threadData.participants.filter(p => p !== mentionedUser);
          await DataUtils.updateThread(threadId, {
            participants: updatedParticipants,
            lastActivity: Date.now()
          });
          
          // إعادة تعيين العداد للصفر لضمان تصفير البيانات عند العودة مستقبلاً
          await DataUtils.updateUser(mentionedUser, { warnings: 0 });
          
          warningMessage += `\n\n🚨 *تفعيل الطرد التلقائي (AUTO-KICK)* 🚨\n`;
          warningMessage += `👢 تم طرد العضو فوراً من المجموعة لتجاوزه الحد المسموح به (3 تحذيرات)!`;
          
          logger.info(`User auto-kicked: ${userData.name} (${mentionedUser}) for 3 warnings`);
          
        } catch (error) {
          logger.error("Error auto-kicking user:", error);
          warningMessage += `\
