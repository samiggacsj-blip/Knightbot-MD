const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "promote",
    aliases: ["admin", "ترقية", "ترقيه", "رفع", "مشرف", "ادمن", "أدمن"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 1,
    description: "ترقية عضو ومنحه صلاحيات المشرف (Admin) داخل المجموعة",
    category: "moderation",
    guide: "{pn} @منشن - لرفع العضو إلى رتبة مشرف عبر الإشارة إليه"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const threadId = message.key.remoteJid;
      const isGroup = threadId.endsWith("@g.us");
      const isAdmin = config.admins.includes(senderJid);
      
      if (!isGroup) {
        return reply("❌ يمكن استخدام هذا الأمر داخل المجموعات فقط.");
      }
      
      if (!isAdmin) {
        return reply("❌ ليس لديك الصلاحية الكافية لاستخدام هذا الأمر.");
      }
      
      // جلب معرف العضو المشار إليه (منشن)
      const mentionedUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (!mentionedUser) {
        const prefix = global.config?.prefix || ".";
        return reply(`❌ يرجى الإشارة (منشن) للعضو المراد ترقيته.\n💡 طريقة الاستخدام: \`${prefix}promote @منشن\` أو \`${prefix}ترقية @منشن\``);
      }
      
      // التحقق من وجود العضو داخل المجموعة حالياً
      const threadData = await DataUtils.getThread(threadId);
      if (!threadData.participants.includes(mentionedUser)) {
        return reply("❌ هذا العضو ليس موجوداً في هذه المجموعة.");
      }
      
      try {
        // ترقية العضو إلى مشرف في المجموعة عبر الـ API الخاص بالواتساب
        await api.groupParticipantsUpdate(threadId, [mentionedUser], "promote");
        
        // تحديث مصفوفة المشرفين في قاعدة بيانات المجموعة
        const updatedAdmins = [...(threadData.admins || []), mentionedUser];
        await DataUtils.updateThread(threadId, {
          admins: updatedAdmins,
          lastActivity: Date.now()
        });
        
        // جلب بيانات العضو الإضافية
        const userData = await DataUtils.getUser(mentionedUser);
        
        const promoteMessage = `👑 *تم ترقية العضو بنجاح* 👑\n\n` +
                              `👤 العضو: ${userData.name || "غير معروف"}\n` +
                              `🆔 المعرف: ${mentionedUser}\n` +
                              `👮 بواسطة المشرف: ${message.pushName || "المطور المسؤول"}\n` +
                              `🕐 الوقت: ${new Date().toLocaleString()}\n\n` +
                              `✅ تهانينا! أصبح العضو المذكور مشرفاً (Admin) في المجموعة الآن.`;
        
        await reply(promoteMessage);
        
        logger.info(`تم ترقية المستخدم: ${userData.name} (${mentionedUser}) في المجموعة ${threadId} بواسطة ${senderJid}`);
        
      } catch (error) {
        logger.error("خطأ أثناء محاولة ترقية العضو:", error);
        await reply("❌ فشل ترقية العضو. يرجى التأكد من أن البوت يملك صلاحيات المشرف (Admin) أولاً.");
      }
      
    } catch (error) {
      logger.error("خطأ عام في أمر الترقية (promote):", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة أمر الترقية.");
    }
  }
};
