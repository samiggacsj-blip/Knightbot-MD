module.exports = {
  config: {
    name: "auth",
    aliases: ["login", "session", "توثيق", "جلسة", "تسجيل", "دخول"],
    version: "1.0",
    author: "@anbuinfosec",
    countDown: 5,
    role: 2, // متاح لمطور البوت الإداري فقط
    description: "إدارة عملية مصادقة وجلسة اتصال البوت",
    category: "Admin",
    guide: "{pn} [info|clear|restart] أو [معلومات|مسح|اعادة]",
  },

  onCmd: async ({ api, message, args, reply, user, role, utils, logger }) => {
    const action = args[0]?.toLowerCase()

    // فحص الإجراء المطلوب مع دعم الكامل للغتين العربية والإنجليزية
    switch (action) {
      case "info":
      case "معلومات":
      case "فحص":
        const authInfo = `🔐 *معلومات التوثيق والمصادقة*

📱 *طريقة الربط:* ${global.GoatBot.authMethod || "غير معروفة"}
✅ *صلاحية الجلسة:* ${global.GoatBot.sessionValid ? "صالحة ونشطة" : "غير صالحة"}
🔗 *حالة الاتصال:* ${global.GoatBot.isConnected ? "متصل" : "غير متصل"}
📊 *الوضع الحالي:* ${global.GoatBot.connectionStatus}
⏰ *عمر الجلسة الراهنة:* ${Math.floor((Date.now() - global.GoatBot.startTime) / 1000)} ثانية

🌐 *لوحة التحكم:* http://localhost:3000`

        await reply(authInfo)
        break

      case "clear":
      case "clear":
      case "مسح":
      case "حذف":
        await reply("⚠️ تنبيه: سيؤدي هذا الإجراء إلى مسح بيانات الجلسة بالكامل وطلب إعادة المصادقة. سيقوم البوت بإعادة التشغيل تلقائياً خلال ثانيتين.")
        setTimeout(() => {
          process.exit(2) // إطلاق أمر إعادة التشغيل للنظام
        }, 2000)
        break

      case "restart":
      case "اعادة":
      case "إعادة":
      case "تشغيل":
        await reply("🔄 جاري إعادة تشغيل عملية الاتصال والمصادقة الآن...")
        setTimeout(() => {
          process.exit(2) // إطلاق أمر إعادة التشغيل للنظام
        }, 1000)
        break

      default:
        const helpText = `🔐 *أوامر إدارة المصادقة والجلسات*

📋 *الإجراءات المتاحة للاستخدام:*
• \`${global.config?.prefix || "."}auth info\` أو \`معلومات\` - لعرض تفاصيل وحالة الجلسة الحالية
• \`${global.config?.prefix || "."}auth clear\` أو \`مسح\` - لحذف ومسح بيانات الجلسة وإعادة الربط
• \`${global.config?.prefix || "."}auth restart\` أو \`اعادة\` - لإعادة تشغيل عملية الاتصال والتوثيق

🌐 *لوحة التحكم:* http://localhost:3000`

        await reply(helpText)
    }
  },
}
