const moment = require("moment-timezone");

module.exports = {
	config: {
		name: "daily",
		aliases: ["يومي", "هدية", "هديه", "راتب", "مكافأة", "مكافاه"],
		version: "1.2",
		author: "@anbuinfosec",
		countDown: 5,
		role: 0,
		description: "استلام المكافأة والهدية المالية اليومية",
		category: "economy",
		guide: "{pn}: للحصول على الهدية اليومية مباشرة\n{pn} info أو معلومات: لعرض جدول المكافآت الأسبوعي",
		envConfig: {
			rewardFirstDay: {
				coin: 100,
				exp: 10
			}
		}
	},

	onStart: async function ({ args, message, event, envCommands, usersData, commandName }) {
		const reward = envCommands[commandName].rewardFirstDay;
		
		// دعم فحص وعرض جدول المعلومات باللغتين العربية والإنجليزية
		if (args[0] == "info" || args[0] == "معلومات" || args[0] == "جدول") {
			let msg = "📅 *جدول المكافآت والجوائز الأسبوعية:*\n\n";
			for (let i = 1; i < 8; i++) {
				const getCoin = Math.floor(reward.coin * (1 + 20 / 100) ** ((i == 0 ? 7 : i) - 1));
				const getExp = Math.floor(reward.exp * (1 + 20 / 100) ** ((i == 0 ? 7 : i) - 1));
				const day = i == 7 ? "الأحد" :
					i == 6 ? "السبت" :
						i == 5 ? "الجمعة" :
							i == 4 ? "الخميس" :
								i == 3 ? "الأربعاء" :
									i == 2 ? "الثلاثاء" :
										"الإثنين";
				msg += `• *${day}:* 💵 ${getCoin} عملة | ⭐ ${getExp} خبرة\n`;
			}
			return message.reply(msg);
		}

		// تعيين المنطقة الزمنية العربية (توقيت القاهرة كمثال افتراضي متوافق)
		const dateTime = moment.tz("Africa/Cairo").format("DD/MM/YYYY");
		const date = new Date();
		const currentDay = date.getDay(); // 0: الأحد, 1: الإثنين, 2: الثلاثاء, 3: الأربعاء, 4: الخميس, 5: الجمعة, 6: السبت
		const { senderID } = event;

		const userData = await usersData.get(senderID);
		
		// التحقق مما إذا كان العضو قد استلم هدية اليوم بالفعل
		if (userData.data.lastTimeGetReward === dateTime)
			return message.reply("❌ لقد قمت باستلام مكافأتك اليومية بالفعل! عد مجدداً غداً.");

		// احتساب الجائزة بناءً على اليوم الحالي عبر المعادلة الرياضية الخاصة بالملف الأصلي
		const getCoin = Math.floor(reward.coin * (1 + 20 / 100) ** ((currentDay == 0 ? 7 : currentDay) - 1));
		const getExp = Math.floor(reward.exp * (1 + 20 / 100) ** ((currentDay == 0 ? 7 : currentDay) - 1));
		
		// تحديث بيانات تاريخ الاستلام لمنع التكرار في نفس اليوم
		userData.data.lastTimeGetReward = dateTime;
		
		await usersData.set(senderID, {
			money: userData.money + getCoin,
			exp: userData.exp + getExp,
			data: userData.data
		});
		
		message.reply(`🎁 *مبروك! تم استلام هديتك اليومية بنجاح:*\n\n💵 تم إضافة: +${getCoin} عملة نقدية\n⭐ تم إضافة: +${getExp} نقطة خبرة (Exp)`);
	}
};
