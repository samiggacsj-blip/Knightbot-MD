module.exports = {
  config: {
    name: "prefix",
    aliases: ["pf", "بادئة", "بادئه", "البادئة", "البادئه", "علامة", "علامه", "الرمز", "رمز"],
    version: "1.0",
    author: "@anbuinfosec",
    countDown: 3,
    role: 0, // متاح لجميع الأعضاء
    description: "عرض رمز بادئة البوت الحالي عند الاستعلام عنه",
    category: "Info",
    guide: "{pn} أو اكتب كلمة 'بادئة' أو 'prefix' مباشرة في الشات بدون رموز",
  },

  // المعالج الأساسي: يتم تشغيله عند كتابة الأمر مع البادئة (مثال: .prefix)
  onCmd: async ({ api, message, reply, user, thread, role, utils, logger }) => {
    const config = require("../../config.json");
    const prefix = config.prefix || ".";
    
    await reply(`🤖 *معلومات بادئة البوت (Prefix)*\n\n` +
               `🔧 الرمز الحالي المعتمد: \`${prefix}\`\n` +
               `📝 طريقة الاستخدام: أكتب \`${prefix}help\` لعرض قائمة جميع الأوامر المتاحة.\n` +
               `💡 تلميح: يمكنك أيضاً كتابة كلمة "بادئة" كرسالة عادية في المجموعة لعرض هذه الرسالة.`);
  },

  // معالج الدردشة: يتم تشغيله تلقائياً عند كتابة الكلمة مباشرة في الشات بدون أي رموز
  onChat: async ({ api, message, reply, user, thread, role, utils, logger }) => {
    const messageText = (message.message?.conversation || "").toLowerCase().trim();
    
    // مصفوفة تحتوي على الكلمات الدلالية باللغتين العربية والإنجليزية لتفعيل الرد التلقائي
    const triggerWords = ["prefix", "بادئة", "بادئه", "البادئة", "البادئه", "الرمز", "رمز البوت"];
    
    if (triggerWords.includes(messageText)) {
      const config = require("../../config.json");
      const prefix = config.prefix || ".";
      
      await reply(`🤖 *رمز تشغيل الأوامر الخاص بي هو:* \`${prefix}\`\n\n` +
                 `📝 تصفح الأوامر: أكتب \`${prefix}help\` - لعرض القائمة كاملة\n` +
                 `💡 مثال للتجربة: \`${prefix}ping\` - لفحص سرعة استجابة البوت`);
    }
  }
};
