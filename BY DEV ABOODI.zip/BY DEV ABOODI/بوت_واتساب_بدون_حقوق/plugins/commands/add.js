const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "add",
    aliases: ["invite", "اضافه", "إضافة", "اضافة", "دعوة", "ضيف"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 1,
    description: "إضافة عضو جديد إلى المجموعة",
    category: "moderation",
    guide: "{pn} [رقم_الهاتف] - لإضافة العضو عن طريق رقم هاتفه مع رمز الدولة\n{pn} @منشن - لإضافة العضو عبر الإشارة إليه (إذا كان في جهات اتصال البوت)"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const threadId = message.key.remoteJid;
      const isGroup = threadId.endsWith("@g.us");
      const isAdmin = config.admins.includes(senderJid);
      
      if (!isGroup) {
        return reply("❌ يمكن استخدام هذا الأمر داخل المجموعات فقط.");
      }
      
      if (!isAdmin) {
        return reply("❌ ليس لديك الصلاحية الكافية لاستخدام هذا الأمر.");
      }
      
      if (args.length === 0) {
        const prefix = global.config?.prefix || ".";
        return reply(`❌ يرجى تحديد رقم هاتف أو إدراج منشن للعضو المراد إضافته.\n💡 طريقة الاستخدام: \`${prefix}add [رقم_الهاتف]\` أو \`${prefix}add @منشن\``);
      }
      
      let userToAdd;
      
      // التحقق مما إذا كان المستخدم قد أشار (منشن) لشخص ما
      const mentionedUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (mentionedUser) {
        userToAdd = mentionedUser;
      } else {
        // التعامل مع المدخل كرقم هاتف
        const phoneNumber = args[0].replace(/\D/g, ""); // إزالة أي رموز أو أحرف غير رقمية
        if (phoneNumber.length < 10) {
          return reply("❌ يرجى إدخال رقم هاتف صحيح مع رمز الدولة.");
        }
        
        // تحويل وتنسيق رقم الهاتف إلى معرف واتساب الافتراضي
        userToAdd = `${phoneNumber}@s.whatsapp.net`;
      }
      
      // التحقق مما إذا كان العضو موجوداً بالفعل في المجموعة
      const threadData = await DataUtils.getThread(threadId);
      if (threadData.participants.includes(userToAdd)) {
        return reply("❌ هذا العضو موجود بالفعل داخل هذه المجموعة.");
      }
      
      try {
        // إرسال طلب إضافة العضو إلى المجموعة عبر الـ API
        await api.groupParticipantsUpdate(threadId, [userToAdd], "add");
        
        // تحديث بيانات المجموعة في قاعدة البيانات
        const updatedParticipants = [...threadData.participants, userToAdd];
        await DataUtils.updateThread(threadId, {
          participants: updatedParticipants,
          lastActivity: Date.now()
        });
        
        // جلب بيانات العضو المضاف
        const userData = await DataUtils.getUser(userToAdd);
        
        const addMessage = `✅ *تم إضافة العضو بنجاح*\n\n` +
                          `👤 العضو: ${userData.name || "غير معروف"}\n` +
                          `🆔 المعرف: ${userToAdd}\n` +
                          `👮 بواسطة المشرف: ${message.pushName || "المطور المسؤول"}\n` +
                          `🕐 الوقت: ${new Date().toLocaleString()}`;
        
        await reply(addMessage);
        
        logger.info(`تم إضافة العضو: ${userData.name} (${userToAdd}) للمجموعة ${threadId} بواسطة ${senderJid}`);
        
      } catch (error) {
        logger.error("خطأ أثناء محاولة إضافة العضو للمجموعة:", error);
        
        let errorMessage = "❌ فشل إضافة العضو للمجموعة. ";
        if (error.message.includes("privacy")) {
          errorMessage += "إعدادات الخصوصية الخاصة بهذا العضو تمنع إضافته للمجموعات.";
        } else if (error.message.includes("not_authorized")) {
          errorMessage += "البوت لا يملك صلاحيات المشرف (Admin) في هذه المجموعة.";
        } else if (error.message.includes("forbidden")) {
          errorMessage += "هذا العضو قام بحظر البوت أو أن الرقم غير موجود في الواتساب.";
        } else {
          errorMessage += "يرجى التحقق من صحة الرقم والمحاولة مرة أخرى لاحقاً.";
        }
        
        await reply(errorMessage);
      }
      
    } catch (error) {
      logger.error("خطأ عام في أمر الإضافة (add):", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة أمر الإضافة.");
    }
  }
};
