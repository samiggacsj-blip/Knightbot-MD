const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "leaderboard",
    aliases: ["top", "rank", "lb", "صدارة", "صداره", "ترتيب", "الترتيب", "توب", "المراكز"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 0,
    description: "عرض قائمة الترتيب والمراكز الأولى للمستخدمين حسب المستوى أو الخبرة أو الرسائل",
    category: "info",
    guide: "{pn} [مستوى/خبرة/رسائل] [عام/مجموعة]"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      // تعيين القيم الافتراضية مع دعم الكلمات العربية والإنجليزية
      const inputType = args[0]?.toLowerCase() || "level";
      const inputScope = args[1]?.toLowerCase() || "global";
      
      // تحويل المدخلات العربية إلى الإنجليزية لتتوافق مع منطق الكود الداخلي
      let type = "level";
      if (["exp", "خبرة", "خبره"].includes(inputType)) type = "exp";
      else if (["messages", "رسائل", "الرسائل"].includes(inputType)) type = "messages";
      else if (["level", "مستوى", "المستوى"].includes(inputType)) type = "level";
      else {
        return reply("❌ نوع الترتيب غير صحيح. يرجى استخدام: (مستوى / خبرة / رسائل)");
      }

      let scope = "global";
      if (["group", "مجموعة", "مجموعه", "الجروب"].includes(inputScope)) scope = "group";
      else if (["global", "عام", "العام"].includes(inputScope)) scope = "global";
      else {
        return reply("❌ نطاق البحث غير صحيح. يرجى استخدام: (عام / مجموعة)");
      }

      const threadId = message.key.remoteJid;
      const isGroup = threadId.endsWith("@g.us");
      
      if (scope === "group" && !isGroup) {
        return reply("❌ لوحة صدارة المجموعة يمكن استدعاؤها داخل المجموعات فقط.");
      }
      
      // جلب جميع المستخدمين من قاعدة البيانات
      const allUsers = await db.getAllUsers();
      let users = [];
      
      // تصفية المستخدمين بناءً على النطاق المحدد
      if (scope === "group") {
        const threadData = await DataUtils.getThread(threadId);
        for (const userId of threadData.participants) {
          const userData = allUsers[`user_${userId}`];
          if (userData) {
            users.push(userData);
          }
        }
      } else {
        users = Object.values(allUsers);
      }
      
      // إعداد حقول الفرز والأيقونات التعبيرية بناءً على النوع
      let sortField = "level";
      let emoji = "⭐";
      let typeLabel = "المستوى";
      
      switch (type) {
        case "exp":
          sortField = "experience";
          emoji = "📊";
          typeLabel = "نقاط الخبرة";
          break;
        case "messages":
          sortField = "messageCount";
          emoji = "💬";
          typeLabel = "عدد الرسائل";
          break;
        case "level":
          sortField = "level";
          emoji = "⭐";
          typeLabel = "المستوى الحالي";
          break;
      }
      
      // فرز ترتيب المستخدمين تنازلياً من الأعلى للأقل
      users.sort((a, b) => (b[sortField] || 0) - (a[sortField] || 0));
      
      // استخراج العشرة الأوائل فقط
      const top10 = users.slice(0, 10);
      
      if (top10.length === 0) {
        return reply("❌ لم يتم العثور على سجلات مستخدمين لعرضها في لوحة الصدارة.");
      }
      
      // صياغة وعرض لوحة الصدارة بشكل منسق وجذاب
      let leaderboard = `🏆 *قائمة المتصدرين في ${typeLabel} (${scope === "group" ? "على مستوى المجموعة" : "على المستوى العام"})*\n\n`;
      
      for (let i = 0; i < top10.length; i++) {
        const user = top10[i];
        const position = i + 1;
        const medal = position === 1 ? "🥇" : position === 2 ? "🥈" : position === 3 ? "🥉" : `${position}.`;
        
        leaderboard += `${medal} ${user.name || "عضو غير معروف"}\n`;
        leaderboard += `   ${emoji} ${user[sortField] || 0}`;
        
        if (type === "level") {
          leaderboard += ` (${user.experience || 0} خبرة)`;
        }
        
        leaderboard += "\n";
      }
      
      // إضافة مركز المستخدم الحالي التنافسي إذا لم يكن ضمن قائمة الـ 10 الأوائل
      const senderJid = message.key.participant || message.key.remoteJid;
      const senderData = await DataUtils.getUser(senderJid);
      const senderPosition = users.findIndex(u => u.id === senderJid) + 1;
      
      if (senderPosition > 10) {
        leaderboard += `\n📍 *مركزك الحالي:* #${senderPosition}\n`;
        leaderboard += `   ${emoji} ${senderData[sortField] || 0}`;
        if (type === "level") {
          leaderboard += ` (${senderData.experience || 0} خبرة)`;
        }
      }
      
      await reply(leaderboard);
      
    } catch (error) {
      logger.error("Error in leaderboard command:", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء توليد وحساب لوحة الصدارة.");
    }
  }
};
