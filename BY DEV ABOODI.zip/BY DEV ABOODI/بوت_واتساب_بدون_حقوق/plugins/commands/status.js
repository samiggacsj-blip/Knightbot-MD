module.exports = {
  config: {
    name: "status",
    aliases: ["stats", "info", "الحالة", "الحاله", "حالة_البوت", "حاله_البوت", "الفحص", "الوضع"],
    version: "1.0",
    author: "@anbuinfosec",
    countDown: 3,
    role: 0, // متاح لجميع الأعضاء
    description: "عرض حالة اتصال البوت الحالية وإحصائيات سريعة عن السيرفر",
    category: "Utility",
    guide: "{pn}",
  },

  onCmd: async ({ reply, user, thread, role, utils, logger }) => {
    // حساب المدة الزمنية لتشغيل السيرفر وتحويلها إلى ساعات ودقائق وثوانٍ
    const uptime = Date.now() - global.GoatBot.startTime;
    const hours = Math.floor(uptime / (1000 * 60 * 60));
    const minutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((uptime % (1000 * 60)) / 1000);

    // صياغة تقرير الحالة بالكامل باللغة العربية
    const status = `🐐 *حالة نظام البوت الحالية (Status)*

🔗 *اتصال الخادم:* ${global.GoatBot.isConnected ? "✅ متصل ونشط" : "❌ غير متصل"}
⏰ *مدة تشغيل السيرفر:* ${hours} ساعة و ${minutes} دقيقة و ${seconds} ثانية
📊 *الرسائل التي تمت معالجتها:* ${global.GoatBot.stats.messagesProcessed}
⚡ *الأوامر المنفذة بنجاح:* ${global.GoatBot.stats.commandsExecuted}
❌ *الأخطاء البرمجية المرصودة:* ${global.GoatBot.stats.errors}
📦 *الأوامر (Commands) المحملة:* ${global.GoatBot.commands.size}
🎭 *الأحداث (Events) المحملة:* ${global.GoatBot.events.size}`;

    await reply(status);
  },
};
