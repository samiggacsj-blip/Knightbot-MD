const fs = require('fs');
const path = require('path');

module.exports = {
    config: {
        name: "rank",
        aliases: ["level", "exp", "xp", "رتبتي", "مستواي", "لفلي", "لفل", "خبرة", "خبره"],
        description: "عرض بطاقة الرتبة، المستوى الحالي، ونقاط الخبرة للعضو",
        guide: "{pn} أو {pn} @منشن لعرض رتبة عضو آخر",
        author: "@anbuinfosec",
        role: 0,
        cooldown: 5,
        countDown: 5,
        category: "info"
    },

    onStart: async ({ message, event, args, user, thread, utils, api, getLang }) => {
        try {
            const { threadID, senderID } = event;
            let targetID = senderID;
            
            // التحقق مما إذا كان المستخدم قد أشار إلى شخص آخر (منشن)
            if (event.mentions && Object.keys(event.mentions).length > 0) {
                targetID = Object.keys(event.mentions)[0];
            }
            
            // جلب بيانات العضو المستهدف من قاعدة البيانات
            const userData = await user.getUser(targetID);
            const userName = userData.name || "عضو غير معروف";
            
            // احتساب المستوى الحالي ونقاط الخبرة بناءً على المعادلة المعتمدة في الكود الأصلي
            const experience = userData.exp || 0;
            const level = Math.floor(experience / 100) + 1;
            const expForNext = (level * 100) - experience;
            const expProgress = experience - ((level - 1) * 100);
            
            // جلب الترتيب والمراكز العامة وفرزها تنازلياً
            const allUsers = await user.getAllUsers();
            const sortedUsers = allUsers.sort((a, b) => (b.exp || 0) - (a.exp || 0));
            const rank = sortedUsers.findIndex(u => u.uid === targetID) + 1;
            
            // إنشاء ورسم شريط التقدم الرقمي المستند إلى دالة الرسم بالأسفل
            const progressBar = createProgressBar(expProgress, 100);
            
            // قاموس النصوص الداخلي المترجم بالكامل للغة العربية
            const getText = getLang || ((key, ...args) => {
                const texts = {
                    userRank: "🏆 *بطاقة معلومات الرتبة والمستوى* 🏆\n\n👤 *العضو:* %1\n📊 *المستوى الحالي:* %2\n⭐ *إجمالي الخبرة:* %3 XP\n🎯 *الترتيب العام:* #%4\n📈 *معدل التقدم للفل التالي:* %5/100 XP\n%6\n🔥 *المتبقي لرفع المستوى:* يحتاج %7 XP إضافية\n\n💡 *تلميح:* تفاعل باستمرار في المجموعة لرفع رتبتك ومستواك بشكل أسرع!",
                    userNotFound: "تعذر العثور على بيانات هذا العضو في قاعدة البيانات."
                };
                let text = texts[key] || key;
                args.forEach((arg, index) => {
                    text = text.replace(new RegExp(`%${index + 1}`, 'g'), arg);
                });
                return text;
            });
            
            const rankMessage = getText('userRank', userName, level, experience, rank, expProgress, progressBar, expForNext);
            
            // التحقق ديناميكياً من دالة الرد المتاحة لإرسال الرسالة بسلاسة
            if (typeof reply === 'function') {
                await reply(rankMessage);
            } else {
                await message.reply(rankMessage);
            }
            
        } catch (error) {
            console.error("Error in rank command:", error);
            const errorText = "❌ حدث خطأ غير متوقع أثناء استخراج بطاقة الرتبة والمستوى، يرجى المحاولة لاحقاً.";
            if (typeof reply === 'function') {
                await reply(errorText);
            } else {
                await message.reply(errorText);
            }
        }
    }
};

// دالة هندسة وإنشاء شريط التقدم الرقمي التفاعلي بناءً على النسبة المئوية
function createProgressBar(current, max, length = 20) {
    const percentage = Math.round((current / max) * 100);
    const filledLength = Math.round((current / max) * length);
    const emptyLength = length - filledLength;
    
    const filled = '█'.repeat(filledLength);
    const empty = '░'.repeat(emptyLength);
    
    return `[${filled}${empty}] ${percentage}%`;
}
