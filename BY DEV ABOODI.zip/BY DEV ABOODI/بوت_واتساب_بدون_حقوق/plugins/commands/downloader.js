const axios = require("axios");
const fs = require("fs");
const path = require("path");

module.exports = {
  config: {
    name: "downloader",
    aliases: ["fbdl", "ytdl", "mediadl", "igdl", "twdl", "dl", "تحميل", "تنزيل", "حمل", "فيديو", "صوت"],
    description: "محمل الوسائط العالمي لتحميل مقاطع الفيديو والملفات الصوتية من الروابط",
    author: "anbuinfosec",
    cooldown: 5,
    role: 0,
    category: "media",
    guide: "{pn} -فيديو <الرابط> ← لتحميل مقطع فيديو" + 
    "\n{pn} -صوت <الرابط> ← لتحميل ملف صوتي"
  },

  onCmd: async ({ args, event, reply, react }) => {
    // دعم فحص نوع التحميل باللغتين العربية والإنجليزية
    const isAudioAction = args[0] === "-a" || args[0] === "-صوت" || args[0] === "صوت";
    const type = isAudioAction ? "audio" : "video";
    const url = args[1];

    if (!url?.startsWith("http")) {
      const prefix = global.config?.prefix || "/";
      return reply(
        `❌ يرجى تقديم رابط صحيح يبدأ بـ http.\n💡 طريقة الاستخدام:\n${prefix}downloader -فيديو <الرابط> أو -صوت <الرابط>`
      );
    }

    await react("⏳");
    const apikey = global.GoatBot.config.apikeys?.anbu;
    if (!apikey) {
      await react("❌");
      return reply(
        "❌ مفتاح الواجهة البرمجية (API key) غير معين. يرجى ضبط مفتاح الأبي في الكود."
      );
    }
    const apiUrl = `https://api.anbuinfosec.xyz/api/downloader/download?url=${encodeURIComponent(
      url
    )}&apikey=${apikey}`;

    try {
      const { data } = await axios.get(apiUrl);

      if (!data.success || !data.medias?.length) {
        await react("❌");
        return reply("❌ لم يتم العثور على أي وسائط مدعومة للرابط الذي أرسلته.");
      }

      const selected = getBestMedia(data.medias, type);
      if (!selected?.url) {
        await react("❌");
        return reply(`❌ تعذر العثور على ملف ${(type === "audio" ? "صوتي" : "فيديو")} متاح.`);
      }

      const ext = selected.extension || (type === "audio" ? "m4a" : "mp4");
      const tempDir = path.join(__dirname, "tmp");

      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }

      const tempPath = path.join(tempDir, `media_${Date.now()}.${ext}`);

      const mediaStream = await axios({
        url: selected.url,
        method: "GET",
        responseType: "stream",
      });

      const writer = fs.createWriteStream(tempPath);
      mediaStream.data.pipe(writer);

      writer.on("finish", async () => {
        try {
          await react("✔️");

          // قراءة الملف بالكامل كـ Buffer لتفادي أخطاء إرسال مكتبة Baileys
          const buffer = fs.readFileSync(tempPath);

          await reply({
            [type]: buffer,
            mimetype: type === "audio" ? "audio/mpeg" : "video/mp4",
            caption: `🎬 *العنوان:* ${data.title || "غير متوفر"}\n👤 *الناشر/المؤلف:* ${
              data.author || "غير متوفر"
            }\n📺 *النوع المطلوب:* ${(type === "audio" ? "ملف صوتي (AUDIO)" : "مقطع فيديو (VIDEO)")}`,
          });
        } catch (err) {
          console.error("Failed to send media:", err);
          await react("❌");
          try {
            fs.unlink(tempPath, () => {});
          } catch (unlinkErr) {
            console.error("Failed to delete temp file:", unlinkErr);
          }
          await reply("❌ فشل إرسال ملف الوسائط إلى الدردشة.");
          return;
        } finally {
          // حذف الملف المؤقت دائماً بعد انتهاء المحاولة للحفاظ على المساحة
          fs.unlink(tempPath, () => {});
        }
      });

      writer.on("error", async () => {
        await react("❌");
        await reply("❌ فشل حفظ ملف الوسائط مؤقتاً على الخادم.");
        fs.unlink(tempPath, () => {});
      });
    } catch (err) {
      console.error("Download error:", err);
      await react("❌");
      reply("❌ حدث خطأ غير متوقع أثناء معالجة عملية التحميل.");
    }
  },
};

function getBestMedia(medias, type = "video") {
  const filtered = medias.filter((m) => m.type === type);
  if (!filtered.length) return null;

  if (type === "video") {
    // ترتيب تنازلي لاختيار أعلى دقة فيديو متاحة (Resolution)
    return filtered.sort((a, b) => {
      const resA = parseInt(a.resolution?.split("x")[1] || "0", 10);
      const resB = parseInt(b.resolution?.split("x")[1] || "0", 10);
      return resB - resA;
    })[0];
  } else {
    // ترتيب تنازلي لاختيار أعلى جودة صوت متاحة (Bandwidth)
    return filtered.sort((a, b) => (b.bandwidth || 0) - (a.bandwidth || 0))[0];
  }
}
