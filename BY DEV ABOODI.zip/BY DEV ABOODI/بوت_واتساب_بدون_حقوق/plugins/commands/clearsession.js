const fs = require("fs-extra");
const path = require("path");

module.exports = {
  config: {
    name: "clearsession",
    aliases: ["cs", "clear-session", "حذف_الجلسة", "مسح_الجلسة", "تصفير_الجلسة", "تصفير"],
    description: "مسح ملفات الجلسة الحالية وإعادة تشغيل عملية التوثيق والمصادقة",
    guide: "{pn}",
    author: "@anbuinfosec",
    category: "admin",
    role: 1,
    countDown: 10
  },
  onCmd: async ({ reply, logger }) => {
    try {
      await reply("🔄 جاري مسح ملفات الجلسة الحالية وإعادة تشغيل عملية المصادقة...");
      
      // تحديد مسار مجلد الجلسة (Session Folder)
      const sessionPath = path.join(process.cwd(), "session");
      
      // التحقق من وجود المجلد وحذفه نهائياً في حال العثور عليه
      if (await fs.pathExists(sessionPath)) {
        await fs.remove(sessionPath);
        logger.info("✅ تم مسح وحذف ملفات الجلسة بنجاح من النظام");
      }
      
      // إجبار البوت على إعادة التشغيل قسرياً بعد ثانيتين
      setTimeout(() => {
        process.exit(2); // الخروج برمز إعادة التشغيل المعتمد للنظام
      }, 2000);
      
    } catch (error) {
      logger.error("خطأ أثناء محاولة مسح الجلسة (clearsession):", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء مسح ملفات الجلسة.");
    }
  }
};
