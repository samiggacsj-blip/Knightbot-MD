module.exports = {
	config: {
		name: "uptime",
		aliases: ["up", "التشغيل", "وقت_التشغيل", "الموارد", "السيرفر", "الذاكرة"],
		version: "1.2",
		author: "@anbuinfosec",
		countDown: 5,
		role: 0, // متاح لجميع الأعضاء للاطمئنان على حالة السيرفر
		description: "عرض مدة تشغيل البوت الحية وتحليل استهلاك موارد السيرفر الحالية",
		category: "info",
		guide: "{pn}: لعرض وقت تشغيل نظام البوت ومواصفات البيئة البرمجية الحالية."
	},

	onStart: async function ({ message, event }) {
		// جلب بيانات الموارد ووقت العمل الفعلي من العمليات الأساسية للنظام (Node.js Process)
		const uptime = process.uptime();
		const memoryUsage = Math.round(process.memoryUsage().rss / 1024 / 1024);
		const cpuUsage = Math.round(process.cpuUsage().user / 1000);
		const totalCommands = global.commandsProcessed || 0;
		const os = require('os');
		
		// استدعاء دالة التحويل لتهيئة الوقت بالشكل المقروء وجلب تفاصيل نواة النظام
		const uptimeString = convertUptime(uptime);
		const osInfo = `${os.type()} ${os.release()}`;
		
		// صياغة تقرير الأداء والموارد بالكامل باللغة العربية
		return message.reply(`⏰ *وقت تشغيل البوت:* ${uptimeString}\n` +
		                     `💾 *استهلاك الذاكرة (RAM):* ${memoryUsage} ميجابايت (MB)\n` +
		                     `🔄 *جهد المعالج (CPU):* ${cpuUsage}%\n` +
		                     `📊 *إجمالي الأوامر المعالجة:* ${totalCommands}\n` +
		                     `🌐 *نظام تشغيل السيرفر:* ${osInfo}`);
	}
};

// دالة هندسية مخصصة لتحويل عدد الثواني الخام إلى صيغة أيام، ساعات، دقائق وثوانٍ
function convertUptime(uptime) {
	const days = Math.floor(uptime / 86400);
	const hours = Math.floor((uptime % 86400) / 3600);
	const minutes = Math.floor((uptime % 3600) / 60);
	const seconds = Math.floor(uptime % 60);
	
	let result = "";
	if (days > 0) result += `${days} يوم `;
	if (hours > 0) result += `${hours} ساعة `;
	if (minutes > 0) result += `${minutes} دقيقة `;
	if (seconds > 0) result += `${seconds} ثانية`;
	
	return result.trim() || "0 ثانية";
}
