const DataUtils = require("../../libs/dataUtils");
const { getUserName } = require("../../libs/utils");

module.exports = {
  config: {
    name: "ban",
    aliases: ["block", "حظر", "منع", "بلوك"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 1,
    description: "حظر مستخدم من استخدام البوت",
    category: "moderation",
    guide: "ban @user [السبب] - لحظر مستخدم{pn}\n{pn} ban unban @user - لإلغاء حظر مستخدم\n{pn} ban list - لعرض قائمة المستخدمين المحظورين"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const threadId = message.key.remoteJid;
      const isAdmin = config.admins.includes(senderJid);
      
      if (!isAdmin) {
        return reply("❌ ليس لديك الصلاحية الكافية لاستخدام هذا الأمر.");
      }
      
      const action = args[0]?.toLowerCase();
      
      // دعم الكلمات المفتاحية باللغتين العربية والإنجليزية لإجراء العرض
      if (action === "list" || action === "قائمة" || action === "المحظورين") {
        // عرض قائمة المستخدمين المحظورين
        const allUsers = await db.getAllUsers();
        const bannedUsers = [];
        
        for (const [key, userData] of Object.entries(allUsers)) {
          if (userData.banned) {
            bannedUsers.push({
              name: userData.name || "غير معروف",
              id: userData.id,
              banReason: userData.banReason || "لم يتم تقديم سبب",
              banDate: userData.banDate ? new Date(userData.banDate).toLocaleString() : "غير معروف"
            });
          }
        }
        
        if (bannedUsers.length === 0) {
          return reply("✅ لا يوجد أي مستخدمين محظورين حالياً في النظام.");
        }
        
        let banList = `🚫 *قائمة المستخدمين المحظورين*\n\n`;
        bannedUsers.forEach((user, index) => {
          banList += `${index + 1}. ${user.name}\n`;
          banList += `   المعرف (ID): ${user.id}\n`;
          banList += `   السبب: ${user.banReason}\n`;
          banList += `   التاريخ: ${user.banDate}\n\n`;
        });
        
        return reply(banList);
      }
      
      // دعم الكلمات المفتاحية باللغتين العربية والإنجليزية لإلغاء الحظر
      if (action === "unban" || action === "الغاء" || action === "فك") {
        // إلغاء حظر مستخدم
        const mentionedUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!mentionedUser) {
          return reply("❌ يرجى الإشارة (منشن) للمستخدم المراد إلغاء حظره.\n💡 الاستخدام: ban unban @user أو حظر الغاء @user.");
        }
        
        const userData = await DataUtils.getUser(mentionedUser);
        const userName = await getUserName(mentionedUser, message, api);
        
        if (!userData.banned) {
          return reply("❌ هذا المستخدم ليس محظوراً بالأساس.");
        }
        
        await DataUtils.updateUser(mentionedUser, {
          banned: false,
          banReason: null,
          banDate: null
        });
        
        const unbanMessage = `✅ *تم إلغاء الحظر بنجاح*\n\n` +
                            `👤 المستخدم: ${userName}\n` +
                            `🆔 المعرف (ID): ${mentionedUser}\n` +
                            `👮 بواسطة المشرف: ${message.pushName || "المطور المسؤول"}\n` +
                            `🕐 الوقت: ${new Date().toLocaleString()}`;
        
        await reply(unbanMessage);
        logger.info(`تم إلغاء حظر المستخدم: ${userData.name} (${mentionedUser}) بواسطة ${senderJid}`);
        return;
      }
      
      // تنفيذ عملية الحظر لمطلب جديد (إذا لم تكن المدخلات قائمة أو إلغاء)
      const mentionedUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (!mentionedUser) {
        return reply("❌ يرجى الإشارة (منشن) للمستخدم المراد حظره.\n💡 الاستخدام: ban @user [السبب] أو حظر @user [السبب].");
      }
      
      // التحقق لمنع حظر المشرفين أو مطوري البوت
      if (config.admins.includes(mentionedUser)) {
        return reply("❌ لا يمكن حظر المطورين أو المشرفين المسؤولين عن البوت.");
      }
      
      const reason = args.slice(1).join(" ") || "لم يتم تقديم سبب معين";
      const userData = await DataUtils.getUser(mentionedUser);
      const userName = await getUserName(mentionedUser, message, api);
      
      if (userData.banned) {
        return reply("❌ هذا المستخدم محظور بالفعل.");
      }
      
      await DataUtils.updateUser(mentionedUser, {
        banned: true,
        banReason: reason,
        banDate: Date.now()
      });
      
      const banMessage = `🚫 *تم حظر المستخدم بنجاح*\n\n` +
                        `👤 المستخدم: ${userName}\n` +
                        `🆔 المعرف (ID): ${mentionedUser}\n` +
                        `👮 بواسطة المشرف: ${message.pushName || "المطور المسؤول"}\n` +
                        `📝 السبب: ${reason}\n` +
                        `🕐 الوقت: ${new Date().toLocaleString()}`;
      
      await reply(banMessage);
      logger.info(`تم حظر المستخدم: ${userName} (${mentionedUser}) بواسطة ${senderJid} - السبب: ${reason}`);
      
    } catch (error) {
      logger.error("خطأ في أمر الحظر (ban):", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة أمر الحظر.");
    }
  }
};
