const fs = require('fs');
const path = require('path');

module.exports = {
    config: {
        name: "cmd",
        aliases: ["command", "امر", "أمر", "تحكم", "الأوامر", "الاوامر"],
        description: "إدارة وتحديث ملفات الأوامر (تحميل، إيقاف، إعادة تشغيل، معلومات)",
        guide: "{pn} [تحميل|ايقاف|تحديث|معلومات|قائمة] <اسم_الأمر>",
        author: "@anbuinfosec",
        role: 2,
        cooldown: 3,
        countDown: 3,
        category: "admin"
    },

    onStart: async ({ reply, event, args, utils, role, getLang }) => {
        try {
            const getText = getLang || ((key, ...args) => {
                const texts = {
                    missingAction: "❌ يرجى تحديد الإجراء المطلوب: (تحميل/load، ايقاف/unload، تحديث/reload، معلومات/info، قائمة/list)",
                    missingCommand: "❌ يرجى كتابة اسم ملف الأمر المطلوب.",
                    commandNotFound: "❌ تعذر العثور على الأمر '%1' في المجلد.",
                    commandLoaded: "✅ تم تحميل وتفعيل الأمر '%1' بنجاح في الذاكرة.",
                    commandUnloaded: "✅ تم إيقاف وإلغاء تحميل الأمر '%1' بنجاح.",
                    commandReloaded: "✅ تم إعادة تحديث وتحميل الأمر '%1' بنجاح.",
                    loadError: "❌ حدث خطأ أثناء تحميل الأمر '%1': %2",
                    unloadError: "❌ حدث خطأ أثناء إيقاف الأمر '%1': %2",
                    commandsList: "📋 قائمة الأوامر المتاحة حالياً (%1):\n\n%2",
                    commandInfo: "📖 تفاصيل ومعلومات الأمر:\n\n🏷️ الاسم الافتراضي: %1\n📝 الوصف: %2\n🔧 طريقة الاستخدام: %3\n🔑 الصلاحية المطلوبة: %4\n⏱️ وقت الانتظار: %5 ثواني\n📂 الفئة: %6\n🔗 الأسماء المرادفة: %7"
                };
                let text = texts[key] || key;
                args.forEach((arg, index) => {
                    text = text.replace(new RegExp(`%${index + 1}`, 'g'), arg);
                });
                return text;
            });

            if (!args[0]) {
                return await reply(getText('missingAction'));
            }

            const action = args[0].toLowerCase();
            const commandName = args[1];

            // معالجة الأوامر والتحقق منها باللغتين العربية والإنجليزية
            switch (action) {
                case 'load':
                case 'تحميل':
                    if (!commandName) {
                        return await reply(getText('missingCommand'));
                    }
                    await loadCommand(commandName, reply, getText);
                    break;

                case 'unload':
                case 'ايقاف':
                case 'إيقاف':
                    if (!commandName) {
                        return await reply(getText('missingCommand'));
                    }
                    await unloadCommand(commandName, reply, getText);
                    break;

                case 'reload':
                case 'تحديث':
                case 'اعادة_تحميل':
                    if (!commandName) {
                        return await reply(getText('missingCommand'));
                    }
                    await reloadCommand(commandName, reply, getText);
                    break;

                case 'info':
                case 'معلومات':
                case 'فحص':
                    if (!commandName) {
                        return await reply(getText('missingCommand'));
                    }
                    await showCommandInfo(commandName, reply, getText);
                    break;

                case 'list':
                case 'قائمة':
                case 'قائمه':
                case 'الاوامر':
                    await listCommands(reply, getText);
                    break;

                default:
                    await reply(getText('missingAction'));
            }

        } catch (error) {
            console.error("Error in cmd command:", error);
            await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة نظام إدارة الأوامر.");
        }
    }
};

async function loadCommand(commandName, reply, getText) {
    try {
        const commandPath = path.join(__dirname, `${commandName}.js`);
        
        if (!fs.existsSync(commandPath)) {
            return await reply(getText('commandNotFound', commandName));
        }

        // مسح كاش الموديول القديم لضمان قراءة التحديثات الجديدة
        delete require.cache[require.resolve(commandPath)];

        // تحميل ملف الأمر برمجياً
        const command = require(commandPath);
        
        // إضافته لمجموعة الأوامر النشطة للبوت
        global.GoatBot.commands.set(command.config.name, command);

        // تسجيل الكلمات المرادفة (Aliases)
        if (command.config.aliases) {
            command.config.aliases.forEach(alias => {
                global.GoatBot.aliases.set(alias, command.config.name);
            });
        }

        // إدراجه في معالجات الشات المباشر في حال تطلّب ذلك
        if (command.onChat && !global.GoatBot.onChat.includes(command.config.name)) {
            global.GoatBot.onChat.push(command.config.name);
        }

        await reply(getText('commandLoaded', command.config.name));

    } catch (error) {
        await reply(getText('loadError', commandName, error.message));
    }
}

async function unloadCommand(commandName, reply, getText) {
    try {
        const command = global.GoatBot.commands.get(commandName);
        
        if (!command) {
            return await reply(getText('commandNotFound', commandName));
        }

        // إزالة الأمر من الذاكرة النشطة
        global.GoatBot.commands.delete(commandName);

        // إزالة جميع الاختصارات المرتبطة به لمنع استدعائه
        if (command.config.aliases) {
            command.config.aliases.forEach(alias => {
                global.GoatBot.aliases.delete(alias);
            });
        }

        // إزالته من معالجات الشات المباشر
        const chatIndex = global.GoatBot.onChat.indexOf(commandName);
        if (chatIndex !== -1) {
            global.GoatBot.onChat.splice(chatIndex, 1);
        }

        // مسح كاش الموديول كلياً من النظام
        const commandPath = path.join(__dirname, `${commandName}.js`);
        if (fs.existsSync(commandPath)) {
            delete require.cache[require.resolve(commandPath)];
        }

        await reply(getText('commandUnloaded', commandName));

    } catch (error) {
        await reply(getText('unloadError', commandName, error.message));
    }
}

async function reloadCommand(commandName, reply, getText) {
    try {
        // أولاً: نقوم بإيقاف الأمر ومسحه من الذاكرة
        await unloadCommand(commandName, () => {}, getText);
        
        // ثانياً: نقوم بإعادة تحميل الملف لقراءة الكود الجديد
        await loadCommand(commandName, reply, getText);

    } catch (error) {
        await reply(getText('loadError', commandName, error.message));
    }
}

async function showCommandInfo(commandName, reply, getText) {
    try {
        const command = global.GoatBot.commands.get(commandName) || 
                       global.GoatBot.commands.get(global.GoatBot.aliases.get(commandName));
        
        if (!command) {
            return await reply(getText('commandNotFound', commandName));
        }

        const config = command.config;
        const roleNames = ['مستخدم عادي', 'مشرف مجمّوعة', 'مطور البوت الرئيسي'];
        const roleName = roleNames[config.role] || `مستوى صلاحية ${config.role}`;
        const aliases = config.aliases ? config.aliases.join(', ') : 'لا يوجد';

        const info = getText('commandInfo',
            config.name,
            config.description || 'لا يوجد وصف متاح لهذا الأمر حالياً.',
            config.usage || `${global.GoatBot.prefix}${config.name}`,
            roleName,
            config.cooldown || config.countDown || 3,
            config.category || 'عام',
            aliases
        );

        await reply(info);

    } catch (error) {
        await reply(getText('commandNotFound', commandName));
    }
}

async function listCommands(reply, getText) {
    try {
        const commands = Array.from(global.GoatBot.commands.values());
        const categories = {};

        // فرز وترتيب الأوامر داخل مصفوفات بناءً على الفئة الخاصة بها
        commands.forEach(cmd => {
            const category = cmd.config.category || 'عام';
            if (!categories[category]) {
                categories[category] = [];
            }
            categories[category].push(cmd.config.name);
        });

        let commandsList = '';
        for (const [category, cmdList] of Object.entries(categories)) {
            commandsList += `📂 **${category.toUpperCase()}**\n`;
            commandsList += `${cmdList.join(', ')}\n\n`;
        }

        await reply(getText('commandsList', commands.length, commandsList));

    } catch (error) {
        await reply("❌ حدث خطأ أثناء محاولة فهرسة واستعراض قائمة الأوامر.");
    }
}
