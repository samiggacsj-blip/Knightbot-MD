const DataUtils = require("../../libs/dataUtils");

module.exports = {
  config: {
    name: "demote",
    aliases: ["unadmin", "تنزيل", "عزل", "إعفاء", "اعفاء", "تخفيض"],
    version: "1.0.0",
    author: "@anbuinfosec",
    countDown: 10,
    role: 1,
    description: "تنزيل رتبة عضو وإلغاء صلاحية المشرف (Admin) عنه في المجموعة",
    category: "moderation",
    guide: "{pn} @منشن - لإلغاء إشراف العضو عبر الإشارة إليه"
  },
  
  onCmd: async function ({ api, message, args, db, logger, config, reply }) {
    try {
      const senderJid = message.key.participant || message.key.remoteJid;
      const threadId = message.key.remoteJid;
      const isGroup = threadId.endsWith("@g.us");
      const isAdmin = config.admins.includes(senderJid);
      
      if (!isGroup) {
        return reply("❌ يمكن استخدام هذا الأمر داخل المجموعات فقط.");
      }
      
      if (!isAdmin) {
        return reply("❌ ليس لديك الصلاحية الكافية لاستخدام هذا الأمر.");
      }
      
      // جلب معرف العضو المشار إليه (منشن)
      const mentionedUser = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
      if (!mentionedUser) {
        const prefix = global.config?.prefix || ".";
        return reply(`❌ يرجى الإشارة (منشن) للعضو المراد تنزيل رتبته.\n💡 طريقة الاستخدام: \`${prefix}demote @منشن\` أو \`${prefix}تنزيل @منشن\``);
      }
      
      // منع تخفيض رتب مطوري أو مديري البوت الأساسيين
      if (config.admins.includes(mentionedUser)) {
        return reply("❌ نظام الحماية: لا يمكن عزل أو تنزيل رتبة مطور أو مشرف البوت الأساسي.");
      }
      
      // التحقق من وجود العضو داخل هذه المجموعة حالياً
      const threadData = await DataUtils.getThread(threadId);
      if (!threadData.participants.includes(mentionedUser)) {
        return reply("❌ هذا العضو ليس موجوداً في هذه المجموعة.");
      }
      
      try {
        // إلغاء رتبة المشرف عن العضو في المجموعة عبر الـ API
        await api.groupParticipantsUpdate(threadId, [mentionedUser], "demote");
        
        // تحديث قائمة المشرفين في قاعدة بيانات المجموعة
        const updatedAdmins = (threadData.admins || []).filter(admin => admin !== mentionedUser);
        await DataUtils.updateThread(threadId, {
          admins: updatedAdmins,
          lastActivity: Date.now()
        });
        
        // جلب بيانات العضو المعدل
        const userData = await DataUtils.getUser(mentionedUser);
        
        const demoteMessage = `👤 *تم تنزيل رتبة العضو بنجاح*\n\n` +
                             `👤 العضو: ${userData.name || "غير معروف"}\n` +
                             `🆔 المعرف: ${mentionedUser}\n` +
                             `👮 بواسطة المشرف: ${message.pushName || "المطور المسؤول"}\n` +
                             `🕐 الوقت: ${new Date().toLocaleString()}\n\n` +
                             `❌ العضو المذكور لم يعد مشرفاً (Admin) في المجموعة بعد الآن.`;
        
        await reply(demoteMessage);
        
        logger.info(`تم عزل وتنزيل رتبة المستخدم: ${userData.name} (${mentionedUser}) في المجموعة ${threadId} بواسطة ${senderJid}`);
        
      } catch (error) {
        logger.error("خطأ أثناء محاولة عزل العضو:", error);
        await reply("❌ فشل تنزيل رتبة العضو. يرجى التأكد من أن البوت يملك صلاحيات المشرف (Admin) أولاً.");
      }
      
    } catch (error) {
      logger.error("خطأ عام في أمر التنزيل (demote):", error);
      await reply("❌ حدث خطأ داخلي غير متوقع أثناء معالجة أمر تخفيض الرتبة.");
    }
  }
};
