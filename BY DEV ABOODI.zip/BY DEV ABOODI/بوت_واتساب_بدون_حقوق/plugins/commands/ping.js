module.exports = {
  config: {
    name: "ping",
    aliases: ["p", "بينج", "بنج", "سرعة", "سرعه", "السرعة", "السرعه", "فحص"],
    version: "1.0",
    author: "@anbuinfosec",
    countDown: 0,
    role: 0, // متاح لجميع الأعضاء دون قيود
    description: "فحص قياس سرعة استجابة البوت والاتصال بالسيرفر",
    category: "Utility",
    guide: "{pn}",
  },

  onCmd: async ({ api, message, reply, user, thread, role, utils, logger }) => {
    const startTime = Date.now();
    
    // إرسال رسالة أولية لبدء الفحص
    const sentMsg = await reply("⏳ جاري الفحص وقياس سرعة الاتصال..."); 
    
    // حساب الفارق الزمني بالملي ثانية
    const latency = Date.now() - startTime;

    // تعديل الرسالة السابقة لعرض النتيجة النهائية
    await api.sendMessage(sentMsg.key.remoteJid, {
      text: `🏓 بونج (Pong)!\n⏱️ سرعة الاستجابة: ${latency} ملي ثانية`,
      edit: sentMsg.key,
    });
  },
};
