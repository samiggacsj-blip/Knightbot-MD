module.exports = {
	config: {
		name: "unsend",
		aliases: ["uns", "احذف", "حذف", "اسحب", "سحب", "امسح", "مسح"],
		version: "1.2",
		author: "@anbuinfosec",
		countDown: 5,
		role: 0, // متاح لجميع الأعضاء لحذف رسائل البوت الناتجة عنهم
		description: "جعل البوت يسحب ويحذف رسالته من المجموعة عن طريق الرد عليها",
		category: "utility",
		guide: "{pn}: قم بالرد (Reply) على رسالة البوت التي تريد حذفها وكتابة الأمر."
			+ "\n{pn} <العدد>: لسحب آخر عدد معين من رسائل البوت (متاح من 1 إلى 10)."
	},

	onStart: async function ({ message, event, args, api }) {
		const { messageReply, threadID } = event;
		const botID = api.getCurrentUserID();
		
		// المسار الأول: في حال قام المستخدم بالرد (Reply) على الرسالة المراد حذفها
		if (messageReply) {
			// التحقق مما إذا كانت الرسالة المستهدفة تخص البوت نفسه أم عضو آخر
			if (messageReply.senderID != botID) {
				return message.reply("❌ عذراً، يمكنني فقط سحب الرسائل الخاصة بي وليس رسائل الأعضاء الآخرين.");
			}
			
			try {
				// تنفيذ أمر حذف وسحب الرسالة من الشات لدى الجميع
				await api.unsendMessage(messageReply.messageID);
				return message.reply("✅ تم سحب وإزالة الرسالة بنجاح.");
			} catch (err) {
				return message.reply("❌ تعذر سحب هذه الرسالة حالياً، قد يكون الوقت المسموح للحذف قد انتهى.");
			}
		}
		
		// المسار الثاني: في حال إدخال رقم لحذف رسائل متعددة
		if (args[0]) {
			const num = parseInt(args[0]);
			if (isNaN(num) || num < 1 || num > 10) {
				return message.reply("❌ يرجى إدخال رقم صحيح وصالح بين 1 و 10 فقط.");
			}
			
			// ملاحظة برمجية من الكود الأصلي: يتطلب هذا الجزء سجل تخزين مؤقت للرسائل الأخيرة
			// لذلك يتم توجيه المستخدم برمجياً لاستخدام ميزة الرد المباشر حالياً
			return message.reply("⚠️ ميزة سحب الرسائل بالعدد قيد التطوير حالياً في ملف النظام.\n💡 يرجى الرد (Reply) مباشرة على رسالة البوت التي ترغب في حذفها.");
		}
		
		// في حال كتابة الأمر دون رد أو بدون تحديد رقم
		return message.reply("❌ طريقة استخدام خاطئة. يرجى الرد (Reply) مباشرة على رسالة البوت التي ترغب في سحبها وحذفها من الشات.");
	}
};
