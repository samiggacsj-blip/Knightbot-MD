const DataUtils = require("../../libs/dataUtils");
const { getUserName } = require("../../libs/utils");

module.exports = {
  config: {
    name: "leave",
    author: "anbuinfosec",
    version: "1.0.0",
    category: "events", // مديول أحداث تلقائي يعمل بالخلفية فور رصد خروج عضو
  },

  onEvent: async ({ api, event, db, logger }) => {
    const { id, action, participants } = event;
    // التحقق مما إذا كان الحدث الحالي هو خروج/طرد عضو (remove) من المجموعة
    if (action !== "remove" || !participants) return;

    try {
      // جلب بيانات وإحصائيات المجموعة الحالية من قاعدة البيانات
      const threadData = await DataUtils.getThread(id);
      
      // معالجة كافة الأعضاء الخارجين (سواء كان عضواً واحداً أو خروجاً جماعياً)
      for (const user of participants) {
        try {
          // جلب الاسم الحركي للعضو المغادر عبر واجهة البوت المعتمدة
          const userName = await getUserName(user, null, api);
          
          // تحديث سجلات المجموعة في قاعدة البيانات واستثناء العضو المغادر
          await DataUtils.updateThread(id, {
            participants: threadData.participants.filter(p => p !== user),
            lastActivity: Date.now()
          });
          
          // صياغة وتنسيق رسالة الوداع باللغة العربية
          const leaveMessage = `👋 *[ مغادرة / طرد عضو من المجموعة ]*\n\n` +
                              `👤 *العضو:* ${userName}\n` +
                              `🆔 *المعرف (ID):* \`${user}\`\n` +
                              `🕐 *التوقيت:* ${new Date().toLocaleString('ar-EG')}\n\n` +
                              `😢 نتمنى لك وقتاً طيباً، سنشتاق لوجودك معنا!`;
          
          // إرسال كائن رسالة الوداع تلقائياً إلى الروم
          await api.sendMessage(id, {
            text: leaveMessage
          });
          
          logger.info(`👋 ${userName} left group ${id}`);
          
        } catch (error) {
          logger.error(`Error processing leave for user ${user}:`, error);
        }
      }
    } catch (error) {
      logger.error("Error in leave event:", error);
    }
  }
};
