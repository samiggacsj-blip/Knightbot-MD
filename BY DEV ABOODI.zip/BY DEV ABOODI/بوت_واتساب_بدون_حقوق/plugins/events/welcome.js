module.exports = {
  config: {
    name: "welcome",
    author: "anbuinfosec",
    version: "1.0.0",
    category: "events", // مديول أحداث تلقائي يعمل بالخلفية فور رصد انضمام عضو
  },

  onEvent: async ({ api, event, db, logger, user, thread, utils }) => {
    const { id, action, participants } = event;
    // التحقق مما إذا كان الحدث الحالي هو انضمام أو إضافة عضو جديد (add) للمجموعة
    if (action !== "add" || !participants) return;

    try {
      // استدعاء المكتبات المساعدة والأدوات الأساسية للنظام
      const DataUtils = require("../../libs/dataUtils");
      const { getUserName } = require("../../libs/utils");
      
      // جلب بيانات المجموعة - مع معالجة وتفادي الأخطاء في حال غياب بارامتر الـ thread
      const threadData = thread?.getThread ? await thread.getThread() : await DataUtils.getThread(id);
      
      // التحقق مما إذا كانت ميزة رسائل الترحيب مفعّلة في إعدادات هذه المجموعة أم معطّلة
      if (!threadData.settings.welcomeMessage) return;

      // معالجة الأعضاء المنضمين (يدعم الانضمام الفردي والجماعي في نفس الوقت)
      for (const participantId of participants) {
        try {
          // جلب بيانات العضو والاسم الحركي عبر الوسائط المتاحة في النظام
          const userData = user?.getUser ? await user.getUser(participantId) : await DataUtils.getUser(participantId);
          const userName = utils?.getUserName ? await utils.getUserName(participantId, null, api) : await getUserName(participantId);
          
          // تحديث بيانات حساب العضو الجديد وجدولة توقيت رؤيته
          if (user?.updateUser) {
            await user.updateUser(participantId, {
              name: userName,
              lastSeen: Date.now(),
              messageCount: userData.messageCount || 0
            });
          } else {
            await DataUtils.updateUser(participantId, {
              name: userName,
              lastSeen: Date.now(),
              messageCount: userData.messageCount || 0
            });
          }
          
          // تحديث سجل الأعضاء الفعليين داخل المجموعة ومنع التكرار باستخدام Set
          if (thread?.updateThread) {
            await thread.updateThread({
              participants: [...new Set([...threadData.participants, participantId])],
              lastActivity: Date.now()
            });
          } else {
            await DataUtils.updateThread(id, {
              participants: [...new Set([...threadData.participants, participantId])],
              lastActivity: Date.now()
            });
          }
          
          // نظام المكافآت: منح العضو الجديد 10 نقاط خبرة (XP) للتفاعل
          if (user?.addExperience) {
            await user.addExperience(participantId, 10);
          } else {
            const currentUser = await DataUtils.getUser(participantId);
            await DataUtils.updateUser(participantId, {
              experience: (currentUser.experience || 0) + 10
            });
          }
          
          // صياغة وتنسيق رسالة الترحيب باللغة العربية مع إدراج المنشن
          const welcomeMessage = `🎉 *أهلاً بك في المجموعة!* 🎉\n\n` +
                                `👋 مرحباً بك يا ${userName}!\n` +
                                `📝 يرجى مراجعة قوانين المجموعة والالتزام بها لقضاء وقت ممتع.\n` +
                                `🎁 لقد حصلت على 10 نقاط خبرة (XP) كهدية ترحيبية لانضمامك إلينا!\n\n` +
                                `ℹ️ لمعرفة أوامر وميزات البوت، اكتب: \`.help\``;
          
          // إرسال رسالة الترحيب التلقائية مباشرة إلى شات المجموعة
          await api.sendMessage(id, {
            text: welcomeMessage,
            mentions: [participantId],
          });
          
          if (logger) {
            logger.info(`👋 Welcomed new member: ${userData.name || participantId} to group ${id}`);
          }
        } catch (e) {
          console.log("Error welcoming user:", e);
        }
      }
    } catch (error) {
      console.log("Error in welcome event:", error);
    }
  },
}
