const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const ModuleManager = require("../libs/moduleManager");

// تحميل ملف الإعدادات والتهيئة
function loadConfig(logger) {
  try {
    const configPath = path.join(__dirname, "..", "config.json");
    if (!fs.existsSync(configPath)) {
      throw new Error("ملف الإعدادات (config.json) غير موجود");
    }
    const config = require(configPath);

    if (!global.GoatBot) {
      global.GoatBot = {};
    }

    global.GoatBot.config = config;

    logger.info(`✅ تم تحميل ملف الإعدادات بنجاح من: ${configPath}`);
  } catch (error) {
    logger.error(`❌ فشل في تحميل ملف الإعدادات: ${error.message}`);
    throw error; // إيقاف تشغيل البوت تماماً إذا غاب ملف الإعدادات
  }
}

async function loadCommand(filePath, logger) {
  try {
    const moduleManager = new ModuleManager();
    const dependenciesOk = await moduleManager.checkCommandDependencies(filePath);

    if (!dependenciesOk) {
      logger.warn(`⚠️ فشل تثبيت بعض الحزم التابعة لـ ${path.basename(filePath)}، جاري التحميل على أي حال...`);
    }

    const absolutePath = require.resolve(filePath);
    delete require.cache[absolutePath];

    const command = require(filePath);

    if (!command) throw new Error("ملف الأمر فارغ أو يصدر كائن غير معرف (undefined/null)");
    if (!command.config) throw new Error("كائن التهيئة 'config' مفقود في ملف الأمر");
    if (!command.config.name) throw new Error("اسم الأمر 'config.name' مفقود في ملف التهيئة");
    if (!command.onCmd && !command.onStart) throw new Error("الدالة التنفيذية 'onCmd' أو 'onStart' مفقودة في ملف الأمر");

    const cmdName = command.config.name.toLowerCase();

    if (!global.GoatBot) throw new Error("كائن البوت العام global.GoatBot لم يتم تهيئته بعد");
    if (!global.GoatBot.commands) global.GoatBot.commands = new Map();
    if (!global.GoatBot.aliases) global.GoatBot.aliases = new Map();

    global.GoatBot.commands.set(cmdName, command);

    if (command.config.aliases) {
      command.config.aliases.forEach(alias => {
        global.GoatBot.aliases.set(alias.toLowerCase(), cmdName);
      });
    }

    logger.info(`✅ تم تحميل الأمر بنجاح: ${cmdName}`);
    return true;
  } catch (error) {
    logger.error(`❌ فشل في تحميل الأمر ${path.basename(filePath)}: ${error.message}`);
    return false;
  }
}

function unloadCommand(filePath, logger) {
  try {
    const absolutePath = require.resolve(filePath);

    let command;
    if (require.cache[absolutePath]) {
      command = require.cache[absolutePath].exports;
    } else {
      command = require(filePath);
    }

    if (command && command.config && command.config.name) {
      const cmdName = command.config.name.toLowerCase();

      if (global.GoatBot && global.GoatBot.commands?.has(cmdName)) {
        global.GoatBot.commands.delete(cmdName);
      }
      if (command.config.aliases) {
        command.config.aliases.forEach(alias => {
          if (global.GoatBot && global.GoatBot.aliases.get(alias.toLowerCase()) === cmdName) {
            global.GoatBot.aliases.delete(alias.toLowerCase());
          }
        });
      }
      logger.info(`🗑️ تم إزالة غلق وتحميل الأمر: ${cmdName}`);
    }

    delete require.cache[absolutePath];
    return true;
  } catch (error) {
    logger.error(`❌ فشل في إلغاء تحميل الأمر ${path.basename(filePath)}: ${error.message}`);
    try {
      delete require.cache[require.resolve(filePath)];
    } catch {}
    return false;
  }
}

async function loadEvent(filePath, logger) {
  try {
    const moduleManager = new ModuleManager();
    const dependenciesOk = await moduleManager.checkCommandDependencies(filePath);

    if (!dependenciesOk) {
      logger.warn(`⚠️ فشل تثبيت بعض الحزم التابعة لـ ${path.basename(filePath)}، جاري التحميل على أي حال...`);
    }

    const absolutePath = require.resolve(filePath);
    delete require.cache[absolutePath];

    const event = require(filePath);

    if (!event.config?.name) {
      throw new Error("اسم الحدث 'config.name' مفقود في ملف الأحداث.");
    }

    const eventName = event.config.name.toLowerCase();

    if (!global.GoatBot) throw new Error("كائن البوت العام global.GoatBot لم يتم تهيئته بعد");
    if (!global.GoatBot.events) global.GoatBot.events = new Map();

    global.GoatBot.events.set(eventName, event);

    logger.info(`✅ تم تحميل الحدث بنجاح: ${eventName}`);
    return true;
  } catch (error) {
    logger.error(`❌ فشل في تحميل الحدث ${path.basename(filePath)}: ${error.message}`);
    return false;
  }
}

function unloadEvent(filePath, logger) {
  try {
    const absolutePath = require.resolve(filePath);
    let event;

    if (require.cache[absolutePath]) {
      event = require.cache[absolutePath].exports;
    } else {
      event = require(filePath);
    }

    const eventName = event.config.name.toLowerCase();

    if (global.GoatBot && global.GoatBot.events?.has(eventName)) {
      global.GoatBot.events.delete(eventName);
    }

    delete require.cache[absolutePath];
    logger.info(`🗑️ تم إلغاء تحميل الحدث: ${eventName}`);
    return true;
  } catch (error) {
    logger.error(`❌ فشل في إلغاء تحميل الحدث ${path.basename(filePath)}: ${error.message}`);
    return false;
  }
}

async function loadPlugins(logger) {
  // أولاً جلب وتحميل الإعدادات
  loadConfig(logger);

  const commandsPath = path.join(__dirname, "..", "plugins", "commands");
  const eventsPath = path.join(__dirname, "..", "plugins", "events");

  const moduleManager = new ModuleManager();

  logger.info(chalk.cyan.bold(`--- جاري فحص الحزم والاعتماديات الخارجية ---`));
  const dependencySuccess = await moduleManager.scanAndInstallAllDependencies();

  if (!dependencySuccess) {
    logger.warn("⚠️ فشل تثبيت بعض المديولات الاعتمادية، ولكن جاري المتابعة في تحميل الإضافات...");
  }

  const stats = moduleManager.getStats();
  if (stats.installedCount > 0) {
    logger.info(`✅ تم التثبيت التلقائي لـ ${stats.installedCount} من المديولات المفقودة: ${stats.installed.join(", ")}`);
  }
  if (stats.failedCount > 0) {
    logger.warn(`⚠️ فشل تثبيت ${stats.failedCount} من المديولات: ${stats.failed.join(", ")}`);
  }

  // تحميل الأوامر
  logger.info(chalk.cyan.bold(`--- الأوامر (Commands) ---`));
  if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"));
    for (const file of commandFiles) {
      await loadCommand(path.join(commandsPath, file), logger);
    }
  } else {
    logger.warn(`⚠️ مسار مجلد الأوامر غير موجود: ${commandsPath}`);
  }
  logger.info(chalk.white(`- إجمالي الأوامر:    تم تحميل ${chalk.green(global.GoatBot.commands?.size || 0)} أمر بنجاح`));

  // تحميل الأحداث
  logger.info(chalk.cyan.bold(`--- الأحداث (Events) ---`));
  if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith(".js"));
    for (const file of eventFiles) {
      await loadEvent(path.join(eventsPath, file), logger);
    }
  } else {
    logger.warn(`⚠️ مسار مجلد الأحداث غير موجود: ${eventsPath}`);
  }
  logger.info(chalk.white(`- إجمالي الأحداث:    تم تحميل ${chalk.green(global.GoatBot.events?.size || 0)} حدث بنجاح`));

  logger.info("-------------------------");
}

module.exports = {
  loadPlugins,
  loadCommand,
  unloadCommand,
  loadEvent,
  unloadEvent,
};
