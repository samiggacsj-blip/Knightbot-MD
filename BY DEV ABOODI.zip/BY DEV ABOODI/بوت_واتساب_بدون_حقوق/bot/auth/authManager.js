const inquirer = require("inquirer")
const chalk = require("chalk")
const fs = require("fs-extra")
const path = require("path")
const { logger } = require("@/libs/logger")

class AuthManager {
  constructor() {
    this.sessionPath = path.join(process.cwd(), "session")
    this.authMethod = null
    this.isInteractive = process.stdout.isTTY
    this.authPromise = null
    this.authResolver = null
    this.authRejecter = null
  }

  async checkSession() {
    try {
      const sessionExists = await fs.pathExists(this.sessionPath)
      if (!sessionExists) {
        logger.info("📱 لم يتم العثور على جلسة نشطة سابقة")
        return false
      }

      const files = await fs.readdir(this.sessionPath)
      const hasValidSession = files.some((file) => file.includes("creds.json"))

      if (hasValidSession) {
        // تحقق إضافي: التأكد من صحة وهيكل ملف creds.json
        const credsPath = path.join(this.sessionPath, "creds.json")
        try {
          const credsContent = await fs.readFile(credsPath, "utf8")
          const creds = JSON.parse(credsContent)
          
          // التحقق الأساسي من بنية بيانات الاعتماد
          if (creds && typeof creds === "object" && creds.noiseKey) {
            logger.info("✅ تم العثور على جلسة صالحة ونشطة")
            global.GoatBot.sessionValid = true
            return true
          } else {
            logger.warn("⚠️ ملف الجلسة موجود ولكنه يبدو تالفاً")
            await this.clearSession()
            return false
          }
        } catch (error) {
          logger.warn("⚠️ ملف الجلسة موجود ولكنه غير صالح:", error.message)
          await this.clearSession()
          return false
        }
      } else {
        logger.info("⚠️ مجلد الجلسة موجود ولكن لم يتم العثور على بيانات اعتماد صالحة")
        await this.clearSession()
        return false
      }
    } catch (error) {
      logger.error("❌ خطأ أثناء فحص حالة الجلسة:", error)
      return false
    }
  }

  async clearSession() {
    try {
      await fs.remove(this.sessionPath)
      logger.info("🗑️ تم مسح بيانات الجلسة بنجاح")
      global.GoatBot.sessionValid = false
    } catch (error) {
      logger.error("❌ خطأ أثناء مسح الجلسة:", error)
      throw error
    }
  }

  async showAuthMenu() {
    return new Promise(async (resolve) => {
      // تنظيف الكونسول فقط إذا كنا في وضع تفاعلي
      if (this.isInteractive) {
        console.clear()
      }

      console.log(chalk.cyan("\n" + "=".repeat(50)))
      console.log(chalk.cyan.bold("           🔐 تسجيل الدخول والمصادقة مطلوب"))
      console.log(chalk.cyan("=".repeat(50)))
      console.log(chalk.yellow("يرجى اختيار طريقة المصادقة المفضلة لديك:\n"))

      const choices = [
        {
          name: "📱 كود الإقتران - ربط الحساب عبر رقم الهاتف مباشرة",
          value: "pairing",
          short: "كود الإقتران",
        },
        {
          name: "📷 رمز الـ QR - مسح الكود بكاميرا الواتساب",
          value: "qr",
          short: "رمز QR",
        },
        {
          name: "🗑️ مسح الجلسة - حذف ملفات الجلسة الحالية وإعادة التهيئة",
          value: "clear",
          short: "مسح الجلسة",
        },
        {
          name: "❌ خروج - إغلاق التطبيق بالكامل",
          value: "exit",
          short: "خروج",
        },
      ]

      try {
        // تعيين الحالة العامة للبوت بانتظار المصادقة
        global.GoatBot.connectionStatus = "waiting_for_auth"
        global.GoatBot.waitingForAuth = true

        // التحقق مما إذا كانت البيئة تدعم القوائم التفاعلية
        if (!this.isInteractive) {
          logger.warn("⚠️ تم رصد بيئة غير تفاعلية، جاري التحويل التلقائي لمصادقة رمز الـ QR");
          return resolve("qr")
        }

        const answer = await inquirer.prompt([
          {
            type: "list",
            name: "method",
            message: "اختر طريقة تسجيل الدخول المريحة لك:",
            choices: choices,
            pageSize: 4,
            prefix: "🐐",
            suffix: "",
          },
        ])

        resolve(answer.method)
      } catch (error) {
        if (error.isTtyError || !this.isInteractive) {
          logger.info("📱 واجهات الإدخال التفاعلية غير متاحة، جاري التحويل التلقائي لرمز الـ QR")
          resolve("qr")
        } else {
          logger.error("❌ خطأ داخل قائمة المصادقة الرئيسية:", error)
          // نظام حماية احتياطي بالتحويل التلقائي للـ QR
          resolve("qr")
        }
      }
    })
  }

  async handlePairingCode() {
    console.log(chalk.cyan("\n" + "=".repeat(50)))
    console.log(chalk.cyan.bold("           📱 المصادقة عبر كود الإقتران"))
    console.log(chalk.cyan("=".repeat(50)))

    try {
      let phoneNumber

      if (this.isInteractive) {
        const phoneAnswer = await inquirer.prompt([
          {
            type: "input",
            name: "phone",
            message: "أدخل رقم هاتفك (مع رمز الدولة كاملاً، مثال: 201234567890+):",
            validate: (input) => {
              const cleaned = input.replace(/\D/g, "")
              if (cleaned.length < 10 || cleaned.length > 15) {
                return "يرجى إدخال رقم هاتف صحيح (يتراوح بين 10 إلى 15 رقماً)"
              }
              if (!input.startsWith("+")) {
                return "يرجى إدراج رمز الدولة أولاً مبدوءاً بعلامة + (مثال: 201234567890+)"
              }
              return true
            },
            filter: (input) => {
              // التأكد من الحفاظ على علامة الزائد والأرقام فقط بعد التصفية
              const cleaned = input.replace(/[^\d+]/g, "")
              if (!cleaned.startsWith("+")) {
                return "+" + cleaned
              }
              return cleaned
            },
            prefix: "📞",
          },
        ])
        phoneNumber = phoneAnswer.phone
      } else {
        // المعالجة الاحتياطية في البيئات غير التفاعلية
        logger.error("❌ لا يمكن جلب أو استقبال رقم الهاتف في بيئة عمل غير تفاعلية")
        throw new Error("يجب توفر إدخال تفاعلي من الكونسول لاستخدام طريقة كود الإقتران")
      }

      this.authMethod = "pairing"
      global.GoatBot.authMethod = "pairing"

      console.log(chalk.yellow("\n⏳ جاري توليد كود الإقتران الخاص بك..."))
      this.showPairingInstructions()

      return phoneNumber
    } catch (error) {
      logger.error("❌ خطأ أثناء إعداد كود الإقتران:", error)
      throw error
    }
  }

  showPairingInstructions() {
    console.log(chalk.cyan("\n📋 تعليمات ربط كود الإقتران:"))
    console.log(chalk.white("┌─────────────────────────────────────────────────────┐"))
    console.log(chalk.white("│ 1. افتح تطبيق الـ WhatsApp على هاتفك المحمول         │"))
    console.log(chalk.white("│ 2. انتقل إلى الإعدادات > الأجهزة المرتبطة             │"))
    console.log(chalk.white("│ 3. اضغط على زر 'ربط جهاز جديد'                      │"))
    console.log(chalk.white("│ 4. اختر 'الربط برقم الهاتف بدلاً من ذلك'             │"))
    console.log(chalk.white("│ 5. قم بإدخال كود الإقتران الذي سيظهر بالأسفل حالاً   │"))
    console.log(chalk.white("└─────────────────────────────────────────────────────┘"))
    console.log(chalk.cyan("=".repeat(50)))
  }

  async handleQRCode() {
    console.log(chalk.cyan("\n" + "=".repeat(50)))
    console.log(chalk.cyan.bold("           📷 المصادقة عبر رمز الـ QR"))
    console.log(chalk.cyan("=".repeat(50)))

    this.authMethod = "qr"
    global.GoatBot.authMethod = "qr"

    console.log(chalk.yellow("⏳ جاري توليد رمز الـ QR الآن..."))
    this.showQRInstructions()

    return null
  }

  showQRInstructions() {
    console.log(chalk.cyan("\n📋 تعليمات مسح رمز الـ QR:"))
    console.log(chalk.white("┌─────────────────────────────────────────────────────┐"))
    console.log(chalk.white("│ 1. افتح تطبيق الـ WhatsApp على هاتفك المحمول         │"))
    console.log(chalk.white("│ 2. انتقل إلى الإعدادات > الأجهزة المرتبطة             │"))
    console.log(chalk.white("│ 3. اضغط على زر 'ربط جهاز جديد'                      │"))
    console.log(chalk.white("│ 4. وجّه كاميرا الهاتف نحو رمز الـ QR الموضح أدناه    │"))
    console.log(chalk.white("└─────────────────────────────────────────────────────┘"))
    console.log(chalk.cyan("=".repeat(50)))
  }

  async handleClearSession() {
    console.log(chalk.cyan("\n" + "=".repeat(50)))
    console.log(chalk.cyan.bold("           🗑️ جاري تنظيف الجلسة الحالية"))
    console.log(chalk.cyan("=".repeat(50)))

    try {
      await this.clearSession()
      console.log(chalk.green("✅ تم حذف ومسح بيانات الجلسة السابقة بنجاح"))
      console.log(chalk.yellow("🔄 جاري إعادة تشغيل عملية المصادقة التلقائية..."))
      await new Promise(resolve => setTimeout(resolve, 2000))
    } catch (error) {
      logger.error("❌ خطأ أثناء عملية تصفية ومسح بيانات الجلسة:", error)
      throw error
    }
  }

  showConnectionStatus(status) {
    const statusMessages = {
      connecting: "🔄 جاري الاتصال بخوادم واتساب...",
      connected: "✅ تم الاتصال بنجاح بـ WhatsApp!",
      disconnected: "❌ فُقد الاتصال بتطبيق واتساب",
      reconnecting: "🔄 جاري محاولة إعادة الاتصال التلقائي...",
      timeout: "⏰ انتهت مهلة محاولة الاتصال بالخادم",
      qr_ready: "📷 رمز الـ QR جاهز وبانتظار المسح بالكاميرا",
      pairing_ready: "📱 كود الإقتران الخاص بك جاهز للاستخدام",
      authentication: "🔐 جاري التحقق وفحص صلاحية التوثيق...",
      waiting_for_auth: "⏳ بانتظار إتمام عملية المصادقة والربط...",
    }

    const message = statusMessages[status] || `📊 الحالة الحالية: ${status}`
    console.log(chalk.cyan(`\n${message}`))
    
    // تحديث المتغير العام لحالة الاتصال للبوت
    global.GoatBot.connectionStatus = status
  }

  showSuccess() {
    console.log(chalk.green("\n" + "=".repeat(50)))
    console.log(chalk.green.bold("           ✅ تمت عملية المصادقة والربط بنجاح"))
    console.log(chalk.green("=".repeat(50)))
    console.log(chalk.yellow("🎉 تم تأسيس وربط اتصال الواتساب بنجاح واستقرار!"))
    console.log(chalk.cyan("🚀 البوت الآن بكامل جاهزيته ومستعد لتلقي الأوامر"))
    console.log(chalk.magenta("📊 لوحة التحكم متوفرة عبر الرابط: http://localhost:3000"))
    console.log(chalk.green("=".repeat(50)))
  }

  showError(message, error = null) {
    console.log(chalk.red("\n" + "=".repeat(50)))
    console.log(chalk.red.bold("           ❌ خطأ في عملية التوثيق والمصادقة"))
    console.log(chalk.red("=".
