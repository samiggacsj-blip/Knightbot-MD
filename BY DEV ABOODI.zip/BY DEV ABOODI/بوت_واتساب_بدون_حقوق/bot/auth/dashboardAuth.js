const config = require("../../config.json");

// مخزن مؤقت في الذاكرة لحفظ جلسات لوحة التحكم (Dashboard Sessions)
const dashboardSessions = new Map();

function generateSessionId() {
  return (
    Math.random().toString(36).substring(2, 15) +
    Math.random().toString(36).substring(2, 15)
  );
}

function isValidSession(sessionId) {
  const session = dashboardSessions.get(sessionId);
  if (!session) return false;
  const now = Date.now();
  // التحقق من انتهاء مهلة الجلسة (الافتراضي 30 دقيقة = 1800000 مللي ثانية)
  if (now - session.createdAt > (config.dashboard.sessionTimeout || 1800000)) {
    dashboardSessions.delete(sessionId);
    return false;
  }
  return true;
}

function requireAuth(req, res, next) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (token) {
    const authTokens = global.GoatBot.authTokens || new Map();
    const tokenData = authTokens.get(token);
    if (tokenData && Date.now() <= tokenData.expiryTime) {
      req.user = { authenticated: true };
      return next();
    }
    if (tokenData) authTokens.delete(token);
  }
  const sessionId = req.headers["x-session-id"] || req.query.sessionId;
  if (!sessionId || !isValidSession(sessionId)) {
    return res.status(401).json({ error: "تسجيل الدخول والمصادقة مطلوبة للوصول" });
  }
  next();
}

module.exports = {
  dashboardSessions,
  generateSessionId,
  isValidSession,
  requireAuth,
};
