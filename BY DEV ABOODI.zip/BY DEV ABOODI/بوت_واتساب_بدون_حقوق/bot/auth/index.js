module.exports = {
  // مديول مدير مصادقة وجلسات حساب الواتساب الأساسي
  AuthManager: require('./authManager'),
  // مديولات وأدوات فحص وتوثيق جلسات لوحة التحكم (Dashboard)
  ...require('./dashboardAuth')
};
