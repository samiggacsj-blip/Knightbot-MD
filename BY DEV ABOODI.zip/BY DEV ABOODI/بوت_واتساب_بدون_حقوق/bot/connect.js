const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const { Boom } = require("@hapi/boom");
const pino = require("pino");
const qrcode = require("qrcode-terminal");
const QRCode = require("qrcode");
const chalk = require("chalk");
const config = require("../config.json");
const { logger } = require("../libs/logger");
const { loadPlugins } = require("./loader");
const messageHandler = require("./handler");
const AuthManager = require("./auth/authManager");
const fs = require("fs-extra");
const path = require("path");

let sock;
let authManager;
let connectionAttempts = 0;
const MAX_CONNECTION_ATTEMPTS = 3;
let decryptionErrors = new Map(); // تتبع أخطاء فك التشفير لكل جهة اتصال

// تصدير AUTH_ERROR للاستخدام في ملف Goat.js
module.exports.AUTH_ERROR = new Boom("AUTH", { statusCode: 401 });

// معالجة أخطاء فك التشفير
async function handleDecryptionError(remoteJid, error) {
  try {
    const errorCount = decryptionErrors.get(remoteJid) || 0;
    decryptionErrors.set(remoteJid, errorCount + 1);

    logger.warn(
      `🔑 خطأ في فك التشفير لـ ${remoteJid} (العدد: ${errorCount + 1}): ${error.message}`
    );

    // إذا زادت أخطاء فك التشفير لجهة الاتصال هذه عن 5، يتم مسح الجلسة الخاصة به
    if (errorCount > 5) {
      logger.warn(`🔑 أخطاء فك تشفير كثيرة جداً لـ ${remoteJid}، جاري مسح بيانات الجلسة الخاصة به`);

      // مسح ملفات الجلسة الخاصة بجهة الاتصال هذه تحديداً
      const sessionPath = path.join(process.cwd(), "session");
      const sessionFiles = await fs.readdir(sessionPath);

      for (const file of sessionFiles) {
        if (file.includes(remoteJid.replace("@", "").replace(".", ""))) {
          const filePath = path.join(sessionPath, file);
          await fs.remove(filePath);
          logger.info(`🗑️ تم حذف ملف الجلسة: ${file}`);
        }
      }

      // إعادة تعيين عداد الأخطاء
      decryptionErrors.delete(remoteJid);
    }
  } catch (err) {
    logger.error("❌ خطأ أثناء معالجة خطأ فك التشفير:", err);
  }
}

// تنظيف ذاكرة التخزين المؤقت لأخطاء فك التشفير (إعادة تعيين كل ساعة)
setInterval(() => {
  decryptionErrors.clear();
  logger.debug("🔄 تم تنظيف ذاكرة التخزين المؤقت لأخطاء فك التشفير");
}, 3600000); // ساعة واحدة

async function connect({ method } = {}) {
  return new Promise(async (resolve, reject) => {
    try {
      authManager = new AuthManager();

      // التحقق من وجود مجلد الجلسة وإنشائه صامتاً إذا لم يكن موجوداً
      const sessionPath = path.join(process.cwd(), "session");
      if (!(await fs.pathExists(sessionPath))) {
        await fs.mkdir(sessionPath);
      }

      // التحقق من وجود جلسة صالحة
      const hasValidSession = await authManager.checkSession();

      if (!hasValidSession || method) {
        global.GoatBot.connectionStatus = "waiting_for_auth";
        global.GoatBot.waitingForAuth = true;

        // استخدام الطريقة الممررة أو إظهار قائمة المصادقة
        const authMethod = method || (await authManager.showAuthMenu()) || "session";
        global.GoatBot.authMethod = authMethod;

        // معالجة اختيار المستخدم
        switch (authMethod) {
          case "pairing":
            const phoneNumber = await authManager.handlePairingCode();
            await startConnection(phoneNumber, resolve, reject);
            break;
          case "qr":
            await authManager.handleQRCode();
            await startConnection(null, resolve, reject);
            break;
          case "clear":
            await authManager.handleClearSession();
            return connect().then(resolve).catch(reject);
          case "exit":
            console.log(chalk.yellow("👋 وداعاً!"));
            process.exit(0);
            break;
          default:
            await startConnection(null, resolve, reject);
        }
      } else {
        global.GoatBot.authMethod = "session";
        global.GoatBot.sessionValid = true;
        global.GoatBot.waitingForAuth = false;
        await startConnection(null, resolve, reject);
      }
    } catch (error) {
      authManager?.showError("فشل في تهيئة المصادقة", error);
      global.GoatBot.stats.errors++;
      reject(error);
    }
  });
}

async function startConnection(phoneNumber = null, resolve, reject) {
  try {
    connectionAttempts++;

    if (connectionAttempts > MAX_CONNECTION_ATTEMPTS) {
      const error = new Error(`تم تجاوز الحد الأقصى لمحاولات الاتصال (${MAX_CONNECTION_ATTEMPTS})`);
      authManager?.showError("فشل الاتصال بعد محاولات متعددة", error);
      return reject(error);
    }

    const { state, saveCreds } = await useMultiFileAuthState("session");
    const { version } = await fetchLatestBaileysVersion();

    logger.info(`جاري استخدام إصدار Baileys: ${version.join(".")}`);

    // التحقق من حالة الجلسة وتنظيفها إذا لزم الأمر
    if (state.creds && state.creds.me) {
      const sessionPath = path.join(process.cwd(), "session");
      const sessionFiles = await fs.readdir(sessionPath);

      // الفحص عن ملفات الجلسة التالفة
      const corruptedFiles = [];
      for (const file of sessionFiles) {
        if (file.startsWith("session-") && file.endsWith(".json")) {
          try {
            const filePath = path.join(sessionPath, file);
            const content = await fs.readFile(filePath, "utf8");
            JSON.parse(content); // التحقق من صحة JSON
          } catch (error) {
            corruptedFiles.push(file);
          }
        }
      }

      // إزالة ملفات الجلسة التالفة
      if (corruptedFiles.length > 0) {
        logger.warn(`🔧 تم العثور على ${corruptedFiles.length} من ملفات الجلسة التالفة، جاري إزالتها...`);
        for (const file of corruptedFiles) {
          await fs.remove(path.join(sessionPath, file));
          logger.info(`🗑️ تم حذف الملف التالف: ${file}`);
        }
      }
    }

    const connectionOptions = {
      auth: state,
      logger: pino({ level: "silent" }),
      version,
      printQRInTerminal: false,
      connectTimeoutMs: 30000,
      qrTimeout: 45000,
      retryRequestDelayMs: 1000,
      maxMsgRetryCount: 5,
      browser: ["GoatBot", "Chrome", "1.0.0"],
      generateHighQualityLinkPreview: true,
      // خيارات محسنة لمنع أخطاء "Bad MAC"
      getMessage: async (key) => {
        try {
          return { conversation: "هذه الرسالة تم حذفها" };
        } catch (error) {
          logger.warn("⚠️ فشل في جلب الرسالة:", error.message);
          return { conversation: "الرسالة غير متوفرة" };
        }
      },
      shouldIgnoreJid: (jid) => {
        // تجاهل المعرفات الـ JID التي تسبب مشاكل وأخطاء فك التشفير
        const errorCount = decryptionErrors.get(jid) || 0;
        return errorCount > 10;
      },
      // خيارات إضافية للتعامل مع أخطاء الجلسة
      syncFullHistory: false,
      emitOwnEvents: false,
      markOnlineOnConnect: false,
      msgRetryCounterMap: {},
    };

    if (phoneNumber) {
      connectionOptions.mobile = true;
    }

    sock = makeWASocket(connectionOptions);

    const connectionTimeout = setTimeout(() => {
      if (!global.GoatBot.isConnected) {
        authManager?.showConnectionStatus("timeout");
        authManager?.showError("انتهت مهلة الاتصال. يرجى المحاولة مرة أخرى.");
        reject(new Error("Connection timeout"));
      }
    }, 60000);

    // مستمع موحد لإحداثيات وحالات الاتصال لمنع التصادم البرمجي وتكرار الاستدعاء
    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect, qr } = update;

      // التعامل مع الكود الخاص بالـ Pairing
      if (qr && phoneNumber) {
        try {
          const code = await sock.requestPairingCode(phoneNumber.replace(/\D/g, ""));
          console.log(chalk.green.bold(`\n🔑 كود الاقتران الخاص بك: ${code}`));
          console.log(chalk.yellow("⏰ تنتهي صلاحية الكود خلال 60 ثانية"));
          console.log(chalk.cyan("📱 أدخل هذا الكود في واتساب > الأجهزة المرتبطة > ربط جهاز\n"));
          authManager?.showConnectionStatus("pairing_ready");
        } catch (error) {
          authManager?.showError("فشل في توليد كود الاقتران", error);
          reject(error);
        }
      }

      // التعامل مع الـ QR للوحة التحكم والكونسول
      if (qr && !phoneNumber) {
        authManager?.showConnectionStatus("qr_ready");

        // توليد رمز QR للوحة التحكم
        try {
          const qrDataURL = await QRCode.toDataURL(qr, {
            width: 256,
            margin: 2,
            color: {
              dark: "#000000",
              light: "#FFFFFF",
            },
          });
          global.GoatBot.qrCode = qrDataURL;
        } catch (error) {
          logger.error("خطأ في توليد رمز QR للوحة التحكم:", error);
          global.GoatBot.qrCode = null;
        }

        // ضبط حجم الـ QR تلقائياً بناءً على عرض الكونسول
        const consoleWidth = process.stdout.columns || 80;
        const qrSize = Math.min(Math.floor(consoleWidth / 2), 30);
        qrcode.generate(qr, {
          small: true,
          size: qrSize,
        });
        console.log(chalk.cyan("👆 امسح رمز QR أعلاه باستخدام تطبيق الـ WhatsApp"));
        console.log(chalk.yellow("📱 واتساب > الإعدادات > الأجهزة المرتبطة > ربط جهاز جديد\n"));
      }

      // التعامل مع إغلاق الاتصال وفشله
      if (connection === "close") {
        clearTimeout(connectionTimeout);
        
        const lastDisconnectError = lastDisconnect?.error;
        const statusCode = lastDisconnectError instanceof Boom 
          ? lastDisconnectError.output?.statusCode 
          : (lastDisconnectError?.output?.statusCode || 500);

        const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

        if (shouldReconnect) {
          switch (statusCode) {
            case DisconnectReason.badSession:
              authManager?.showError("ملف الجلسة تالف وجاري حذفه...");
              await authManager?.clearSession();
              break;
            case DisconnectReason.connectionClosed:
              authManager?.showConnectionStatus("disconnected");
              logger.info("🔄 تم إغلاق الاتصال. جاري محاولة إعادة الاتصال...");
              break;
            case DisconnectReason.connectionLost:
              authManager?.showConnectionStatus("disconnected");
              logger.info("📡 فُقد الاتصال بالشبكة. جاري محاولة إعادة الاتصال...");
              break;
            case DisconnectReason.connectionReplaced:
              authManager?.showError("تم استبدال الاتصال بجلسة أخرى مفتوحة حالياً");
              await authManager?.clearSession();
              break;
            case DisconnectReason.timedOut:
              authManager?.showError("انتهت مهلة الاتصال");
              break;
            default:
              authManager?.showError("سبب غير معروف لفصل الاتصال");
          }

          global.GoatBot.isConnected = false;
          global.GoatBot.connectionStatus = "reconnecting";

          const retryDelay = Math.min(1000 * Math.pow(2, connectionAttempts - 1), 10000);
          setTimeout(() => {
            startConnection(phoneNumber, resolve, reject);
          }, retryDelay);
        } else {
          authManager?.showError("انتهت صلاحية الجلسة أو تم تسجيل الخروج");
          await authManager?.clearSession();
          global.GoatBot.isConnected = false;
          global.GoatBot.sessionValid = false;
          reject(new Error("Session expired"));
        }
      } else if (connection === "connecting") {
        authManager?.showConnectionStatus("connecting");
        global.GoatBot.connectionStatus = "connecting";
      } else if (connection === "open") {
        clearTimeout(connectionTimeout);
        connectionAttempts = 0;

        authManager?.showConnectionStatus("connected");

        global.GoatBot.user = sock.user;
        global.GoatBot.isConnected = true;
        global.GoatBot.sessionValid = true;
        global.GoatBot.connectionStatus = "connected";
        global.GoatBot.waitingForAuth = false;
        global.GoatBot.qrCode = null; // تنظيف الـ QR بعد الاتصال الناجح
        global.GoatBot.sock = sock; // حفظ السوكيت للاستخدام اللاحق

        /* logger.info("📦 جاري تحميل الإضافات والبلجنات...");
        try {
          loadPlugins(logger);
          logger.info("✅ تم تحميل جميع الإضافات بنجاح");
        } catch (error) {
          logger.error("❌ فشل في تحميل بعض الإضافات:", error);
        }

        logger.info("🎉 البوت جاهز للاستخدام الآن!"); */

        await sendWelcomeMessage();

        resolve(sock);
      }
    });

    sock.ev.on("creds.update", saveCreds);

    // مستمع إضافي لمراقبة الجلسة والتأكد من عدم تركها معلقة
    sock.ev.on("connection.update", (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === "close") {
        const shouldReconnect =
          lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;

        if (shouldReconnect) {
          logger.info("🔄 فُقد الاتصال، جاري إعادة التشغيل تلقائياً للطبقة...");
          setTimeout(() => {
            process.exit(2); // الخروج بكود إعادة التشغيل لـ PM2
          }, 2000);
        } else {
          logger.error("❌ تم تسجيل الخروج من واتساب، يرجى إعادة الفحص والمصادقة");
          process.exit(1);
        }
      }
    });

    // مستمع الرسائل الواردة والمعالجة الأساسية
    sock.ev.on("messages.upsert", async (m) => {
      try {
        if (!global.GoatBot.isConnected) return;

        const msg = m.messages[0];
        if (!msg?.message || msg.key.fromMe) return;
        if (config.antiInbox && !msg.key.remoteJid.endsWith("@g.us")) return;

        global.GoatBot.stats.messagesProcessed++;

        try {
          await messageHandler({
            sock,
            event: m,
            msg,
            config,
            db: require("../database/manager"),
            logger,
          });
        } catch (messageError) {
          console.error("❌ خطأ أثناء معالجة الرسالة للويندوز/الهاندلر:", messageError);
          // التعامل مع أخطاء التشفير المحددة لمنع توقف السيرفر
          if (
            messageError.message?.includes("Bad MAC") ||
            messageError.message?.includes("decrypt") ||
            messageError.message?.includes("Failed to decrypt")
          ) {
            logger.warn(
              `🔑 فشل فك تشفير الرسالة لـ ${msg.key.remoteJid}: ${messageError.message}`
            );

            // معالجة خطأ فك التشفير
            await handleDecryptionError(msg.key.remoteJid, messageError);

            // لا تقم بعمل كراش، فقط استمر في العمل
            return;
          }

          // للأخطاء الأخرى، قم بتسجيل اللوج والاستمرار
          logger.error(`❌ خطأ في معالجة البنية التحتية للرسالة: ${messageError.message}`);
          global.GoatBot.stats.errors++;
        }
      } catch (error) {
        // التعامل مع الأخطاء المتعلقة بالجلسة بالكامل
        if (error.message?.includes("Bad MAC") || error.message?.includes("session")) {
          logger.error("❌ تم اكتشاف خطأ في الجلسة الكلية:", error.message);
          logger.info("🔄 جاري إعادة تشغيل الاتصال بالكامل...");

          // تعيين كغير متصل
          global.GoatBot.isConnected = false;
          global.GoatBot.sessionValid = false;

          // إعادة تشغيل العملية
          setTimeout(() => {
            process.exit(2); // الخروج بكود إعادة التشغيل
          }, 1000);
        } else {
          logger.error("❌ خطأ علوي أثناء معالجة الرسالة الواردة:", error);
          global.GoatBot.stats.errors++;
        }
      }
    });

    // مستمع أحداث المجموعات (انضمام، مغادرة، طرد)
    sock.ev.on("group-participants.update", async (update) => {
      try {
        if (!global.GoatBot.isConnected) return;

        const welcomeEvent = global.GoatBot.events.get("welcome");
        if (welcomeEvent) {
          const DataUtils = require("../libs/dataUtils");
          const { getUserName } = require("../libs/utils");

          // إنشاء كائنات خدمات مساعدة مشابهة لهاندلر الأوامر الرئيسي
          const user = {
            getUser: async (userId) => await DataUtils.getUser(userId),
            updateUser: async (userId, data) => await DataUtils.updateUser(userId, data),
            addExperience: async (userId, amount) => {
              const userData = await DataUtils.getUser(userId);
              await DataUtils.updateUser(userId, {
                experience: (userData.experience || 0) + amount,
              });
            },
          };

          const thread = {
            getThread: async (threadId) => await DataUtils.getThread(threadId || update.id),
            updateThread: async (data) => await DataUtils.updateThread(update.id, data),
          };

          const utils = {
            getUserName: async (userId) => await getUserName(userId),
          };

          await welcomeEvent.onEvent({
            api: sock,
            event: update,
            db: require("../database/manager"),
            logger,
            user,
            thread,
            utils,
          });
        }
      } catch (error) {
        logger.error("❌ خطأ أثناء معالجة حدث المجموعة المحدث:", error);
        global.GoatBot.stats.errors++;
      }
    });

    // رفض المكالمات تلقائياً لحماية الحساب من التهنيج
    sock.ev.on("call", async (callInfo) => {
      try {
        for (const call of callInfo) {
          if (call.status === "offer") {
            await sock.rejectCall(call.id, call.from);
            logger.info(`📞 تم رفض مكالمة واردة تلقائياً من ${call.from}`);
          }
        }
      } catch (error) {
        logger.error("❌ خطأ أثناء معالجة رفض المكالمة المفاجئة:", error);
      }
    });

    // مستمع لحالات التواجد والظهور (الـ Presence)
    sock.ev.on("presence.update", async (presenceUpdate) => {
      try {
        // يمكنك معالجة وتتبع ظهور المستخدمين هنا إذا أردت مستقبلاً
      } catch (error) {
        logger.error("❌ خطأ أثناء التعامل مع تحديثات التواجد والظهور:", error);
      }
    });
  } catch (error) {
    authManager?.showError("فشل الاتصال الكلي للطبقة", error);
    global.GoatBot.stats.errors++;
    reject(error);
  }
}

async function sendWelcomeMessage() {
  try {
    if (config.admins && config.admins.length > 0) {
      const welcomeText = `🐐 *تم اتصال GOAT Bot بنجاح!*\n\n✅ طريقة المصادقة: ${
        global.GoatBot.authMethod
      }\n⏰ وقت التشغيل: ${new Date().toLocaleString()}\n📊 لوحة التحكم: http://localhost:${
        process.env.PORT || 3000
      }\n\n🚀 البوت جاهز تماماً وبكامل قواه لاستقبال الأوامر الآن!`;

      await sock.sendMessage(config.admins[0], {
        text: welcomeText,
      });

      logger.info("📨 تم إرسال رسالة الترحيب والتشغيل بنجاح للمطور المسؤول");
    }
  } catch (error) {
    logger.warn("⚠️ تعذر إرسال رسالة التشغيل الترحيبية للمطور الرئيسي:", error.message);
  }
}

// تصدير الأدوات والخدمات المساعدة الإضافية للاتصال خارجياً
module.exports = {
  connect,
  getSock: () => sock,
  getConnectionStatus: () => global.GoatBot.connectionStatus,
  isConnected: () => global.GoatBot.isConnected,
  getAuthManager: () => authManager,
  restart: async () => {
    if (sock) {
      sock.end();
    }
    connectionAttempts = 0;
    return connect();
  },
};
