// المتغيرات العامة للنظام (Global Variables)
let currentTab = 'dashboard';
let sidebarCollapsed = false;
let isAuthenticated = false;
let otpTimer = null;
let otpTimeLeft = 300; // مدة الصلاحية: 5 دقائق

/**
 * نظام إدارة واجهات التحكم والمصادقة - Matrix-Bot
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 * المشروع: Matrix-Bot (Dashboard JavaScript Engine)
 */

// إظهار نافذة تسجيل الدخول وإخفاء اللوحة الرئيسية
function showLogin() {
    document.querySelector('.login-container').style.display = 'flex';
    document.querySelector('.dashboard').style.display = 'none';
}

// إظهار اللوحة الرئيسية للتحكم وحفظ حالة تسجيل الدخول
function showDashboard() {
    document.querySelector('.login-container').style.display = 'none';
    document.querySelector('.dashboard').style.display = 'block';
    isAuthenticated = true;
    loadDashboardData();
}

// التبديل بين طرق تسجيل الدخول (OTP أو كلمة المرور)
function showLoginTab(tabName) {
    // إزالة التفعيل عن كافة أزرار التبويب
    document.querySelectorAll('.login-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // إزالة التفعيل عن كافة نماذج تسجيل الدخول
    document.querySelectorAll('.login-method').forEach(method => {
        method.classList.remove('active');
    });
    
    // تفعيل التبويب المختار
    event.target.classList.add('active');
    
    // إظهار النموذج المتوافق مع الاختيار
    document.getElementById(tabName + '-login').classList.add('active');
}

// معالجة الدخول التقليدي عبر كلمة المرور
function passwordLogin() {
    const password = document.getElementById('adminPassword').value;
    if (!password) {
        showAlert('عذراً، يرجى إدخال كلمة المرور أولاً!', 'error');
        return;
    }

    const loginBtn = document.getElementById('passwordLoginBtn');
    loginBtn.disabled = true;
    loginBtn.innerHTML = '<span class="spinner"></span>جاري التحقق والدخول...';

    fetch('/api/auth/login-password', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ password: password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            localStorage.setItem('authToken', data.token);
            showDashboard();
            showAlert('تم تسجيل الدخول بنجاح! أهلاً بك.', 'success');
        } else {
            showAlert(data.message || 'كلمة المرور غير صحيحة، حاول مجدداً!', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('حدث خطأ أثناء الاتصال بالسيرفر. يرجى المحاولة لاحقاً.', 'error');
    })
    .finally(() => {
        loginBtn.disabled = false;
        loginBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> تسجيل الدخول';
    });
}

// طلب إرسال رمز التحقق OTP إلى الإدارة
function requestOTP() {
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span>جاري إرسال الرمز...';

    fetch('/api/auth/request-otp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showOTPForm();
            startOTPTimer();
            showAlert('تم إرسال رمز الـ OTP إلى هواتف المسؤولين بنجاح!', 'success');
        } else {
            showAlert(data.message || 'فشل إرسال رمز التحقق، يرجى مراجعة السيرفر.', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('حدث خطأ أثناء طلب الرمز. يرجى المحاولة مرة أخرى.', 'error');
    })
    .finally(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'إرسال رمز OTP الآن';
    });
}

// التحقق من الرمز المدخل المكون من 6 أرقام
function verifyOTP() {
    const otpInputs = document.querySelectorAll('.otp-input');
    const otp = Array.from(otpInputs).map(input => input.value).join('');
    
    if (otp.length !== 6) {
        showAlert('يرجى تعبئة رمز الـ OTP كاملاً (6 أرقام)!', 'error');
        return;
    }

    const verifyBtn = document.getElementById('verifyBtn');
    verifyBtn.disabled = true;
    verifyBtn.innerHTML = '<span class="spinner"></span>جاري التأكيد...';

    fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ otp: otp })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            localStorage.setItem('authToken', data.sessionId);
            showDashboard();
            showAlert('تم التحقق والدخول بنجاح!', 'success');
        } else {
            showAlert(data.message || 'رمز التحقق غير صحيح أو انتهت صلاحيته!', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert('حدث خطأ أثناء معالجة الرمز. أعد المحاولة.', 'error');
    })
    .finally(() => {
        verifyBtn.disabled = false;
        verifyBtn.innerHTML = 'التحقق من الرمز ودخول';
    });
}

// التبديل لإظهار حقول إدخال أرقام الـ OTP
function showOTPForm() {
    document.querySelector('.phone-container').style.display = 'none';
    document.querySelector('.otp-container').style.display = 'block';
}

// دالة حقن وعرض التنبيهات العلوية داخل كرت تسجيل الدخول
function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    const container = document.querySelector('.login-card');
    const existingAlert = container.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    container.insertBefore(alertDiv, container.firstChild);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// تشغيل عداد الوقت التنازلي لصلاحية الـ OTP
function startOTPTimer() {
    otpTimeLeft = 300;
    const timerElement = document.getElementById('otpTimer');
    const resendBtn = document.getElementById('resendOTP');
    
    resendBtn.style.display = 'none';
    
    otpTimer = setInterval(() => {
        const minutes = Math.floor(otpTimeLeft / 60);
        const seconds = otpTimeLeft % 60;
        timerElement.textContent = `الوقت المتبقي: ${minutes}:${seconds.toString().padStart(2, '0')}`;
        
        if (otpTimeLeft <= 0) {
            clearInterval(otpTimer);
            timerElement.textContent = 'انتهت صلاحية الرمز الحالية!';
            resendBtn.style.display = 'inline-block';
        }
        
        otpTimeLeft--;
    }, 1000);
}

// طلب إعادة إرسال الرمز مرة أخرى عند انتهاء العداد
function resendOTP() {
    clearInterval(otpTimer);
    requestOTP();
}

// تسجيل الخروج وتنظيف التوكن والجلسات المحلية
function logout() {
    localStorage.removeItem('authToken');
    isAuthenticated = false;
    showLogin();
    // إعادة تعيين واجهة الـ OTP للحالة الافتراضية
    document.querySelector('.phone-container').style.display = 'block';
    document.querySelector('.otp-container').style.display = 'none';
    document.querySelectorAll('.otp-input').forEach(input => input.value = '');
    clearInterval(otpTimer);
}

// تنظيم حركة التنقل التلقائي بين خانات إدخال الـ OTP
function setupOTPInputs() {
    const otpInputs = document.querySelectorAll('.otp-input');
    
    otpInputs.forEach((input, index) => {
        input.addEventListener('input', (e) => {
            if (e.target.value.length === 1) {
                if (index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus(); // القفز للخانة التالية عند الكتابة
                }
            }
        });
        
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !e.target.value) {
                if (index > 0) {
                    otpInputs[index - 1].focus(); // الرجوع للخانة السابقة عند الحذف
                }
            }
        });
    });
}

// نظام التبديل بين تبويبات اللوحة الجانبية (Tabs Navigation)
function showTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    document.getElementById(tabName + '-tab').classList.add('active');
    event.target.classList.add('active');
    
    currentTab = tabName;
    loadTabData(tabName);
}

// تصغير أو توسيع القائمة الجانبية لإعطاء مساحة أكبر لعرض الجداول
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    
    sidebarCollapsed = !sidebarCollapsed;
    
    if (sidebarCollapsed) {
        sidebar.classList.add('collapsed');
        mainContent.classList.add('expanded');
    } else {
        sidebar.classList.remove('collapsed');
        mainContent.classList.remove('expanded');
    }
}

// تنسيق وتحويل ثواني التشغيل المستمر إلى صيغة زمنية مفهومة ومفصلة
function formatUptime(seconds) {
    const years = Math.floor(seconds / (365.25 * 24 * 3600));
    const months = Math.floor((seconds % (365.25 * 24 * 3600)) / (30.44 * 24 * 3600));
    const days = Math.floor((seconds % (30.44 * 24 * 3600)) / (24 * 3600));
    const hours = Math.floor((seconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    return { years, months, days, hours, minutes, seconds: secs };
}

// تحديث لوحة تشغيل البوت وذاكرة الـ RAM بشكل حي ومستمر
function updateUptime() {
    if (!isAuthenticated) return;
    
    fetch('/api/system', {
        headers: {
            'Authorization': 'Bearer ' + localStorage.getItem('authToken')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.uptime) {
            const uptime = formatUptime(data.uptime);
            document.getElementById('uptimeYears').textContent = uptime.years;
            document.getElementById('uptimeMonths').textContent = uptime.months;
            document.getElementById('uptimeDays').textContent = uptime.days;
            document.getElementById('uptimeHours').textContent = uptime.hours;
            document.getElementById('uptimeMinutes').textContent = uptime.minutes;
            document.getElementById('uptimeSeconds').textContent = uptime.seconds;
        }
        
        if (data.memory) {
            document.getElementById('memoryUsage').textContent = Math.round(data.memory.used / 1024 / 1024) + ' ميجابايت';
        }
    })
    .catch(error => console.error('Error updating uptime:', error));
}

// موجه تحميل البيانات البرمجية بناءً على التبويب المفتوح حالياً
function loadTabData(tabName) {
    if (!isAuthenticated) return;
    
    switch(tabName) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'bot-info':
            loadBotInfo();
            break;
        case 'commands':
            loadCommands();
            break;
        case 'users':
            loadUsers();
            break;
        case 'groups':
            loadGroups();
            break;
        case 'system':
            loadSystemInfo();
            break;
        case 'analytics':
            loadAnalytics();
            break;
        case 'settings':
            loadSettings();
            break;
        case 'whatsapp-auth':
            loadWhatsAppAuth();
            break;
    }
}

// تهيئة نظام تتبع اتصال تطبيق الواتساب وبدء فحص الـ 5 ثواني الدوري
function loadWhatsAppAuth() {
    checkWhatsAppStatus();
    setInterval(checkWhatsAppStatus, 5000);
}

// الاستعلام عن حالة مصادقة الواتساب الحالية بالسيرفر الخلفي
function checkWhatsAppStatus() {
    apiRequest('/api/whatsapp/auth/status')
        .then(data => {
            updateAuthStatus(data);
        })
        .catch(error => {
            console.error('Error checking WhatsApp status:', error);
            addAuthLog('خطأ أثناء التحقق من اتصال الواتساب: ' + error.message);
        });
}

// تحديث مؤشرات التوصيل والرموز (QR / Pairing Code) بناءً على رد السيرفر
function updateAuthStatus(data) {
    const statusDot = document.getElementById('connectionStatus');
    const statusText = document.getElementById('connectionText');
    
    if (data.connected) {
        statusDot.className = 'status-dot connected';
        statusText.textContent = 'متصل بحساب الواتساب بنجاح';
        addAuthLog('جلسة الواتساب مستقرة ونشطة الآن بالخلفية');
    } else {
        statusDot.className = data.connectionStatus === 'connecting' ? 'status-dot connecting' : 'status-dot';
        statusText.textContent = data.connectionStatus === 'connecting' ? 'جاري محاولة تأسيس اتصال بالواتساب...' : 'غير متصل بالواتساب حالياً';
        
        if (data.lastError) {
            addAuthLog('آخر خطأ رصده الخادم: ' + data.lastError);
        }
    }
    
    // فحص وتحديث كود المزامنة اللاسلكية QR
    if (data.qrCode) {
        showQRCode(data.qrCode);
    } else {
        hideQRCode();
    }
    
    // فحص وتحديث كود الاقتران الرقمي المباشر
    if (data.pairingCode) {
        showPairingCode(data.pairingCode);
    } else {
        hidePairingCode();
    }
}

// حقن وعرض كود الـ QR مجهزاً للمسح
function showQRCode(qrCode) {
    const container = document.getElementById('qrCodeContainer');
    const qrElement = document.getElementById('qrCode');
    
    if (qrCode.startsWith('data:image/')) {
        qrElement.innerHTML = `<img src="${qrCode}" alt="Matrix-Bot QR Code" style="max-width: 100%; height: auto;">`;
    } else {
        qrElement.innerHTML = `<div class="qr-placeholder">رمز الـ QR جاهز ومتاح بالخادم - يرجى المسح بالتطبيق حالياً</div>`;
    }
    
    container.style.display = 'block';
}

function hideQRCode() {
    document.getElementById('qrCodeContainer').style.display = 'none';
}

function showPairingCode(code) {
    const container = document.getElementById('pairingCodeContainer');
    const codeElement = document.getElementById('pairingCode');
    
    codeElement.textContent = code;
    container.style.display = 'block';
}

function hidePairingCode() {
    document.getElementById('pairingCodeContainer').style.display = 'none';
}

// إضافة سطر لوق (Log) جديد في مستودع مراقبة الاتصال الفوري بالواجهة
function addAuthLog(message) {
    const logContainer = document.getElementById('authLogs');
    const logEntry = document.createElement('div');
    logEntry.className = 'log-entry';
    
    const timestamp = new Date().toLocaleTimeString();
    logEntry.innerHTML = `
        <span class="log-time">${timestamp}</span>
        <span class="log-message">${message}</span>
    `;
    
    logContainer.appendChild(logEntry);
    logContainer.scrollTop = logContainer.scrollHeight;
    
    // تصفية وحذف السطور القديمة للحفاظ على الذاكرة عند تخطي 50 سطر لوق
    const entries = logContainer.querySelectorAll('.log-entry');
    if (entries.length > 50) {
        entries[0].remove();
    }
}

// زر بدء طلب جلسة اقتران جديدة للواتساب
function startWhatsAppAuth() {
    const btn = document.getElementById('startAuthBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>جاري التشغيل...';
    
    apiRequest('/api/whatsapp/auth/request-code', { method: 'POST' })
        .then(data => {
            if (data.success) {
                addAuthLog('تم إطلاق طلب المصادقة وجلب أكواد الربط بالسيرفر');
                showAlert('تم بدء عملية المصادقة بالنجاح!', 'success');
            } else {
                addAuthLog('فشل تفعيل المصادقة: ' + data.message);
                showAlert(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error starting WhatsApp auth:', error);
            addAuthLog('خطأ استجابة من الخادم: ' + error.message);
            showAlert('حدث خطأ غير متوقع أثناء تفعيل المصادقة', 'error');
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-play"></i> بدء جلسة ربط جديدة';
        });
}

// زر فصل وتدمير جلسة اتصال حساب الواتساب من السيرفر
function disconnectWhatsApp() {
    const btn = document.getElementById('disconnectBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>جاري قطع الاتصال...';
    
    apiRequest('/api/whatsapp/auth/disconnect', { method: 'POST' })
        .then(data => {
            if (data.success) {
                addAuthLog('تم إلغاء وإنهاء ربط حساب الواتساب نهائياً');
                showAlert('تم إنهاء ربط الحساب بنجاح وعزل البوت.', 'success');
            } else {
                addAuthLog('فشل إلغاء الربط: ' + data.message);
                showAlert(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error disconnecting from WhatsApp:', error);
            addAuthLog('خطأ أثناء إلغاء الربط: ' + error.message);
            showAlert('حدث خطأ أثناء محاولة فصل الحساب الموصول', 'error');
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-unlink"></i> إنهاء وقطع اتصال الحساب';
        });
}

// زر إعادة تنشيط وتشغيل محرك اقتران السوكت بالخادم
function restartWhatsAppAuth() {
    const btn = document.getElementById('restartAuthBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span>جاري إعادة التشغيل...';
    
    apiRequest('/api/whatsapp/auth/restart', { method: 'POST' })
        .then(data => {
            if (data.success) {
                addAuthLog('تمت إعادة تهيئة وإقلاع نظام الاقتران فورياً');
                showAlert('تمت إعادة تشغيل جلسة الاقتران بنجاح.', 'success');
            } else {
                addAuthLog('فشل إعادة التشغيل: ' + data.message);
                showAlert(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error restarting WhatsApp auth:', error);
            addAuthLog('فشل إعادة التشغيل البرمجية: ' + error.message);
            showAlert('حدث خطأ أثناء محاولة إعادة تشغيل نظام الربط', 'error');
        })
        .finally(() => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-redo"></i> إعادة تشغيل جلسة الاقتران';
        });
}

// دالة مركزية موحدة لمعالجة طلبات الـ Fetch مع حقن رموز المصادقة Bearer Token تلقائياً
function apiRequest(endpoint, options = {}) {
    const token = localStorage.getItem('authToken');
    const defaultOptions = {
        headers: {
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }
    };
    
    return fetch(endpoint, { ...defaultOptions, ...options })
        .then(response => {
            if (response.status === 401) {
                logout(); // إخراج المستخدم تلقائياً إن انتهت صلاحية التوكن بالسيرفر
                throw new Error('جلسة غير مصرحة أو منتهية الصلاحية');
            }
            return response.json();
        });
}

// جلب وتحديث كامل باقة بيانات وإحصائيات اللوحة الرئيسية دفعة واحدة عبر تقنية Promise.all
function loadDashboardData() {
    Promise.all([
        apiRequest('/api/users'),
        apiRequest('/api/groups'),
        apiRequest('/api/system'),
        apiRequest('/api/bot/info'),
        apiRequest('/api/analytics/overview')
    ]).then(([users, groups, system, botInfo, analytics]) => {
        const setText = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        };
        // توزيع البيانات وتحديث واجهة المستخدم العربية
        setText('totalUsers', users.total || 0);
        setText('totalGroups', groups.total || 0);
        setText('activeUsers', users.active || 0);
        setText('activeGroups', groups.active || 0);
        setText('botName', botInfo.name || 'Matrix Bot');
        setText('commandsLoaded', botInfo.commandsLoaded || 0);
        
        if (analytics) {
            updateAnalyticsDisplay(analytics);
        }
        const loadingEl = document.getElementById('loading');
        if (loadingEl) loadingEl.style.display = 'none';
    }).catch(error => {
        console.error('Error loading dashboard:', error);
        const errorEl = document.getElementById('error');
        if (errorEl) {
            errorEl.innerHTML = '<div class="error-message">حدث خطأ فادح أثناء جلب وتحديث بيانات لوحة التحكم: ' + (error.message || error) + '</div>';
            errorEl.style.display = 'block';
        }
        const loadingEl = document.getElementById('loading');
        if (loadingEl) loadingEl.style.display = 'none';
    });
}

// جلب تفاصيل وبيانات نواة تشغيل البوت والمسؤولين المسجلين في النظام
function loadBotInfo() {
    apiRequest('/api/bot/info')
        .then(data => {
            document.getElementById('botName').textContent = data.name || 'Matrix Bot';
            document.getElementById('botVersion').textContent = data.version || '1.0.0';
            document.getElementById('botStatusText').textContent = data.status || 'متصل ونشط';
            document.getElementById('botUptime').textContent = data.uptime || '0 ثانية';
            document.getElementById('commandsLoaded').textContent = data.commandsLoaded || 0;
            document.getElementById('eventsLoaded').textContent = data.eventsLoaded || 0;
            document.getElementById('lastRestart').textContent = data.lastRestart || 'لم يتم رصد إعادة تشغيل';
            document.getElementById('adminUsers').textContent = data.adminUsers || 0;
        })
        .catch(error => {
            console.error('Error loading bot info:', error);
            showAlert('فشل سحب تفاصيل البوت من السيرفر: ' + error.message, 'error');
        });
}

// جلب وعرض قائمة الأوامر والميزات المفعلة بالسيستم مع تصنيفاتها بطريقة منسقة
function loadCommands() {
    apiRequest('/api/commands')
        .then(data => {
            const commandsList = document.getElementById('commandsList');
            commandsList.innerHTML = '';
            
            if (data.commands && data.commands.length > 0) {
                data.commands.forEach(command => {
                    const commandItem = document.createElement('div');
                    commandItem.className = 'list-item';
                    commandItem.innerHTML = `
                        <div class="item-info text-start">
                            <h6>الأمر: ${command.name}</h6>
                            <p>الوصف: ${command.description || 'لا يوجد وصف متاح لهذا الأمر حالياً'}</p>
                            <small class="text-muted">طريقة الاستخدام: ${command.usage || 'تلقائي'}</small>
                        </div>
                        <div class="item-badges">
                            <span class="badge bg-primary command-category">${command.category || 'عام'}</span>
                            ${command.role ? `<span class="badge bg-info">رتبة: ${command.role}</span>` : ''}
                        </div>
                    `;
                    commandsList.appendChild(commandItem);
                });
            } else {
                commandsList.innerHTML = '<div class="text-center text-muted">لم يتم العثور على أي أوامر برمجية مسجلة!</div>';
            }
        })
        .catch(error => {
            console.error('Error loading commands:', error);
            document.getElementById('commandsList').innerHTML = '<div class="error-message">حدث خطأ داخلي أثناء معالجة مصفوفة الأوامر</div>';
        });
}

// جلب قائمة مستخدمي البوت وحالات الحظر ومستويات النشاط والتفاعل
function loadUsers() {
    apiRequest('/api/users')
        .then(data => {
            const usersList = document.getElementById('usersList');
            usersList.innerHTML = '';
            
            if (data.users && data.users.length > 0) {
                data.users.forEach(user => {
                    const userItem = document.createElement('div');
                    userItem.className = 'list-item';
                    userItem.innerHTML = `
                        <div class="item-info text-start">
                            <h6>الاسم: ${user.name || 'مستخدم غير معروف'}</h6>
                            <p>المعرف الإشاري: ${user.id}</p>
                            <small class="text-muted">الخبرة: ${user.exp || 0} xp | عدد الرسائل الصادرة منه: ${user.messageCount || 0}</small>
                        </div>
                        <div class="item-badges">
                            <span class="badge bg-warning text-dark">المستوى ${user.level || 1}</span>
                            <span class="badge ${user.banned ? 'bg-danger' : 'bg-success'}">${user.banned ? 'محظور نهائياً' : 'نشط وفعال'}</span>
                            ${user.role > 0 ? `<span class="badge bg-info">صلاحية رقم: ${user.role}</span>` : ''}
                        </div>
                    `;
                    usersList.appendChild(userItem);
                });
            } else {
                usersList.innerHTML = '<div class="text-center text-muted">لا يوجد مستخدمين مسجلين في قواعد البيانات حالياً</div>';
            }
        })
        .catch(error => {
            console.error('Error loading users:', error);
            document.getElementById('usersList').innerHTML = '<div class="error-message">حدث خطأ غير متوقع أثناء عرض سجلات الأعضاء</div>';
        });
}

// جلب قائمة المجموعات (الجروبات) المضاف إليها البوت وتفاصيل التفاعل فيها
function loadGroups() {
    apiRequest('/api/groups')
        .then(data => {
            const groupsList = document.getElementById('groupsList');
            groupsList.innerHTML = '';
            
            if (data.groups && data.groups.length > 0) {
                data.groups.forEach(group => {
                    const groupItem = document.createElement('div');
                    groupItem.className = 'list-item';
                    groupItem.innerHTML = `
                        <div class="item-info text-start">
                            <h6>اسم المجموعة: ${group.name || 'مجموعة واتساب مبهمة'}</h6>
                            <p>رابط المعرف الخاص (ID): ${group.id}</p>
                            <small class="text-muted">عداد الرسائل المتبادلة: ${group.messageCount || 0}</small>
                        </div>
                        <div class="item-badges">
                            <span class="badge bg-info">${group.memberCount || 0} عضو مشارك</span>
                            <span class="badge ${group.isActive ? 'bg-success' : 'bg-secondary'}">${group.isActive ? 'تفاعل مفعل' : 'تفاعل معطل'}</span>
                        </div>
                    `;
                    groupsList.appendChild(groupItem);
                });
            } else {
                groupsList.innerHTML = '<div class="text-center text-muted">لا توجد مجموعات مسجلة بالذاكرة حالياً</div>';
            }
        })
        .catch(error => {
            console.error('Error loading groups:', error);
            document.getElementById('groupsList').innerHTML = '<div class="error-message">حدث خطأ أثناء معالجة ملفات المجموعات</div>';
        });
}

// جلب بيانات ومواصفات العتاد الصلب للسيرفر (CPU, Memory OS, Node) وعرضها عربياً
function loadSystemInfo() {
    apiRequest('/api/system')
        .then(data => {
            document.getElementById('platform').textContent = data.platform || 'غير معروف';
            document.getElementById('architecture').textContent = data.architecture || 'غير معروف';
            document.getElementById('nodeVersion').textContent = data.nodeVersion || 'غير معروف';
            document.getElementById('memoryTotal').textContent = Math.round((data.memory?.total || 0) / 1024 / 1024) + ' ميجابايت';
            document.getElementById('systemMemoryUsage').textContent = Math.round((data.memory?.used || 0) / 1024 / 1024) + ' ميجابايت';
            document.getElementById('loadAverage').textContent = data.loadAverage?.join(', ') || 'غير متاح';
            document.getElementById('freeMemory').textContent = Math.round((data.memory?.free || 0) / 1024 / 1024) + ' ميجابايت';
        })
        .catch(error => {
            console.error('Error loading system info:', error);
            showAlert('حدث خطأ أثناء معالجة بيانات العتاد المضيف: ' + error.message, 'error');
        });
}

function loadAnalytics() {
    apiRequest('/api/analytics')
        .then(data => {
            updateAnalyticsDisplay(data);
        })
        .catch(error => {
            console.error('Error loading analytics:', error);
            showAlert('فشل تحديث لوحة التحليلات الحيوية: ' + error.message, 'error');
        });
}

function loadSettings() {
    apiRequest('/api/settings')
        .then(data => {
            updateSettingsDisplay(data);
        })
        .catch(error => {
            console.error('Error loading settings:', error);
            showAlert('فشل جلب ملف التكوينات التلقائية: ' + error.message, 'error');
        });
}

// رسم وبناء كروت قسم التحليلات البيانية والرسومية بلغة عربية فصيحة وبسيطة
function updateAnalyticsDisplay(data) {
    if (!data) return;
    
    const analyticsContainer = document.getElementById('analyticsContainer');
    if (analyticsContainer) {
        analyticsContainer.innerHTML = `
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body text-start">
                            <h6 class="text-muted">الرسائل المستلمة اليوم</h6>
                            <h3 class="text-primary fw-bold">${data.messagesToday || 0} رسالة</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body text-start">
                            <h6 class="text-muted">إجمالي الأوامر المستدعاة</h6>
                            <h3 class="text-success fw-bold">${data.commandsUsed || 0} استدعاء</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="card-body text-start">
                            <h6 class="text-muted">الجلسات المفتوحة والنشطة</h6>
                            <h3 class="text-info fw-bold">${data.activeSessions || 0} جلسة سحابية</h3>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}

// رسم وإعداد هيكلية لوحة إعدادات البوت والتحكم بالمتغيرات العامة المتوفرة بملف الـ Config
function updateSettingsDisplay(data) {
    if (!data) return;
    
    const settingsContainer = document.getElementById('settingsContainer');
    if (settingsContainer) {
        settingsContainer.innerHTML = `
            <div class="card shadow-sm border-0">
                <div class="card-body text-start">
                    <h5 class="mb-4 fw-bold"><i class="fas fa-sliders-h me-2"></i> تكوينات نظام Matrix-Bot الأساسية</h5>
                    <div class="system-metric d-flex justify-content-between align-items-center py-2 border-bottom">
                        <span class="metric-label fw-bold">البادئة الافتراضية لتشغيل الأوامر (Prefix):</span>
                        <span class="metric-value badge bg-secondary px-3 py-2 fs-6">${data.prefix || '.'}</span>
                    </div>
                    <div class="system-metric d-flex justify-content-between align-items-center py-2 border-bottom">
                        <span class="metric-label fw-bold">تفعيل تشغيل الأوامر للمطورين فقط (Admin Only):</span>
                        <span class="metric-value fw-bold text-primary">${data.adminOnly ? 'نعم، مفعل حالياً' : 'لا، متاح للعامة'}</span>
                    </div>
                    <div class="system-metric d-flex justify-content-between align-items-center py-2">
                        <span class="metric-label fw-bold">نظام إعادة التشغيل التلقائي عند حدوث كراش (Auto Restart):</span>
                        <span class="metric-value fw-bold text-success">${data.autoRestart ? 'مفعل وجاهز للتأمين' : 'معطل'}</span>
                    </div>
                </div>
            </div>
        `;
    }
}

// تفعيل نظام فلاتر البحث التلقائي الفوري والتصفية الديناميكية لجميع جداول النظام والقوائم
function setupSearch() {
    const searchInputs = [
        { input: 'commandSearch', container: '#commandsList .list-item' },
        { input: 'userSearch', container: '#usersList .list-item' },
        { input: 'groupSearch', container: '#groupsList .list-item' }
    ];

    searchInputs.forEach(({ input, container }) => {
        const searchInput = document.getElementById(input);
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const search = this.value.toLowerCase();
                document.querySelectorAll(container).forEach(item => {
                    const text = item.textContent.toLowerCase();
                    item.style.display = text.includes(search) ? 'flex' : 'none'; // التصفية اللحظية الفورية
                });
            });
        }
    });
}

// دالة فحص وتوثيق الجلسة المسجلة والتأكد من أمان الـ Token فور فتح الصفحة
function checkAuth() {
    const token = localStorage.getItem('authToken');
    if (token) {
        fetch('/api/auth/verify', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.valid) {
                showDashboard();
            } else {
                localStorage.removeItem('authToken');
                showLogin();
            }
        })
        .catch(() => {
            localStorage.removeItem('authToken');
            showLogin();
        });
} else {
        showLogin();
    }
}

// نقطة البداية وتشغيل التطبيق فور اكتمال معالجة واجهة مستند الـ DOM الرئيسي للموقع
document.addEventListener('DOMContentLoaded', function() {
    setupOTPInputs();
    setupSearch();
    checkAuth();
    
    // المزامنة التلقائية وجلب البيانات الحية كل 30 ثانية لتحديث الكروت دورياً
    setInterval(() => {
        if (isAuthenticated) {
            updateUptime();
            if (currentTab === 'dashboard') {
                loadDashboardData();
            }
        }
    }, 30000);
    
    // ربط وتحديث مؤشر الـ Uptime كل ثانية واحدة بشكل سلس
    setInterval(updateUptime, 1000);
});

// ربط مستمعي الأحداث والـ Event Listeners بجميع أزرار الأكشن المتوفرة بالصفحات
document.getElementById('submitBtn')?.addEventListener('click', requestOTP);
document.getElementById('verifyBtn')?.addEventListener('click', verifyOTP);
document.getElementById('resendOTP')?.addEventListener('click', resendOTP);
document.getElementById('passwordLoginBtn')?.addEventListener('click', passwordLogin);
document.getElementById('logoutBtn')?.addEventListener('click', logout);

// السماح بتمرير تسجيل الدخول بكلمة المرور فور النقر على زر Enter باللوحة
document.getElementById('adminPassword')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        passwordLogin();
    }
});

// تأمين حقول الـ OTP ومنع قبول أي مدخلات غير رقمية نهائياً (تصفية المدخلات عبر Regex)
document.querySelectorAll('.otp-input').forEach(input => {
    input.addEventListener('input', function(e) {
        this.value = this.value.replace(/\D/g, '');
    });
});

// تصدير الدوال البرمجية الحيوية لنطاق الـ Window العام لضمان استدعائها من ملف الـ HTML مباشرة
window.showTab = showTab;
window.toggleSidebar = toggleSidebar;
window.logout = logout;
window.showLoginTab = showLoginTab;
window.startWhatsAppAuth = startWhatsAppAuth;
window.disconnectWhatsApp = disconnectWhatsApp;
window.restartWhatsAppAuth = restartWhatsAppAuth;
