const { MongoClient } = require("mongodb")
let client
let db
let userCollection
let threadCollection
let dataCollection

/**
 * محرك استعلامات قاعدة البيانات السحابية المتقدمة MongoDB - Matrix-Bot
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 * المشروع: Matrix-Bot (MongoDB Cloud Core Engine)
 */
module.exports = {
  /**
   * دالة الاتصال بخادم الـ MongoDB السحابي وتأمين المجموعات والفهارس
   * @param {string} uri - رابط الاتصال المشفر الخاص بقاعدة البيانات
   */
  connect: async (uri) => {
    client = new MongoClient(uri)
    await client.connect()
    db = client.db("whatsapp_bot")
    
    // إنشاء وعزل المجموعات (Collections) لتقسيم الجداول تنظيمياً بالخادم
    userCollection = db.collection("users")
    threadCollection = db.collection("threads")
    dataCollection = db.collection("data")
    
    // حقن الفهارس (Indexes) على المفاتيح الرئيسية لتسريع عمليات البحث والجلب
    await userCollection.createIndex({ "_id": 1 })
    await threadCollection.createIndex({ "_id": 1 })
    await dataCollection.createIndex({ "_id": 1 })
  },
  
  /**
   * جلب وقراءة بيانات مفتاح معين بناءً على نوع البادئة الممررة
   * @param {string} key - المفتاح المراد البحث عنه
   */
  get: (key) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      return threadCollection.findOne({ _id: threadId }).then(doc => doc ? doc.data : undefined)
    }
    if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      return userCollection.findOne({ _id: userId }).then(doc => doc ? doc.data : undefined)
    }
    return dataCollection.findOne({ _id: key }).then(doc => doc ? doc.data : undefined)
  },
  
  /**
   * حفظ وتحديث البيانات مع ميزة الـ Upsert الذكية لحقن المستندات الجديدة تلقائياً
   */
  set: async (key, value) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      await threadCollection.updateOne(
        { _id: threadId }, 
        { $set: { data: value, updatedAt: new Date() } }, 
        { upsert: true }
      )
    } else if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      await userCollection.updateOne(
        { _id: userId }, 
        { $set: { data: value, updatedAt: new Date() } }, 
        { upsert: true }
      )
    } else {
      await dataCollection.updateOne(
        { _id: key }, 
        { $set: { data: value, updatedAt: new Date() } }, 
        { upsert: true }
      )
    }
  },
  
  /**
   * حذف مستند وسجل معين نهائياً من مجموعات قاعدة البيانات السحابية
   */
  delete: async (key) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      await threadCollection.deleteOne({ _id: threadId })
    } else if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      await userCollection.deleteOne({ _id: userId })
    } else {
      await dataCollection.deleteOne({ _id: key })
    }
  },
  
  /**
   * جلب وتصفية مجموعة مستندات كاملة بناءً على البادئة الممررة أو التعبيرات النمطية Regex
   */
  getByPrefix: async (prefix) => {
    if (prefix === "user_") {
      const users = await userCollection.find({}).toArray()
      const result = {}
      users.forEach(user => {
        result[user._id] = user.data
      })
      return result
    }
    if (prefix === "thread_") {
      const threads = await threadCollection.find({}).toArray()
      const result = {}
      threads.forEach(thread => {
        result[thread._id] = thread.data
      })
      return result
    }
    // استخدام محرك الـ Regex للبحث المرن داخل مجموعة البيانات العامة
    const data = await dataCollection.find({ _id: { $regex: `^${prefix}` } }).toArray()
    const result = {}
    data.forEach(item => {
      result[item._id] = item.data
    })
    return result
  },
  
  /**
   * استخراج مصفوفة جرد كاملة تحوي كافة المعرفات (Keys) المسجلة في السحاب
   */
  getAllKeys: async () => {
    const userKeys = await userCollection.find({}, { projection: { _id: 1 } }).toArray()
    const threadKeys = await threadCollection.find({}, { projection: { _id: 1 } }).toArray()
    const dataKeys = await dataCollection.find({}, { projection: { _id: 1 } }).toArray()
    
    return [
      ...userKeys.map(k => `user_${k._id}`),
      ...threadKeys.map(k => `thread_${k._id}`),
      ...dataKeys.map(k => k._id)
    ]
  },
  
  /**
   * التحقق السريع من وجود مستند معين داخل السجلات عبر عد الوثائق المطابقة
   */
  has: async (key) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      const count = await threadCollection.countDocuments({ _id: threadId })
      return count > 0
    }
    if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      const count = await userCollection.countDocuments({ _id: userId })
      return count > 0
    }
    const count = await dataCollection.countDocuments({ _id: key })
    return count > 0
  },
  
  /**
   * تفكيك وتصدير نسخة شاملة وموحدة لكافة محتويات السيرفر السحابي بجميع تفاصيلها
   */
  getAllData: async () => {
    const users = await userCollection.find({}).toArray()
    const threads = await threadCollection.find({}).toArray()
    const data = await dataCollection.find({}).toArray()
    
    const usersData = {}
    const threadsData = {}
    const generalData = {}
    
    users.forEach(user => {
      usersData[user._id] = user.data
    })
    
    threads.forEach(thread => {
      threadsData[thread._id] = thread.data
    })
    
    data.forEach(item => {
      generalData[item._id] = item.data
    })
    
    return { data: generalData, threads: threadsData, users: usersData }
  },
  
  /**
   * جلب الإحصائيات الرقمية الإجمالية الحالية لحجم البيانات والملفات المخزنة في السحاب
   */
  getStats: async () => {
    const userCount = await userCollection.countDocuments()
    const threadCount = await threadCollection.countDocuments()
    const dataCount = await dataCollection.countDocuments()
    
    return {
      users: userCount,
      threads: threadCount,
      data: dataCount,
      total: userCount + threadCount + dataCount
    }
  }
}
