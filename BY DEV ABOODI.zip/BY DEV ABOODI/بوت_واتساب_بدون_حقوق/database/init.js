const fs = require('fs');
const path = require('path');

/**
 * تهيئة وإعداد هيكل قاعدة البيانات المحلية مع المخطط البرمجي الافتراضي - Matrix-Bot
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 * المشروع: Matrix-Bot (Database Initialization System)
 */
function initializeDatabase() {
  const dbPath = path.join(__dirname, '/data/data.json');
  
  // الهيكل البنيوي الافتراضي لقاعدة البيانات (Default Schema) عند التشغيل لأول مرة
  const defaultData = {
    // الإعدادات والإحصائيات العالمية للبوت
    global_settings: {
      initialized: true,
      version: "1.0.0",
      createdAt: Date.now(),
      totalUsers: 0,
      totalThreads: 0,
      totalMessages: 0
    },
    
    // نموذج توضيحي لهيكل البيانات (سيتم حقن المجلد تلقائياً عند تفاعل الأعضاء)
    // user_[userId]: {
    //   id: string,
    //   name: string,
    //   messageCount: number,
    //   firstSeen: timestamp,
    //   lastSeen: timestamp,
    //   experience: number,
    //   level: number,
    //   currency: number,
    //   warnings: number,
    //   banned: boolean,
    //   settings: object
    // },
    
    // thread_[threadId]: {
    //   id: string,
    //   isGroup: boolean,
    //   name: string,
    //   messageCount: number,
    //   firstActivity: timestamp,
    //   lastActivity: timestamp,
    //   participants: array,
    //   settings: object,
    //   warnings: number,
    //   banned: boolean
    // },
    
    // message_[messageId]: {
    //   id: string,
    //   body: string,
    //   sender: string,
    //   threadId: string,
    //   timestamp: timestamp,
    //   type: string,
    //   quoted: boolean,
    //   mentions: array
    // }
  };
  
  try {
    // 1. الفحص الاستباقي: التحقق مما إذا كان ملف قاعدة البيانات متواجداً بالفعل
    if (fs.existsSync(dbPath)) {
      const existingData = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      
      // حقن الإعدادات العالمية فقط في حال عدم وجودها مع الحفاظ على سجلات الأعضاء السابقة
      if (!existingData.global_settings) {
        existingData.global_settings = defaultData.global_settings;
        fs.writeFileSync(dbPath, JSON.stringify(existingData, null, 2));
        console.log('✅ [Matrix-DB] تم تحديث قاعدة البيانات بنجاح وحقن الإعدادات العالمية العامة.');
      } else {
        console.log('✅ [Matrix-DB] قاعدة البيانات مهيأة مسبقاً وتعمل مستقرة دون تداخل.');
      }
    } else {
      // 2. إنشاء قاعدة بيانات جديدة تماماً بالهيكل الافتراضي لعدم وجود ملف سابق
      // التأكد من وجود المجلد الأب 'data' قبل الكتابة لتفادي أخطاء المسارات
      const dirPath = path.dirname(dbPath);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }

      fs.writeFileSync(dbPath, JSON.stringify(defaultData, null, 2));
      console.log('✅ [Matrix-DB] تم إنشاء وتأمين ملف قاعدة البيانات الجديد بالهيكل الافتراضي بنجاح.');
    }
    
    return true;
  } catch (error) {
    console.error('❌ [Matrix-DB] فشل فادح أثناء محاولة تهيئة وتأمين قاعدة البيانات:', error);
    return false;
  }
}

// تشغيل دالة التهيئة فورياً تلقائياً في حال تم تنفيذ هذا الملف بشكل مستقل مباشر
if (require.main === module) {
  initializeDatabase();
}

module.exports = { initializeDatabase };
