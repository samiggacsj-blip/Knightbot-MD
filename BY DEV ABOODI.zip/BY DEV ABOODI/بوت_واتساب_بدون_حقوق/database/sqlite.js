const sqlite3 = require("sqlite3").verbose()
const path = require("path")

let db

/**
 * محرك استعلامات قاعدة البيانات المحلية الخفيفة SQLite - Matrix-Bot
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 * المشروع: Matrix-Bot (SQLite Local Core Engine)
 */
module.exports = {
  /**
   * دالة الاتصال بقاعدة بيانات الـ SQLite وبناء الجداول الهيكلية بالتتابع
   * @param {string} dbPath - مسار ملف قاعدة البيانات المحلي الافتراضي
   */
  connect: async (dbPath = "database.db") => {
    return new Promise((resolve, reject) => {
      const fullPath = path.join(__dirname, dbPath)
      db = new sqlite3.Database(fullPath, (err) => {
        if (err) {
          reject(err)
        } else {
          // استخدام وضع التسلسل (Serialize) لضمان بناء الجداول بالترتيب الصحيح
          db.serialize(() => {
            // 1. جدول المستخدمين (Users Table)
            db.run(`
              CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
              )
            `)
            
            // 2. جدول المجموعات والمحادثات (Threads Table)
            db.run(`
              CREATE TABLE IF NOT EXISTS threads (
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
              )
            `)
            
            // 3. جدول البيانات العامة وإعدادات النظام (General Data Table)
            db.run(`
              CREATE TABLE IF NOT EXISTS data (
                id TEXT PRIMARY KEY,
                data TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
              )
            `)
            
            resolve()
          })
        }
      })
    })
  },
  
  /**
   * جلب وقراءة سجل معين وتحويل النص المخرّج إلى كائن JSON تفاعلي
   * @param {string} key - المفتاح المراد الاستعلام عنه بناءً على بادئته
   */
  get: (key) => {
    return new Promise((resolve, reject) => {
      if (key.startsWith("thread_")) {
        const threadId = key.replace("thread_", "")
        db.get("SELECT data FROM threads WHERE id = ?", [threadId], (err, row) => {
          if (err) {
            reject(err)
          } else {
            resolve(row ? JSON.parse(row.data) : undefined)
          }
        })
      } else if (key.startsWith("user_")) {
        const userId = key.replace("user_", "")
        db.get("SELECT data FROM users WHERE id = ?", [userId], (err, row) => {
          if (err) {
            reject(err)
          } else {
            resolve(row ? JSON.parse(row.data) : undefined)
          }
        })
      } else {
        db.get("SELECT data FROM data WHERE id = ?", [key], (err, row) => {
          if (err) {
            reject(err)
          } else {
            resolve(row ? JSON.parse(row.data) : undefined)
          }
        })
      }
    })
  },
  
  /**
   * حفظ وحقن البيانات في الجدول المقابل مع ميزة الاستبدال التلقائي عند التكرار
   */
  set: (key, value) => {
    return new Promise((resolve, reject) => {
      const jsonData = JSON.stringify(value)
      
      if (key.startsWith("thread_")) {
        const threadId = key.replace("thread_", "")
        db.run(
          `INSERT OR REPLACE INTO threads (id, data, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)`,
          [threadId, jsonData],
          (err) => {
            if (err) {
              reject(err)
            } else {
              resolve()
            }
          }
        )
      } else if (key.startsWith("user_")) {
        const userId = key.replace("user_", "")
        db.run(
          `INSERT OR REPLACE INTO users (id, data, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)`,
          [userId, jsonData],
          (err) => {
            if (err) {
              reject(err)
            } else {
              resolve()
            }
          }
        )
      } else {
        db.run(
          `INSERT OR REPLACE INTO data (id, data, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)`,
          [key, jsonData],
          (err) => {
            if (err) {
              reject(err)
            } else {
              resolve()
            }
          }
        )
      }
    })
  },
  
  /**
   * حذف سجل ومعرف معين نهائياً من جداول ملف قاعدة البيانات المحلي
   */
  delete: (key) => {
    return new Promise((resolve, reject) => {
      if (key.startsWith("thread_")) {
        const threadId = key.replace("thread_", "")
        db.run("DELETE FROM threads WHERE id = ?", [threadId], (err) => {
          if (err) {
            reject(err)
          } else {
            resolve()
          }
        })
      } else if (key.startsWith("user_")) {
        const userId = key.replace("user_", "")
        db.run("DELETE FROM users WHERE id = ?", [userId], (err) => {
          if (err) {
            reject(err)
          } else {
            resolve()
          }
        })
      } else {
        db.run("DELETE FROM data WHERE id = ?", [key], (err) => {
          if (err) {
            reject(err)
          } else {
            resolve()
          }
        })
      }
    })
  },
  
  /**
   * استخراج وتجميع مصفوفات السجلات الحية بناءً على البادئة أو المطابقة الجزئية LIKE
   */
  getByPrefix: (prefix) => {
    return new Promise((resolve, reject) => {
      if (prefix === "user_") {
        db.all("SELECT id, data FROM users", [], (err, rows) => {
          if (err) {
            reject(err)
          } else {
            const result = {}
            rows.forEach(row => {
              result[row.id] = JSON.parse(row.data)
            })
            resolve(result)
          }
        })
      } else if (prefix === "thread_") {
        db.all("SELECT id, data FROM threads", [], (err, rows) => {
          if (err) {
            reject(err)
          } else {
            const result = {}
            rows.forEach(row => {
              result[row.id] = JSON.parse(row.data)
            })
            resolve(result)
          }
        })
      } else {
        db.all("SELECT id, data FROM data WHERE id LIKE ?", [`${prefix}%`], (err, rows) => {
          if (err) {
            reject(err)
          } else {
            const result = {}
            rows.forEach(row => {
              result[row.id] = JSON.parse(row.data)
            })
            resolve(result)
          }
        })
      }
    })
  },
  
  /**
   * عمل جرد تتابعي متكامل واستخراج مصفوفة تحوي كافة المفاتيح النشطة بالجداول
   */
  getAllKeys: () => {
    return new Promise((resolve, reject) => {
      const keys = []
      
      db.all("SELECT id FROM users", [], (err, userRows) => {
        if (err) {
          reject(err)
          return
        }
        
        db.all("SELECT id FROM threads", [], (err, threadRows) => {
          if (err) {
            reject(err)
            return
          }
          
          db.all("SELECT id FROM data", [], (err, dataRows) => {
            if (err) {
              reject(err)
              return
            }
            
            userRows.forEach(row => keys.push(`user_${row.id}`))
            threadRows.forEach(row => keys.push(`thread_${row.id}`))
            dataRows.forEach(row => keys.push(row.id))
            
            resolve(keys)
          })
        })
      })
    })
  },
  
  /**
   * التحقق السريع والتأكد من وجود مفتاح محدد داخل سجلات الجداول (Boolean)
   */
  has: (key) => {
    return new Promise((resolve, reject) => {
      if (key.startsWith("thread_")) {
        const threadId = key.replace("thread_", "")
        db.get("SELECT COUNT(*) as count FROM threads WHERE id = ?", [threadId], (err, row) => {
          if (err) {
            reject(err)
          } else {
            resolve(row.count > 0)
          }
        })
      } else if (key.startsWith("user_")) {
        const userId = key.replace("user_", "")
        db.get("SELECT COUNT(*) as count FROM users WHERE id = ?", [userId], (err, row) => {
          if (err) {
            reject(err)
          } else {
            resolve(row.count > 0)
          }
        })
      } else {
        db.get("SELECT COUNT(*) as count FROM data WHERE id = ?", [key], (err, row) => {
          if (err) {
            reject(err)
          } else {
            resolve(row.count > 0)
          }
        })
      }
    })
  },
  
  /**
   * تصدير بنية بيانات شاملة وموحدة مجمّعة من كافة الجداول الفرعية لغايات النسخ الاحتياطي
   */
  getAllData: () => {
    return new Promise((resolve, reject) => {
      const result = { data: {}, threads: {}, users: {} }
      
      db.all("SELECT id, data FROM users", [], (err, userRows) => {
        if (err) {
          reject(err)
          return
        }
        
        userRows.forEach(row => {
          result.users[row.id] = JSON.parse(row.data)
        })
        
        db.all("SELECT id, data FROM threads", [], (err, threadRows) => {
          if (err) {
            reject(err)
            return
          }
          
          threadRows.forEach(row => {
            result.threads[row.id] = JSON.parse(row.data)
          })
          
          db.all("SELECT id, data FROM data", [], (err, dataRows) => {
            if (err) {
              reject(err)
              return
            }
            
            dataRows.forEach(row => {
              result.data[row.id] = JSON.parse(row.data)
            })
            
            resolve(result)
          })
        })
      })
    })
  },
  
  /**
   * جلب تقرير إحصائي رقمي فوري لعدد الصفوف والمستندات المسجلة بقاعدة البيانات المحلية
   */
  getStats: () => {
    return new Promise((resolve, reject) => {
      let userCount = 0
      let threadCount = 0
      let dataCount = 0
      
      db.get("SELECT COUNT(*) as count FROM users", [], (err, userRow) => {
        if (err) {
          reject(err)
          return
        }
        userCount = userRow.count
        
        db.get("SELECT COUNT(*) as count FROM threads", [], (err, threadRow) => {
          if (err) {
            reject(err)
            return
          }
          threadCount = threadRow.count
          
          db.get("SELECT COUNT(*) as count FROM data", [], (err, dataRow) => {
            if (err) {
              reject(err)
              return
            }
            dataCount = dataRow.count
            
            resolve({
              users: userCount,
              threads: threadCount,
              data: dataCount,
              total: userCount + threadCount + dataCount
            })
          })
        })
      })
    })
  },
  
  /**
   * إغلاق الجلسة المفتوحة وإنهاء اتصالات محرك الـ SQLite بشكل نظيف وآمن
   */
  close: () => {
    return new Promise((resolve) => {
      if (db) {
        db.close((err) => {
          if (err) {
            console.error('❌ [Matrix-DB] خطأ أثناء محاولة إغلاق قاعدة بيانات SQLite:', err)
          }
          resolve()
        })
      } else {
        resolve()
      }
    })
  }
}
