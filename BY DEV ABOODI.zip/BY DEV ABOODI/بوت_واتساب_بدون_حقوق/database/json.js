const fs = require("fs").promises
const path = require("path")
const { initializeDatabase } = require("./init")

/**
 * محرك إدارة واستعلامات قاعدة البيانات الموزعة (JSON Database Engine) - Matrix-Bot
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 * المشروع: Matrix-Bot (Data Core System)
 */

const dbPath = path.join(__dirname, "/data/data.json")
const threadPath = path.join(__dirname, "/data/thread.json")
const userPath = path.join(__dirname, "/data/user.json")

// ذاكرة الكاش المؤقتة لضمان سرعة الاستجابة الفورية للقراءة (In-Memory Cache)
let data = {}
let threads = {}
let users = {}

module.exports = {
  /**
   * دالة الاتصال وتأمين ملفات قاعدة البيانات وتحميلها إلى ذاكرة الكاش
   */
  connect: async () => {
    try {
      // تشغيل دالة التهيئة الأولية للتأكد من وجود المسارات
      initializeDatabase()
      
      // تحميل بيانات النظام العام
      const fileContent = await fs.readFile(dbPath, "utf-8")
      data = JSON.parse(fileContent)
      
      // تحميل بيانات المجموعات (Threads) مع معالجة خطأ عدم الوجود
      try {
        const threadContent = await fs.readFile(threadPath, "utf-8")
        threads = JSON.parse(threadContent)
      } catch (error) {
        if (error.code === "ENOENT") {
          threads = {}
          await fs.writeFile(threadPath, JSON.stringify(threads, null, 2))
        }
      }
      
      // تحميل بيانات المستخدمين (Users) مع معالجة خطأ عدم الوجود
      try {
        const userContent = await fs.readFile(userPath, "utf-8")
        users = JSON.parse(userContent)
      } catch (error) {
        if (error.code === "ENOENT") {
          users = {}
          await fs.writeFile(userPath, JSON.stringify(users, null, 2))
        }
      }
    } catch (error) {
      // نظام الأمان الاحتياطي في حال فقدان ملف الإعدادات العام أثناء التشغيل
      if (error.code === "ENOENT") {
        initializeDatabase()
        const fileContent = await fs.readFile(dbPath, "utf-8")
        data = JSON.parse(fileContent)
      } else {
        console.error("❌ [Matrix-DB] فشل فادح أثناء محاولة تحميل قاعدة بيانات الـ JSON:", error)
      }
    }
  },
  
  /**
   * جلب وقراءة قيمة مفتاح معين من الذاكرة بناءً على نوع البادئة
   * @param {string} key - المفتاح المستهدف (مثل user_123 أو إعداد عام)
   */
  get: (key) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      return Promise.resolve(threads[threadId])
    }
    if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      return Promise.resolve(users[userId])
    }
    return Promise.resolve(data[key])
  },
  
  /**
   * تعيين وحفظ قيمة مفتاح معين وكتابتها فورياً في ملف التخزين المقابل
   */
  set: async (key, value) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      threads[threadId] = value
      await fs.writeFile(threadPath, JSON.stringify(threads, null, 2))
    } else if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      users[userId] = value
      await fs.writeFile(userPath, JSON.stringify(users, null, 2))
    } else {
      data[key] = value
      await fs.writeFile(dbPath, JSON.stringify(data, null, 2))
    }
  },
  
  /**
   * حذف مفتاح وسجل معين نهائياً من الذاكرة وملف التخزين الفيزيائي
   */
  delete: async (key) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      delete threads[threadId]
      await fs.writeFile(threadPath, JSON.stringify(threads, null, 2))
    } else if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      delete users[userId]
      await fs.writeFile(userPath, JSON.stringify(users, null, 2))
    } else {
      delete data[key]
      await fs.writeFile(dbPath, JSON.stringify(data, null, 2))
    }
  },
  
  /**
   * جلب تقرير إحصائي رقمي عن حجم البيانات المخزنة في الجداول
   */
  getStats: () => {
    return Promise.resolve({
      users: Object.keys(users).length,
      threads: Object.keys(threads).length,
      data: Object.keys(data).length,
      total: Object.keys(users).length + Object.keys(threads).length + Object.keys(data).length
    })
  },
  
  /**
   * جلب مجموعة بيانات كاملة بناءً على نوع البادئة الممررة
   */
  getByPrefix: async (prefix) => {
    if (prefix === "user_") {
      return Promise.resolve(users)
    }
    if (prefix === "thread_") {
      return Promise.resolve(threads)
    }
    const result = {}
    for (const key in data) {
      if (key.startsWith(prefix)) {
        result[key] = data[key]
      }
    }
    return Promise.resolve(result)
  },
  
  /**
   * جلب مصفوفة تحتوي على كافة المفاتيح المسجلة بالنظام مضافاً إليها البادئات المعيارية
   */
  getAllKeys: () => {
    return Promise.resolve([
      ...Object.keys(users).map(k => `user_${k}`),
      ...Object.keys(threads).map(k => `thread_${k}`),
      ...Object.keys(data)
    ])
  },
  
  /**
   * التحقق من وجود مفتاح معين داخل سجلات الذاكرة (Boolean)
   */
  has: (key) => {
    if (key.startsWith("thread_")) {
      const threadId = key.replace("thread_", "")
      return Promise.resolve(threads.hasOwnProperty(threadId))
    }
    if (key.startsWith("user_")) {
      const userId = key.replace("user_", "")
      return Promise.resolve(users.hasOwnProperty(userId))
    }
    return Promise.resolve(data.hasOwnProperty(key))
  },
  
  /**
   * جلب وتصدير نسخة شاملة لكافة محتويات قاعدة البيانات بجميع جداولها الفرعية
   */
  getAllData: () => {
    return Promise.resolve({ data, threads, users })
  }
}
