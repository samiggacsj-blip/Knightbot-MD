const jsonDb = require("./json")
const mongoDb = require("./mongodb")
const sqliteDb = require("./sqlite")
const mysqlDb = require("./mysql")
let db

/**
 * محرك الربط والتحويل الديناميكي الموحد لقواعد البيانات (Database Bridge) - Matrix-Bot
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 * المشروع: Matrix-Bot (Database Switcher Core)
 */
module.exports = {
  /**
   * دالة الاتصال الذكي وتحديد المحرك المفعل بناءً على ملف الإعدادات
   * @param {Object} config - كائن يحتوي على نوع قاعدة البيانات وبيانات الاتصال
   */
  connect: async (config) => {
    switch (config.type) {
      case "mongodb":
        await mongoDb.connect(config.mongodb.uri)
        db = mongoDb
        break
      case "sqlite":
        await sqliteDb.connect(config.sqlite?.path || "database.db")
        db = sqliteDb
        break
      case "mysql":
        await mysqlDb.connect(config.mysql)
        db = mysqlDb
        break
      case "json":
      default:
        await jsonDb.connect()
        db = jsonDb
        break
    }
    console.log(`✅ [Matrix-DB] تم ربط وتفعيل قاعدة البيانات بنجاح: ${config.type || 'json'}`)
  },

  get: (key) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return db.get(key)
  },

  set: (key, value) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return db.set(key, value)
  },

  delete: (key) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return db.delete(key)
  },
  
  getByPrefix: (prefix) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return db.getByPrefix(prefix)
  },
  
  close: () => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    if (db.close) {
      return db.close()
    }
  },

  // جلب سجل الإحصائيات الرقمية التفصيلية للمحرك الفعال حالياً
  getStats: () => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return db.getStats();
  },

  // ==========================================
  // وظائف وإجراءات إدارة بيانات المستخدمين (Users)
  // ==========================================
  
  getUserData: async (userId) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.get(`user_${userId}`);
  },

  setUserData: async (userId, userData) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.set(`user_${userId}`, userData);
  },

  getAllUsers: async () => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.getByPrefix('user_');
  },

  // ==========================================
  // وظائف وإجراءات إدارة بيانات المجموعات (Threads)
  // ==========================================

  getThreadData: async (threadId) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.get(`thread_${threadId}`);
  },

  setThreadData: async (threadId, threadData) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.set(`thread_${threadId}`, threadData);
  },

  getAllThreads: async () => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.getByPrefix('thread_');
  },

  // ==========================================
  // وظائف وإجراءات تتبع سجلات الرسائل (Messages)
  // ==========================================

  getMessageData: async (messageId) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.get(`message_${messageId}`);
  },

  getThreadMessages: async (threadId) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.get(`thread_messages_${threadId}`) || [];
  },

  // ==========================================
  // وظائف وإجراءات التحكم بالإعدادات العامة للبوت
  // ==========================================

  getGlobalData: async (key) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.get(`global_${key}`);
  },

  setGlobalData: async (key, value) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.set(`global_${key}`, value);
  },

  // ==========================================
  // الأدوات المساعدة المتقدمة لفحص هيكل البيانات
  // ==========================================

  getAllKeys: async () => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.getAllKeys();
  },

  has: async (key) => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.has(key);
  },

  getAllData: async () => {
    if (!db) throw new Error("❌ [Matrix-DB] لم يتم الاتصال بقاعدة البيانات بعد.")
    return await db.getAllData();
  }
}
