const axios = require("axios");
const fs = require("fs");
const path = require("path");
// const youtubedl = require("youtube-dl-exec");
const { logger } = require("../libs/logger");

/**
 * أدوات إدارة الميديا والتحميلات - Matrix-Bot
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 */

// دالة مساعدة للحصول على الامتداد من نوع MIME
function getExtFromMimeType(mimeType = "") {
  const mimeDB = require('mime-db');
  if (mimeDB[mimeType] && Array.isArray(mimeDB[mimeType].extensions)) {
    return mimeDB[mimeType].extensions[0] || "unknown";
  }
  return "unknown";
}

// دالة مساعدة لتوليد نص عشوائي لتسمية الملفات المؤقتة
function randomString(length = 10) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

// دالة متطورة لتحويل الرابط إلى Stream مع معالجة ذكية للأخطاء
async function getStreamFromURL(url = "", pathName = "", options = {}) {
  if (!options && typeof pathName === "object") {
    options = pathName;
    pathName = "";
  }

  // إذا كان مسار ملف محلي، قم بإرجاع ReadStream مباشرة
  if (typeof url === "string" && !/^https?:\/\//.test(url) && fs.existsSync(url)) {
    return fs.createReadStream(url);
  }

  // خلاف ذلك، يتم التعامل معه كرابط خارجي عن بعد
  try {
    if (!url || typeof url !== "string" || url.trim() === "") {
      throw new Error(`الرابط المزود غير صالح أو فارغ: ${url}`);
    }
    if (!isValidUrl(url)) {
      throw new Error(`صيغة الرابط غير مدعومة: ${url}`);
    }
    const response = await axios({
      url: url.trim(),
      method: "GET",
      responseType: "stream",
      timeout: 15000,
      maxRedirects: 3,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      },
      ...options
    });
    if (!pathName) {
      const contentType = response.headers["content-type"];
      const extension = getExtFromMimeType(contentType) || "jpg";
      pathName = randomString(10) + '.' + extension;
    }
    if (response.data) {
      response.data.path = pathName;
    }
    return response.data;
  } catch (err) {
    logger.error(`❌ حدث خطأ في معالج تحويل الرابط للمجموعة ${url}: ${err.message}`);
    throw err;
  }
}

// دالة إرسال الملحقات والميديا مع نص (Caption) مع نظام إعادة المحاولة تلقائياً
async function sendAttachmentWithText(api, jid, attachmentPath, text, type = "image") {
  const maxRetries = 2;
  let attempt = 0;
  
  while (attempt < maxRetries) {
    try {
      logger.info(`🔄 جاري محاولة إرسال ملف الـ ${type} (المحاولة ${attempt + 1}/${maxRetries}): ${attachmentPath}`);
      
      const messageContent = {
        caption: text
      };
      
      // إذا كان الملحق عبارة عن رابط خارجي
      if (attachmentPath.startsWith('http')) {
        const stream = await getStreamFromURL(attachmentPath);
        
        if (type === "image") {
          messageContent.image = stream;
        } else if (type === "video") {
          messageContent.video = stream;
        } else if (type === "audio") {
          messageContent.audio = stream;
        }
      } else {
        // إذا كان مسار ملف محلي بالسيرفر
        if (type === "image") {
          messageContent.image = { url: attachmentPath };
        } else if (type === "video") {
          messageContent.video = { url: attachmentPath };
        } else if (type === "audio") {
          messageContent.audio = { url: attachmentPath };
        }
      }
      
      await api.sendMessage(jid, messageContent);
      logger.info(`✅ تم إرسال ملف الـ ${type} بنجاح واكتملت العملية الحين`);
      return true;
    } catch (error) {
      logger.error(`⚠️ حدث خطأ أثناء إرسال ملف الـ ${type} (المحاولة ${attempt + 1}): ${error.message}`);
      attempt++;
      
      if (attempt < maxRetries) {
        logger.info(`🔄 انتظر ثانية واحدة، جاري إعادة المحاولة الحين تلقائياً...`);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  }
  
  logger.error(`❌ فشل إرسال ملف الـ ${type} بالكامل بعد ${maxRetries} محاولات متتالية`);
  return false;
}

// دالة إرسال ملحقات متعددة دفعة واحدة مع نظام متقدم لتفادي الحظر والسبام
async function sendMultipleAttachments(api, jid, attachments, type = "image", text = null) {
  try {
    // التحقق من صحة المدخلات البرمجية لتفادي كراش البوت
    if (!api || !jid || !attachments) {
      logger.error("❌ بارامترات غير صالحة ممررة لدالة إرسال الملحقات المتعددة");
      if (text) {
        await api.sendMessage(jid, { text: text });
      }
      return false;
    }

    // إذا كانت الملحقات مصفوفة روابط (مثل روابط الصور المصغرة للبومات)
    if (Array.isArray(attachments) && typeof attachments[0] === 'string') {
      const validUrls = attachments.filter(url => url && url.trim() && isValidUrl(url));
      
      if (validUrls.length === 0) {
        logger.error("❌ لم يتم العثور على أي روابط صالحة لإرسالها");
        if (text) {
          await api.sendMessage(jid, { text: text });
        }
        return false;
      }

      try {
        // إرسال النص الرئيسي أولاً
        if (text) {
          await api.sendMessage(jid, { text: text });
        }

        // إرسال الصور واحدة تلو الأخرى مع نظام حماية ذكي وتأخير زمني لمنع السبام
        let sentCount = 0;
        const maxImages = Math.min(validUrls.length, 3); // حد أقصى 3 صور لحماية الحساب من الحظر والسبام
        
        for (let i = 0; i < maxImages; i++) {
          try {
            logger.info(`🔄 جاري محاولة إرسال الصورة رقم ${i + 1}/${maxImages}: ${validUrls[i]}`);
            
            // المحاولة الأولى: الطريقة المباشرة بالروابط (الأكثر استقراراً للصور)
            try {
              const messageContent = {
                image: { url: validUrls[i] }
              };
              
              await api.sendMessage(jid, messageContent);
              sentCount++;
              logger.info(`✅ تم إرسال الصورة بنجاح رقم ${i + 1}/${maxImages}`);
              
              // تأخير زمني طفيف بين الرسائل لتفادي نظام الحظر تلقائياً
              if (i < maxImages - 1) {
                await new Promise(resolve => setTimeout(resolve, 1000));
              }
            } catch (directError) {
              logger.error(`⚠️ فشلت الطريقة المباشرة للصورة رقم ${i + 1}، يتم التحويل لطريقة الـ stream الحين: ${directError.message}`);
              
              // الحل البديل: التحويل لـ stream لإرسالها بأمان
              try {
                const stream = await getStreamFromURL(validUrls[i]);
                
                if (stream && stream.readable !== false) {
                  const messageContent = {
                    image: stream
                  };
                  
                  await api.sendMessage(jid, messageContent);
                  sentCount++;
                  logger.info(`✅ تم إرسال الصورة رقم ${i + 1}/${maxImages} بنجاح باستخدام طريقة الـ stream التبادلية`);
                  
                  if (i < maxImages - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1000));
                  }
                } else {
                  logger.error(`❌ ملف الـ stream غير صالح للصورة رقم ${i + 1}: ${validUrls[i]}`);
                }
              } catch (streamError) {
                logger.error(`❌ فشلت طريقة الـ stream أيضاً للصورة رقم ${i + 1}: ${streamError.message}`);
              }
            }
          } catch (error) {
            logger.error(`❌ خطأ عام أثناء محاولة إرسال الصورة رقم ${i + 1}/${maxImages} (${validUrls[i]}): ${error.message}`);
          }
        }

        logger.info(`📊 ملخص الملحقات: تم إرسال ${sentCount} صور بنجاح من أصل إجمالي ${maxImages}`);
        return sentCount > 0;
        
      } catch (error) {
        logger.error(`❌ حدث خطأ فادح في معالج الملحقات المتعددة الرئيسي: ${error.message}`);
        // الحل الأخير عند الكراش الكلي: إرسال النص فقط ليعلم العميل بنجاح الطلب
        if (text) {
          try {
            await api.sendMessage(jid, { text: text });
          } catch (textError) {
            logger.error(`❌ تعذر إرسال النص كحل بديل أخير: ${textError.message}`);
          }
        }
        return false;
      }
    }
    
    // النظام القديم المستورث: إرسال الملحقات الفردية مع نصوصها الخاصة بكل سطر
    let successCount = 0;
    for (const attachment of attachments) {
      const success = await sendAttachmentWithText(api, jid, attachment.path, attachment.caption || "", attachment.type || "image");
      if (success) successCount++;
      
      await new Promise(resolve => setTimeout(resolve, 800));
    }
    
    if (text) {
      await api.sendMessage(jid, { text: text });
    }
    
    return successCount > 0;
  } catch (error) {
    logger.error(`❌ خطأ غير متوقع في محمل الملحقات المتعددة الإجمالي: ${error.message}`);
    return false;
  }
}

// دالة فحص والتحقق من روابط اليوتيوب الصالحة
function validateYouTubeURL(url) {
  const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/;
  return youtubeRegex.test(url);
}

// نظام إدارة ملفات نظام التشغيل المؤقتة والمسارات الحية
function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function getDownloadsDir() {
  const downloadsDir = path.join(process.cwd(), "downloads");
  ensureDir(downloadsDir);
  return downloadsDir;
}

function getTempDir() {
  const tempDir = path.join(process.cwd(), "temp");
  ensureDir(tempDir);
  return tempDir;
}

// دالة التطهير الفوري والذكي لحذف الملفات المؤقتة بعد إرسالها لعدم ملء مساحة ذاكرة الترمكس
function cleanupFile(filepath, delay = 5000) {
  setTimeout(() => {
    try {
      if (fs.existsSync(filepath)) {
        fs.unlinkSync(filepath);
      }
    } catch (e) {
      console.log("❌ فشل في تنظيف وحذف الملف المؤقت السريع من الذاكرة الحالية:", e);
    }
  }, delay);
}

function sanitizeFilename(filename, maxLength = 50) {
  return filename.replace(/[^a-zA-Z0-9]/g, "_").substring(0, maxLength);
}

// أدوات معالجة وتنسيق نصوص الميديا والأحجام البرمجية للمستندات
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDuration(seconds) {
  if (!seconds) return "00:00";
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// دالة التحقق البرمجي التام من هيكل وصحة الروابط الخارجية
function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}

// معالج فحص حجم الملف وضمان بقائه ضمن الحدود المسموحة لعدم حدوث كراش بالاتصال
function isWithinSizeLimit(filepath, limitMB = 25) {
  try {
    const stats = fs.statSync(filepath);
    const fileSizeInMB = stats.size / (1024 * 1024);
    logger.info(`📊 حجم الملف الحالي: ${fileSizeInMB.toFixed(2)} ميجابايت (الحد المسموح الأقصى: ${limitMB} ميجابايت)`);
    return fileSizeInMB <= limitMB;
  } catch (error) {
    console.log("❌ فشل معالج فحص الحجم في فحص مساحة الملف الحالية:", error.message);
    return false;
  }
}

// نظام الفحص المعزز والأشمل لصحة ملفات الوسائط قبل التمرير النهائي للواتساب
function validateMediaFile(filepath, type = "image") {
  try {
    if (!fs.existsSync(filepath)) {
      logger.error(`❌ الملف المستهدف غير موجود كلياً في هذا المسار البرمجي: ${filepath}`);
      return false;
    }

    const stats = fs.statSync(filepath);
    if (stats.size === 0) {
      logger.error(`❌ حجم ملف الميديا تالف ويساوي صفر بايت: ${filepath}`);
      return false;
    }

    // تحديد أسقف المساحات والحدود المسموح بها تبعاً لكل نوع ميديا بدقة
    let sizeLimit;
    switch (type) {
      case "image":
        sizeLimit = 5; // 5 ميجابايت كحد أقصى للصور الفردية
        break;
      case "video":
        sizeLimit = 25; // 25 ميجابايت كحد أقصى لمقاطع الفيديوهات والريلز
        break;
      case "audio":
        sizeLimit = 10; // 10 ميجابايت كحد أقصى للبصمات الصوتية والمقاطع الصوتية
        break;
      default:
        sizeLimit = 25; // الحد المانع والافتراضي لباقي الملفات الأخرى والمستندات
    }

    const fileSizeInMB = stats.size / (1024 * 1024);
    if (fileSizeInMB > sizeLimit) {
      return false;
    }
    return true;
  } catch (error) {
    return false;
  }
}

module.exports = {
  getExtFromMimeType,
  randomString,
  getStreamFromURL,
  sendAttachmentWithText,
  sendMultipleAttachments,
  // downloadWithFallback,
  // downloadWithYoutubeDL,
  validateYouTubeURL,
  ensureDir,
  getDownloadsDir,
  getTempDir,
  cleanupFile,
  sanitizeFilename,
  formatFileSize,
  formatDuration,
  isValidUrl,
  isWithinSizeLimit,
  validateMediaFile
};
