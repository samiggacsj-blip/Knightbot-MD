/**
 * مُحسِّن المزامنة (Sync Optimizer) - تحسين عمليات مزامنة البيانات مع قاعدة البيانات
 * المطور الرئيسي: -` 𝐃𝐄𝐕 ! 𝐀𝐁𝐎𝐎𝐃𝐈 ˎˊ˗
 * المشروع: Matrix-Bot
 */

class SyncOptimizer {
  constructor() {
    this.batchSize = 20; // حجم الدفعة (تمت زيادتها لضمان معالجة أسرع)
    this.delay = 50; // وقت الانتظار بالمللي ثانية بين الدفعات لتفادي الحظر
    this.maxRetries = 2; // عدد محاولات إعادة الاتصال عند الفشل
    this.cache = new Map();
  }

  /**
   * تحسين مزامنة المجموعات باستخدام معالجة الدفعات ونظام مهلة الحماية
   */
  async optimizeGroupSync(groups, syncFunction, logger) {
    try {
      const startTime = Date.now();
      const timeout = 30000; // مهلة حماية مدتها 30 ثانية لتجنب تجميد البوت

      const results = {
        syncedGroups: 0,
        syncedUsers: 0,
        errors: []
      };

      // معالجة المجموعات على دفعات مع مراعاة وقت المهلة
      const processWithTimeout = async () => {
        for (let i = 0; i < groups.length; i += this.batchSize) {
          const batch = groups.slice(i, i + this.batchSize);
          
          // معالجة الدفعة بالتوازي باستخدام Promise.allSettled للتحكم الذكي بالأخطاء
          const batchResults = await Promise.allSettled(
            batch.map(group => this.syncGroupWithRetry(group, syncFunction, logger))
          );

          // معالجة وتحليل نتائج الدفعة الحالية
          for (const result of batchResults) {
            if (result.status === 'fulfilled') {
              results.syncedGroups += result.value.syncedGroups || 0;
              results.syncedUsers += result.value.syncedUsers || 0;
            } else {
              results.errors.push(result.reason);
              if (logger) {
                logger.warn(`⚠️ فشلت مزامنة المجموعة الحالية: ${result.reason.message}`);
              }
            }
          }

          // التحقق من تجاوز وقت المهلة المسموح به
          if (Date.now() - startTime > timeout) {
            if (logger) {
              logger.warn("⏱️ تم الوصول لحد مهلة المزامنة الأقصى، يتم إيقاف العملية مؤقتاً لحماية الاتصال...");
            }
            break;
          }

          // تأخير زمني بسيط بين الدفعات لمنع نظام حظر الواتساب (Rate Limiting)
          if (i + this.batchSize < groups.length) {
            await this.sleep(this.delay);
          }
        }
      };

      // سباق برمجي بين إتمام العملية بالكامل أو انتهاء وقت المهلة
      await Promise.race([
        processWithTimeout(),
        new Promise((_, reject) => setTimeout(() => reject(new Error("انتهت مهلة المزامنة المسموحة")), timeout))
      ]);

      return results;
    } catch (error) {
      if (logger) {
        logger.error("💥 خطأ فادح في نظام محسن المزامنة الخارجي:", error);
      }
      throw error;
    }
  }

  /**
   * مزامنة مجموعة فردية مع نظام إعادة المحاولة الذكي عند الفشل (النسخة السريعة)
   */
  async syncGroupWithRetry(group, syncFunction, logger) {
    let lastError;
    
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        return await syncFunction(group);
      } catch (error) {
        lastError = error;
        if (logger && attempt === this.maxRetries) {
          logger.warn(`❌ فشلت مزامنة المجموعة بعد ${this.maxRetries} محاولات متتالية للمجموعة ذات المعرف ${group.id}: ${error.message}`);
        }
        
        if (attempt < this.maxRetries) {
          await this.sleep(this.delay * attempt); // تراجع أسي (Exponential backoff) لزيادة المهلة تدريجياً
        }
      }
    }
    
    // إرجاع نتيجة فارغة بدلاً من رمي خطأ فادح يوقف السكريبت بالكامل
    return { syncedGroups: 0, syncedUsers: 0 };
  }

  /**
   * أداة توقف زمني مساعدة (Sleep Utility)
   */
  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * تعيين وتحديث إعدادات التحسين ديناميكياً
   */
  setConfig(config) {
    if (config.batchSize) this.batchSize = config.batchSize;
    if (config.delay) this.delay = config.delay;
    if (config.maxRetries) this.maxRetries = config.maxRetries;
  }
}

module.exports = SyncOptimizer;
